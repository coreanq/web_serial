class E{static calculateExpectedResponseLength(e,t){try{let n;return typeof e=="string"?n=this.hexStringToUint8Array(e):n=e,n.length<2?-1:t==="RTU"?this.calculateRtuResponseLength(n):this.calculateTcpResponseLength(n,t)}catch(n){return console.warn("Error calculating expected response length:",n),-1}}static calculateRtuResponseLength(e){if(e.length<2)return-1;e[0];const t=e[1];if(t>=128)return 5;switch(t){case 1:case 2:return this.calculateRtuCoilResponseLength(e);case 3:case 4:return this.calculateRtuRegisterResponseLength(e);case 5:case 6:return 8;case 15:case 16:return 8;case 7:return 5;case 8:return 8;case 11:return 8;case 12:return-1;case 17:return-1;case 20:case 21:return-1;case 22:return 10;case 23:return this.calculateRtuReadWriteMultipleResponseLength(e);case 24:return-1;case 43:return-1;default:return-1}}static calculateTcpResponseLength(e,t){if(t==="TCP_NATIVE"){if(e.length<1)return-1;const s=e[0];return s>=128?2:this.calculateTcpNativePduLength(e,s)}else return e.length<7?-1:6+(e[4]<<8|e[5])}static calculateTcpNativePduLength(e,t){switch(t){case 1:case 2:return this.calculateTcpCoilResponseLength(e);case 3:case 4:return this.calculateTcpRegisterResponseLength(e);case 5:case 6:return 5;case 15:case 16:return 5;case 7:return 2;case 8:return 5;case 11:return 5;case 12:return-1;case 17:return-1;case 20:case 21:return-1;case 22:return 7;case 23:return this.calculateTcpReadWriteMultipleResponseLength(e);case 24:return-1;case 43:return-1;default:return-1}}static calculateRtuCoilResponseLength(e){if(e.length<6)return-1;const t=e[4]<<8|e[5];return t<=0||t>2e3?-1:3+Math.ceil(t/8)+2}static calculateRtuRegisterResponseLength(e){if(e.length<6)return-1;const t=e[4]<<8|e[5];return t<=0||t>125?-1:3+t*2+2}static calculateRtuReadWriteMultipleResponseLength(e){if(e.length<4)return-1;const t=e[4]<<8|e[5];return t<=0||t>125?-1:3+t*2+2}static calculateTcpCoilResponseLength(e){if(e.length<5)return-1;const t=e[3]<<8|e[4];return t<=0||t>2e3?-1:2+Math.ceil(t/8)}static calculateTcpRegisterResponseLength(e){if(e.length<5)return-1;const t=e[3]<<8|e[4];return t<=0||t>125?-1:2+t*2}static calculateTcpReadWriteMultipleResponseLength(e){if(e.length<5)return-1;const t=e[3]<<8|e[4];return t<=0||t>125?-1:2+t*2}static hexStringToUint8Array(e){const t=e.replace(/\s+/g,""),n=new Uint8Array(t.length/2);for(let s=0;s<t.length;s+=2)n[s/2]=parseInt(t.substr(s,2),16);return n}static getFunctionCode(e,t){try{let n;return typeof e=="string"?n=this.hexStringToUint8Array(e):n=e,n.length<1?-1:t==="RTU"?n.length>1?n[1]:-1:n[0]}catch{return-1}}static isFunctionCodePredictable(e){return[1,2,3,4,5,6,7,11,15,16,22,23].includes(e)||e>=128}static isResponseLengthValid(e,t,n=0){if(t<=0)return!0;let s;return typeof e=="string"?s=e.replace(/\s+/g,"").length/2:s=e.length,Math.abs(s-t)<=n}}class y{constructor(){this.currentPort=null,this.reader=null,this.writer=null,this.isConnected=!1,this.isConnecting=!1,this.isDisconnecting=!1,this.receiveBuffer=new Uint8Array(0),this.receiveTimeout=null,this.PACKET_TIMEOUT_MS=5,this.lastSentRequest=null}static isSupported(){return"serial"in navigator}async requestPort(e){if(!y.isSupported())throw new Error("Web Serial API is not supported in this browser");try{return await navigator.serial.requestPort({filters:e||[]})}catch(t){throw t instanceof Error&&t.name==="NotFoundError"?new Error("No serial port was selected"):new Error(`Failed to request serial port: ${t}`)}}async getGrantedPorts(){if(!y.isSupported())return[];try{return await navigator.serial.getPorts()}catch(e){return console.error("Failed to get granted ports:",e),[]}}async connect(e,t,n=15e3){if(this.isConnecting){console.log("Connection attempt blocked: already in progress");return}if(this.isConnected&&this.currentPort===e){console.log("Already connected to the same port");return}this.isConnected&&this.currentPort!==e&&await this.disconnect(),this.isConnecting=!0,console.log("Starting connection attempt...");try{const s=new Promise((i,r)=>{setTimeout(()=>{r(new Error(`Connection timeout after ${n/1e3} seconds. The device may not be responding or permission was denied.`))},n)}),o=async()=>{e.readable!==null||e.writable!==null||await e.open(t),this.currentPort=e,this.isConnected=!0,e.readable&&!this.reader&&(this.reader=e.readable.getReader()),e.writable&&!this.writer&&(this.writer=e.writable.getWriter())};await Promise.race([o(),s])}catch(s){if(this.currentPort=null,this.isConnected=!1,s instanceof Error){if(s.name==="InvalidStateError"){if(s.message.includes("already open"))throw new Error("Port is already open. Please close it first or refresh the page.");if(s.message.includes("already in progress"))throw new Error("Connection already in progress. Please wait a moment and try again.")}else{if(s.name==="NetworkError")throw new Error("Failed to open port. The device may be disconnected or in use by another application.");if(s.message.includes("timeout"))throw new Error(s.message)}throw new Error(`Failed to connect to serial port: ${s.message}`)}throw new Error(`Failed to connect to serial port: ${s}`)}finally{this.isConnecting=!1}}async disconnect(){if(!this.isDisconnecting){if(this.isDisconnecting=!0,this.isConnecting=!1,!this.currentPort){this.isConnected=!1,this.isDisconnecting=!1;return}try{if(this.receiveTimeout&&(clearTimeout(this.receiveTimeout),this.receiveTimeout=null),this.receiveBuffer=new Uint8Array(0),this.reader){try{await this.reader.cancel()}catch{}try{this.reader.releaseLock()}catch{}this.reader=null}if(this.writer){let e=!1;try{await this.writer.ready,await this.writer.close(),e=!0}catch{if(!e)try{await this.writer.abort()}catch{}}this.writer=null}if(await new Promise(e=>setTimeout(e,10)),this.currentPort)try{this.currentPort.readable===null&&this.currentPort.writable===null||await this.currentPort.close()}catch(e){const t=e instanceof Error?e.message:String(e);console.warn("Port close warning (this is usually harmless):",t)}}catch(e){console.error("Error during disconnect:",e)}finally{this.currentPort=null,this.isConnected=!1,this.isConnecting=!1,this.isDisconnecting=!1,this.reader=null,this.writer=null}}}async sendData(e){if(!this.isConnected||!this.writer)throw new Error("Not connected to any serial port");try{this.lastSentRequest=new Uint8Array(e),await this.writer.write(e)}catch(t){throw new Error(`Failed to send data: ${t}`)}}async sendHexString(e){const t=e.replace(/\s+/g,"");if(t.length%2!==0)throw new Error("Invalid hex string: must have even number of characters");const n=new Uint8Array(t.length/2);for(let s=0;s<t.length;s+=2)n[s/2]=parseInt(t.substring(s,s+2),16);await this.sendData(n)}async startReading(e,t){if(!this.isConnected||!this.reader)throw new Error("Not connected to any serial port");try{for(;this.isConnected&&this.reader;)try{const{value:n,done:s}=await this.reader.read();if(s)break;n&&n.length>0&&this.bufferReceivedData(n,e)}catch(n){if(n instanceof Error&&(n.name==="AbortError"||n.message.includes("cancelled")))break;throw n}}catch(n){t&&this.isConnected&&t(new Error(`Error reading from serial port: ${n}`))}}bufferReceivedData(e,t){const n=new Uint8Array(this.receiveBuffer.length+e.length);n.set(this.receiveBuffer),n.set(e,this.receiveBuffer.length),this.receiveBuffer=n;let s=-1;if(this.lastSentRequest&&this.receiveBuffer.length>=2)try{s=E.calculateExpectedResponseLength(this.lastSentRequest,"RTU")}catch{s=-1}if(s>0&&this.receiveBuffer.length>=s){this.receiveTimeout&&(clearTimeout(this.receiveTimeout),this.receiveTimeout=null),t(this.receiveBuffer),this.receiveBuffer=new Uint8Array(0),this.lastSentRequest=null;return}this.receiveTimeout&&clearTimeout(this.receiveTimeout),this.receiveTimeout=setTimeout(()=>{this.receiveBuffer.length>0&&(t(this.receiveBuffer),this.receiveBuffer=new Uint8Array(0),this.lastSentRequest=null),this.receiveTimeout=null},this.PACKET_TIMEOUT_MS)}getConnectionStatus(){return this.isConnected}getConnectionProgress(){return this.isConnecting}getCurrentPortInfo(){if(!this.currentPort)return"No port connected";const e=this.currentPort.getInfo();return e.usbVendorId&&e.usbProductId?`USB Device (VID: ${e.usbVendorId.toString(16).padStart(4,"0").toUpperCase()}, PID: ${e.usbProductId.toString(16).padStart(4,"0").toUpperCase()})`:"Serial Port"}static uint8ArrayToHex(e){return Array.from(e).map(t=>t.toString(16).padStart(2,"0").toUpperCase()).join(" ")}static hexToUint8Array(e){const t=e.replace(/\s+/g,""),n=new Uint8Array(t.length/2);for(let s=0;s<t.length;s+=2)n[s/2]=parseInt(t.substring(s,s+2),16);return n}}class k{constructor(e){this.port=null,this.messageListeners=new Map,this.hostName=e}connect(){return new Promise((e,t)=>{try{this.port=chrome.runtime.connectNative(this.hostName),this.port.onMessage.addListener(n=>{this.handleIncomingMessage(n)}),this.port.onDisconnect.addListener(()=>{this.handleDisconnect(),chrome.runtime.lastError?(console.error("Native port disconnected with error:",chrome.runtime.lastError.message),t(new Error(chrome.runtime.lastError.message))):console.log("Native port disconnected.")}),this.onMessage("proxy_started",()=>{console.log("Native Messaging Host connected and ready."),e()})}catch(n){console.error("Failed to connect to native host:",n),(n instanceof Error?n.message:String(n)).includes("native messaging host not found")?t(new Error("Native messaging host not found. Make sure it is installed correctly.")):t(n)}})}disconnect(){this.port&&(this.port.disconnect(),this.port=null)}sendMessage(e){if(!this.port){console.error("Cannot send message: Native port is not connected.");return}this.port.postMessage(e)}onMessage(e,t){this.messageListeners.has(e)||this.messageListeners.set(e,[]),this.messageListeners.get(e)?.push(t)}offMessage(e){this.messageListeners.delete(e)}handleIncomingMessage(e){if(e&&e.type){const t=this.messageListeners.get(e.type);t&&t.forEach(n=>n(e))}}handleDisconnect(){this.port=null,this.handleIncomingMessage({type:"native_disconnected"}),this.messageListeners.clear()}isConnected(){return this.port!==null}}class D{constructor(){this.isConnected=!1,this.isProxyConnected=!1,this.connectionCallbacks=[],this.dataCallbacks=[],this.errorCallbacks=[],this.proxyStatusCallbacks=[],this.receiveBuffer="",this.receiveTimeout=null,this.PACKET_TIMEOUT_MS=5,this.lastSentRequest=null,this.nativeService=new k("com.my_company.stdio_proxy"),this.setupMessageHandlers()}async init(){try{await this.nativeService.connect(),this.isProxyConnected=!0}catch(e){const t=e instanceof Error?e.message:String(e);throw new Error(`Failed to connect to native proxy: ${t}`)}}async connect(e){if(!this.isProxyConnected)throw new Error("Native proxy is not connected");this.nativeService.sendMessage({type:"connect",host:e.host,port:e.port})}disconnect(e=!1){if(console.log("🔴 TcpNativeService.disconnect() called, force:",e),!e){console.warn("⚠️ Automatic disconnect prevented. Use disconnect(true) for manual disconnect.");return}console.log("✅ Manual disconnect proceeding..."),this.receiveTimeout&&(clearTimeout(this.receiveTimeout),this.receiveTimeout=null),this.receiveBuffer="",this.isProxyConnected&&this.nativeService.sendMessage({type:"disconnect"}),this.isConnected=!1}sendData(e){if(!this.isConnected)throw new Error("TCP connection is not established");this.lastSentRequest=e,this.nativeService.sendMessage({type:"send",data:e})}onConnectionChange(e){this.connectionCallbacks.push(e)}onData(e){this.dataCallbacks.push(e)}onError(e){this.errorCallbacks.push(e)}onProxyStatus(e){this.proxyStatusCallbacks.push(e)}isTcpConnected(){return this.isConnected}isProxyReady(){return this.isProxyConnected}cleanup(){this.disconnect(),this.nativeService.disconnect(),this.isProxyConnected=!1,this.connectionCallbacks=[],this.dataCallbacks=[],this.errorCallbacks=[],this.proxyStatusCallbacks=[]}setupMessageHandlers(){this.nativeService.onMessage("proxy_started",()=>{this.isProxyConnected=!0,this.proxyStatusCallbacks.forEach(e=>e(!0))}),this.nativeService.onMessage("tcp_connected",()=>{this.isConnected=!0,this.connectionCallbacks.forEach(e=>e(!0))}),this.nativeService.onMessage("tcp_disconnected",()=>{this.isConnected=!1,this.connectionCallbacks.forEach(e=>e(!1))}),this.nativeService.onMessage("tcp_error",e=>{this.isConnected=!1;const t=e.message||"TCP connection error";this.connectionCallbacks.forEach(n=>n(!1,t)),this.errorCallbacks.forEach(n=>n(t))}),this.nativeService.onMessage("data",e=>{e.data&&this.bufferReceivedData(e.data)}),this.nativeService.onMessage("error",e=>{const t=e.message||"Unknown error";this.errorCallbacks.forEach(n=>n(t))}),this.nativeService.onMessage("native_disconnected",()=>{this.isProxyConnected=!1,this.isConnected=!1,this.proxyStatusCallbacks.forEach(e=>e(!1)),this.connectionCallbacks.forEach(e=>e(!1,"Native proxy disconnected"))})}bufferReceivedData(e){this.receiveBuffer+=e;let t=-1;if(this.lastSentRequest&&this.receiveBuffer.length>=2)try{t=E.calculateExpectedResponseLength(this.lastSentRequest,"TCP_NATIVE")}catch{t=-1}const n=this.receiveBuffer.replace(/\s+/g,"").length/2;if(t>0&&n>=t){this.receiveTimeout&&(clearTimeout(this.receiveTimeout),this.receiveTimeout=null),this.dataCallbacks.forEach(s=>s(this.receiveBuffer)),this.receiveBuffer="",this.lastSentRequest=null;return}this.receiveTimeout&&clearTimeout(this.receiveTimeout),this.receiveTimeout=setTimeout(()=>{this.receiveBuffer.length>0&&(this.dataCallbacks.forEach(s=>s(this.receiveBuffer)),this.receiveBuffer="",this.lastSentRequest=null),this.receiveTimeout=null},this.PACKET_TIMEOUT_MS)}}const M={app:{title:"Modbus Protocol Analyzer",subtitle:"Real-time Modbus RTU/TCP communication monitoring and analysis tool"},common:{connect:"Connect",disconnect:"Disconnect",send:"Send",clear:"Clear",export:"Export",import:"Import",save:"Save",cancel:"Cancel",ok:"OK",close:"Close",yes:"Yes",no:"No",loading:"Loading...",error:"Error",warning:"Warning",info:"Information",success:"Success",reset:"Reset",start:"Start",stop:"Stop",pause:"Pause",resume:"Resume",enabled:"Enabled",disabled:"Disabled",settings:"Settings",language:"Language",theme:"Theme",dark:"Dark",light:"Light"},panel:{position:"Panel Position",top:"Top",left:"Left",right:"Right",hide:"Hide Panel",show:"Show Panel",visibility:"Panel Visibility",layout:"Main Layout",commandLeft:"Command Left",commandRight:"Command Right"},connection:{title:"Connection",connected:"Connected",disconnected:"Disconnected",connecting:"Connecting...",connectionError:"Connection Error",type:"Connection Type",rtu:{title:"RTU (Serial)",port:"Serial Port",selectPort:"Select Port",noPortSelected:"No port selected",baudRate:"Baud Rate",parity:"Parity",dataBits:"Data Bits",stopBits:"Stop Bits",none:"None",even:"Even",odd:"Odd"},tcp:{title:"TCP",host:"Host",port:"Port",timeout:"Timeout (ms)",autoReconnect:"Auto Reconnect",reconnectInterval:"Reconnect Interval (s)"},messages:{selectPortFirst:"Please select a serial port first",connectionFailed:"Connection failed",connectionSuccess:"Connected successfully",disconnectSuccess:"Disconnected successfully",portNotAvailable:"Selected port is not available",nativeHostNotAvailable:"Native messaging host not available"},status:{nativeProxyConnected:"Native Proxy Connected",nativeProxyConnecting:"Connecting to Native Proxy...",nativeProxyFailed:"Native Proxy Connection Failed",nativeProxyDisconnected:"Native Proxy Disconnected",tcpNativeConnected:"TCP Connected",tcpNativeConnecting:"TCP Connecting...",tcpNativeFailed:"TCP Connection Failed",tcpNativeDisconnected:"TCP Disconnected",connectedTo:"Connected to:",connectingTo:"Connecting to:",failedToConnect:"Failed to connect to:",lastAttempted:"Last attempted:",noConnectionAttempted:"No connection attempted"},nativeGuide:{title:"Native TCP Setup Guide",connected:"Native Host is connected successfully!",notConnected:"Native Host installation required",connectedDesc:"TCP feature is available. Below are additional setup and troubleshooting methods.",notConnectedDesc:"Please follow the steps below to use TCP feature.",whyNeeded:"Why is separate installation needed?",browserSecurity:"Browser Security Limitation: Chromium-based browsers cannot make direct TCP connections for security reasons.",webSerialVsTcp:"Web Serial vs TCP:",rtuSerial:"RTU (Serial) → Uses built-in Web Serial API ✅",tcpNative:"TCP → Requires external program (Native Host) 📦",nativeHostRole:"Native Host Role: Acts as a bridge between extension and TCP devices.",supportedBrowsers:"Supported Browsers: All Chromium-based browsers including Chrome, Edge, Brave, Opera, Vivaldi",simpleInstall:"Simple Installation",step1:"Download OS-specific installation package",step1Desc:"Compressed file containing executable + installation script",step2:"Extract and run installation",macosLinux:"macOS/Linux: Extract → ./install-*.sh",windows:"Windows: Extract → double-click install-windows.bat",autoDetect:"💡 Auto-detects Extension ID, auto-installs for all browsers",step3:"Restart Browser",step3Desc:"Completely close and restart your browser",extensionId:"Current Extension ID",extensionIdDesc:"This ID will be automatically configured in the installation script.",installationConfirm:"Installation Verification",installationConfirmDesc:'Once installation is complete, the "Native Proxy" status above will change to "🟢 Connected".',troubleshooting:"Troubleshooting",confirm:"OK",troubleshootingItems:["Check if executable has execution permissions (macOS/Linux)","Verify Windows antivirus is not blocking the file","Confirm Extension ID is correctly configured","Completely restart browser (Chrome, Edge, Brave, etc.)","Test with other Chromium-based browsers"],clickToInstall:"Click to view installation guide",clickToGuide:"Click to view installation/setup guide",installGuide:"💡 Install",guideInfo:"ℹ️ Guide",clickToInstallTooltip:"↑ Click to install!",reinstallTooltip:"↑ Reinstall/troubleshoot",downloadManually:"Please open the download link manually: ",troubleshootingTitle:"& Troubleshooting"}},log:{title:"Communication Log",count:"{{count}} logs",autoScroll:"Auto Scroll",clearLogs:"Clear Logs",exportLogs:"Export Logs",logSettings:"Log Settings",filter:"Filter",search:"Search",timestamp:"Timestamp",direction:"Direction",data:"Data",send:"SEND",recv:"RECV",error:"Error",responseTime:"Response Time",export:{title:"Export Log Data",format:"Format",json:"JSON",csv:"CSV",txt:"Text",dateRange:"Date Range",allLogs:"All Logs",customRange:"Custom Range",from:"From",to:"To"},settings:{title:"Log Management Settings",memoryManagement:"Memory Management",bufferSize:"Buffer Size",segmentSize:"Segment Size",autoExport:"Auto Export",exportThreshold:"Export Threshold (%)",statistics:"Memory Statistics",memoryLogs:"Memory Logs",totalLogs:"Total Logs",exportedFiles:"Exported Files",memoryUsage:"Memory Usage",bufferUtilization:"Buffer Utilization",indexedDBLogs:"IndexedDB Logs",indexedDBSize:"IndexedDB Size",memoryEfficiency:"Memory Efficiency",allocatedSegments:"Allocated Segments",cleanup:"Cleanup Memory",reset:"Reset All Settings",bufferSizeDesc:"Maximum number of logs to keep in memory (overflow saved to file)",exportFormatDesc:"File format for overflow logs",circularBufferInfo:"Circular Buffer + IndexedDB Storage",circularBufferDesc:"Keeps logs in memory up to buffer size, excess logs are automatically saved to IndexedDB.",indexedDBInfo:"IndexedDB Overflow Storage",indexedDBDesc:"Logs exceeding memory buffer are automatically saved to IndexedDB. IndexedDB is cleared when saving all logs.",actions:"Actions",clearAllLogsWithDB:"Clear All Logs (Including DB)",settingsSaved:"Settings saved successfully!",settingsSaveError:"Error occurred while saving settings.",memoryLogsSaved:"Memory logs saved successfully!",memoryLogsSaveError:"Error occurred while saving memory logs.",allLogsSaved:"All logs saved successfully and IndexedDB cleared!",allLogsSaveError:"Error occurred while saving all logs.",confirmClearMemory:"Are you sure you want to delete memory logs? IndexedDB logs will be preserved.",memoryLogsCleared:"Memory logs cleared.",memoryClearError:"Error occurred while clearing memory logs.",confirmClearAll:"Are you sure you want to delete all logs? (Memory + IndexedDB) This action cannot be undone.",allLogsCleared:"All logs cleared.",allClearError:"Error occurred while clearing logs."},virtualScroll:{enabled:"Virtual scrolling enabled for better performance",disabled:"Virtual scrolling disabled"}},command:{title:"Command Panel",generator:{title:"Modbus Command Generator",slaveId:"Slave ID",functionCode:"Function Code",startAddress:"Start Address",quantity:"Quantity",hexBaseMode:"HEX Base Mode",generateCommand:"Generate Command",addToHistory:"Add to History"},functionCodes:{"01":"01 - Read Coils","02":"02 - Read Discrete Inputs","03":"03 - Read Holding Registers","04":"04 - Read Input Registers","05":"05 - Write Single Coil","06":"06 - Write Single Register","0F":"0F - Write Multiple Coils",10:"10 - Write Multiple Registers"},manual:{title:"Manual Command",input:"Enter HEX data or text",asciiMode:"ASCII Mode",autoCrc:"Auto CRC",preview:"Preview",invalidHex:"Invalid HEX format",enterData:"Enter {{mode}} data above...",hexData:"HEX",textData:"text"},history:{title:"Recent Commands",empty:"No recent commands",remove:"Remove",repeat:"Repeat",clear:"Clear History"},repeat:{title:"Repeat Mode",interval:"Interval (ms)",selectCommands:"Select commands to repeat",minInterval:"Minimum interval: 10ms",noCommandsSelected:"Please check at least one command for periodic sending"},dataValues:{title:"Data Values",coil:"Coil",register:"Reg",add:"Add Value",remove:"Remove"},messages:{commandSent:"Command sent successfully",commandFailed:"Failed to send command",invalidCommand:"Invalid command format",notConnected:"Not connected",validCoilValues:"Please enter valid coil values for Function Code 0F",validRegisterValues:"Please enter valid register values for Function Code 10",atLeastOneValue:"At least one {{type}} is required for {{functionCode}}",coil:"coil",register:"register"}},modbus:{analysis:"Modbus Protocol Analysis",rtu:"RTU",tcp:"TCP",pdu:"PDU",mbap:"MBAP Header",crc:"CRC",slaveId:"Slave ID",functionCode:"Function Code",address:"Address",quantity:"Quantity",data:"Data",byteCount:"Byte Count",coilStatus:"Coil Status",registerValue:"Register Value",protocol:{tcpPdu:"MODBUS TCP PDU (will be wrapped in MBAP header)",crcAdded:"+CRC: {{bytes}} bytes total",mbapAdded:"+MBAP: {{bytes}} bytes total"},errors:{"01":"Illegal Function","02":"Illegal Data Address","03":"Illegal Data Value","04":"Slave Device Failure","05":"Acknowledge","06":"Slave Device Busy","08":"Memory Parity Error","0A":"Gateway Path Unavailable","0B":"Gateway Target Device Failed to Respond"}},errors:{general:"An unexpected error occurred",network:"Network connection error",timeout:"Operation timed out",invalidInput:"Invalid input",fileNotFound:"File not found",permissionDenied:"Permission denied",serialPortBusy:"Serial port is busy",serialPortNotFound:"Serial port not found",nativeHostError:"Native messaging host error",unknownError:"Unknown error occurred"}},N={app:{title:"Modbus 프로토콜 분석기",subtitle:"실시간 Modbus RTU/TCP 통신 모니터링 및 분석 도구"},common:{connect:"연결",disconnect:"연결 해제",send:"전송",clear:"지우기",export:"내보내기",import:"가져오기",save:"저장",cancel:"취소",ok:"확인",close:"닫기",yes:"예",no:"아니오",loading:"로딩 중...",error:"오류",warning:"경고",info:"정보",success:"성공",reset:"초기화",start:"시작",stop:"정지",pause:"일시정지",resume:"재개",enabled:"활성화",disabled:"비활성화",settings:"설정",language:"언어",theme:"테마",dark:"다크",light:"라이트"},panel:{position:"패널 위치",top:"상단",left:"좌측",right:"우측",hide:"패널 숨기기",show:"패널 보이기",visibility:"패널 표시",layout:"메인 레이아웃",commandLeft:"명령 창 좌측",commandRight:"명령 창 우측"},connection:{title:"연결",connected:"연결됨",disconnected:"연결 안됨",connecting:"연결 중...",connectionError:"연결 오류",type:"연결 타입",rtu:{title:"RTU (시리얼)",port:"시리얼 포트",selectPort:"포트 선택",noPortSelected:"포트가 선택되지 않음",baudRate:"보드레이트",parity:"패리티",dataBits:"데이터 비트",stopBits:"스톱 비트",none:"없음",even:"짝수",odd:"홀수"},tcp:{title:"TCP",host:"호스트",port:"포트",timeout:"타임아웃 (ms)",autoReconnect:"자동 재연결",reconnectInterval:"재연결 간격 (초)"},messages:{selectPortFirst:"먼저 시리얼 포트를 선택해주세요",connectionFailed:"연결에 실패했습니다",connectionSuccess:"성공적으로 연결되었습니다",disconnectSuccess:"연결이 해제되었습니다",portNotAvailable:"선택한 포트를 사용할 수 없습니다",nativeHostNotAvailable:"Native messaging 호스트를 사용할 수 없습니다"},status:{nativeProxyConnected:"Native Proxy 연결됨",nativeProxyConnecting:"Native Proxy 연결 중...",nativeProxyFailed:"Native Proxy 연결 실패",nativeProxyDisconnected:"Native Proxy 연결 해제",tcpNativeConnected:"TCP 연결됨",tcpNativeConnecting:"TCP 연결 중...",tcpNativeFailed:"TCP 연결 실패",tcpNativeDisconnected:"TCP 연결 해제",connectedTo:"연결됨:",connectingTo:"연결 중:",failedToConnect:"연결 실패:",lastAttempted:"마지막 시도:",noConnectionAttempted:"연결 시도 없음"},nativeGuide:{title:"Native TCP 설치 가이드",connected:"Native Host가 정상적으로 연결되었습니다!",notConnected:"Native Host 설치가 필요합니다",connectedDesc:"TCP 기능을 사용할 수 있습니다. 아래는 추가 설정 및 문제해결 방법입니다.",notConnectedDesc:"TCP 기능을 사용하려면 아래 단계를 따라 설치해주세요.",whyNeeded:"왜 별도 설치가 필요한가요?",browserSecurity:"브라우저 보안 제한: Chromium 기반 브라우저는 보안상 직접 TCP 연결을 할 수 없습니다.",webSerialVsTcp:"Web Serial vs TCP:",rtuSerial:"RTU (시리얼) → 브라우저 내장 Web Serial API 사용 ✅",tcpNative:"TCP → 외부 프로그램(Native Host) 필요 📦",nativeHostRole:"Native Host 역할: 확장과 TCP 장치 사이의 브리지 역할을 합니다.",supportedBrowsers:"지원 브라우저: Chrome, Edge, Brave, Opera, Vivaldi 등 모든 Chromium 기반 브라우저",simpleInstall:"간단 설치",step1:"OS별 설치 패키지 다운로드",step1Desc:"실행파일 + 설치스크립트가 포함된 압축파일",step2:"압축 해제 후 설치 실행",macosLinux:"macOS/Linux: 압축 해제 → ./install-*.sh",windows:"Windows: 압축 해제 → install-windows.bat 더블클릭",autoDetect:"💡 Extension ID 자동 감지, 모든 브라우저 자동 설치",step3:"브라우저 재시작",step3Desc:"사용 중인 브라우저를 완전히 종료 후 다시 실행하세요",extensionId:"현재 Extension ID",extensionIdDesc:"이 ID가 설치 스크립트에 자동으로 설정됩니다.",installationConfirm:"설치 완료 확인",installationConfirmDesc:'설치가 완료되면 위의 "Native Proxy" 상태가 "🟢 Connected"로 변경됩니다.',troubleshooting:"문제 해결",confirm:"확인",troubleshootingItems:["실행파일에 실행 권한이 있는지 확인 (macOS/Linux)","Windows에서 바이러스 검사기가 차단하지 않는지 확인","Extension ID가 정확히 설정되었는지 확인","브라우저를 완전히 재시작 (Chrome, Edge, Brave 등)","다른 Chromium 기반 브라우저에서도 테스트해보기"],clickToInstall:"클릭하여 설치 가이드 보기",clickToGuide:"클릭하여 설치/설정 가이드 보기",installGuide:"💡 설치하기",guideInfo:"ℹ️ 가이드",clickToInstallTooltip:"↑ 클릭하여 설치하세요!",reinstallTooltip:"↑ 재설치/문제해결",downloadManually:"다운로드 링크를 수동으로 열어주세요: ",troubleshootingTitle:"& 문제해결"}},log:{title:"통신 로그",count:"{{count}}개 로그",autoScroll:"자동 스크롤",clearLogs:"로그 지우기",exportLogs:"로그 내보내기",logSettings:"로그 설정",filter:"필터",search:"검색",timestamp:"시간",direction:"방향",data:"데이터",send:"송신",recv:"수신",error:"오류",responseTime:"응답 시간",export:{title:"로그 데이터 내보내기",format:"형식",json:"JSON",csv:"CSV",txt:"텍스트",dateRange:"날짜 범위",allLogs:"모든 로그",customRange:"사용자 지정 범위",from:"시작",to:"끝"},settings:{title:"로그 관리 설정",memoryManagement:"메모리 관리",bufferSize:"버퍼 크기",segmentSize:"세그먼트 크기",autoExport:"자동 내보내기",exportThreshold:"내보내기 임계값 (%)",statistics:"메모리 통계",memoryLogs:"메모리 로그",totalLogs:"전체 로그",exportedFiles:"내보낸 파일",memoryUsage:"메모리 사용량",bufferUtilization:"버퍼 사용률",indexedDBLogs:"IndexedDB 로그",indexedDBSize:"IndexedDB 크기",memoryEfficiency:"메모리 효율성",allocatedSegments:"할당된 세그먼트",cleanup:"메모리 정리",reset:"모든 설정 초기화",bufferSizeDesc:"메모리에 보관할 최대 로그 수 (초과시 파일로 저장)",exportFormatDesc:"오버플로우 시 저장될 파일 형식",circularBufferInfo:"순환 버퍼 + IndexedDB 저장",circularBufferDesc:"설정한 버퍼 크기만큼 메모리에 보관하고, 초과된 로그는 즉시 IndexedDB에 저장됩니다.",indexedDBInfo:"IndexedDB 오버플로우 저장",indexedDBDesc:"메모리 버퍼를 초과한 로그는 자동으로 IndexedDB에 저장됩니다. 전체 로그 저장 시 IndexedDB가 초기화됩니다.",actions:"작업",clearAllLogsWithDB:"전체 로그 지우기 (DB 포함)",settingsSaved:"설정이 저장되었습니다!",settingsSaveError:"설정 저장 중 오류가 발생했습니다.",memoryLogsSaved:"메모리 로그가 성공적으로 저장되었습니다!",memoryLogsSaveError:"메모리 로그 저장 중 오류가 발생했습니다.",allLogsSaved:"전체 로그가 성공적으로 저장되고 IndexedDB가 초기화되었습니다!",allLogsSaveError:"전체 로그 저장 중 오류가 발생했습니다.",confirmClearMemory:"메모리 로그를 삭제하시겠습니까? IndexedDB 로그는 유지됩니다.",memoryLogsCleared:"메모리 로그가 삭제되었습니다.",memoryClearError:"메모리 로그 삭제 중 오류가 발생했습니다.",confirmClearAll:"모든 로그를 삭제하시겠습니까? (메모리 + IndexedDB) 이 작업은 되돌릴 수 없습니다.",allLogsCleared:"모든 로그가 삭제되었습니다.",allClearError:"로그 삭제 중 오류가 발생했습니다."},virtualScroll:{enabled:"성능 향상을 위해 가상 스크롤링이 활성화되었습니다",disabled:"가상 스크롤링이 비활성화되었습니다"}},command:{title:"명령 패널",generator:{title:"Modbus 명령 생성기",slaveId:"슬레이브 ID",functionCode:"펑션 코드",startAddress:"시작 주소",quantity:"수량",hexBaseMode:"HEX 베이스 모드",generateCommand:"명령 생성",addToHistory:"히스토리에 추가"},functionCodes:{"01":"01 - 코일 읽기","02":"02 - 이산 입력 읽기","03":"03 - 홀딩 레지스터 읽기","04":"04 - 입력 레지스터 읽기","05":"05 - 단일 코일 쓰기","06":"06 - 단일 레지스터 쓰기","0F":"0F - 다중 코일 쓰기",10:"10 - 다중 레지스터 쓰기"},manual:{title:"수동 명령",input:"HEX 데이터 또는 텍스트 입력",asciiMode:"ASCII 모드",autoCrc:"자동 CRC",preview:"미리보기",invalidHex:"잘못된 HEX 형식",enterData:"위에 {{mode}} 데이터를 입력하세요...",hexData:"HEX",textData:"텍스트"},history:{title:"최근 명령",empty:"최근 명령이 없습니다",remove:"제거",repeat:"반복",clear:"히스토리 지우기"},repeat:{title:"반복 모드",interval:"간격 (ms)",selectCommands:"반복할 명령 선택",minInterval:"최소 간격: 10ms",noCommandsSelected:"주기적 전송을 위해 최소 하나의 명령을 선택해주세요"},dataValues:{title:"데이터 값",coil:"코일",register:"레지스터",add:"값 추가",remove:"제거"},messages:{commandSent:"명령이 성공적으로 전송되었습니다",commandFailed:"명령 전송에 실패했습니다",invalidCommand:"잘못된 명령 형식입니다",notConnected:"연결되지 않았습니다",validCoilValues:"펑션 코드 0F에 대한 유효한 코일 값을 입력해주세요",validRegisterValues:"펑션 코드 10에 대한 유효한 레지스터 값을 입력해주세요",atLeastOneValue:"{{functionCode}}에는 최소 하나의 {{type}}이 필요합니다",coil:"코일",register:"레지스터"}},modbus:{analysis:"Modbus 프로토콜 분석",rtu:"RTU",tcp:"TCP",pdu:"PDU",mbap:"MBAP 헤더",crc:"CRC",slaveId:"슬레이브 ID",functionCode:"펑션 코드",address:"주소",quantity:"수량",data:"데이터",byteCount:"바이트 수",coilStatus:"코일 상태",registerValue:"레지스터 값",protocol:{tcpPdu:"MODBUS TCP PDU (MBAP 헤더로 래핑됨)",crcAdded:"+CRC: 총 {{bytes}}바이트",mbapAdded:"+MBAP: 총 {{bytes}}바이트"},errors:{"01":"잘못된 펑션","02":"잘못된 데이터 주소","03":"잘못된 데이터 값","04":"슬레이브 장치 오류","05":"확인","06":"슬레이브 장치 사용 중","08":"메모리 패리티 오류","0A":"게이트웨이 경로 사용 불가","0B":"게이트웨이 대상 장치 응답 실패"}},errors:{general:"예상치 못한 오류가 발생했습니다",network:"네트워크 연결 오류",timeout:"작업 시간 초과",invalidInput:"잘못된 입력",fileNotFound:"파일을 찾을 수 없습니다",permissionDenied:"권한이 거부되었습니다",serialPortBusy:"시리얼 포트가 사용 중입니다",serialPortNotFound:"시리얼 포트를 찾을 수 없습니다",nativeHostError:"Native messaging 호스트 오류",unknownError:"알 수 없는 오류가 발생했습니다"}};class S{constructor(){this.currentLanguage="en",this.translations={en:{},ko:{}},this.changeListeners=[],this.loadLanguagePreference()}static getInstance(){return S.instance||(S.instance=new S),S.instance}initialize(e){this.translations=e}getCurrentLanguage(){return this.currentLanguage}setLanguage(e){this.currentLanguage!==e&&(this.currentLanguage=e,this.saveLanguagePreference(),this.notifyLanguageChange())}t(e,t){const n=this.getNestedTranslation(e,this.currentLanguage);if(n)return Array.isArray(n)?n:this.interpolateParams(n,t);if(this.currentLanguage!=="en"){const s=this.getNestedTranslation(e,"en");if(s)return Array.isArray(s)?s:this.interpolateParams(s,t)}return console.warn(`Translation not found: ${e}`),e}tArray(e){const t=this.getNestedTranslation(e,this.currentLanguage);if(t&&Array.isArray(t))return t;if(this.currentLanguage!=="en"){const n=this.getNestedTranslation(e,"en");if(n&&Array.isArray(n))return n}return console.warn(`Translation array not found: ${e}`),[]}tString(e,t){const n=this.getNestedTranslation(e,this.currentLanguage);if(n&&typeof n=="string")return this.interpolateParams(n,t);if(this.currentLanguage!=="en"){const s=this.getNestedTranslation(e,"en");if(s&&typeof s=="string")return this.interpolateParams(s,t)}return console.warn(`Translation string not found: ${e}`),e}getNestedTranslation(e,t){const n=e.split(".");let s=this.translations[t];for(const o of n)if(s&&typeof s=="object"&&o in s)s=s[o];else return null;return typeof s=="string"||Array.isArray(s)?s:null}interpolateParams(e,t){return t?e.replace(/\{\{(\w+)\}\}/g,(n,s)=>t[s]?.toString()||n):e}loadLanguagePreference(){try{const t=localStorage.getItem("modbus-analyzer-language");if(t&&(t==="en"||t==="ko")){this.currentLanguage=t;return}}catch(t){console.warn("Failed to load language preference:",t)}navigator.language.toLowerCase().startsWith("ko")?this.currentLanguage="ko":this.currentLanguage="en"}saveLanguagePreference(){try{localStorage.setItem("modbus-analyzer-language",this.currentLanguage)}catch(e){console.warn("Failed to save language preference:",e)}}onLanguageChange(e){this.changeListeners.push(e)}removeLanguageChangeListener(e){const t=this.changeListeners.indexOf(e);t>-1&&this.changeListeners.splice(t,1)}notifyLanguageChange(){this.changeListeners.forEach(e=>{try{e(this.currentLanguage)}catch(t){console.error("Error in language change listener:",t)}})}getAvailableLanguages(){return[{code:"en",name:"English",nativeName:"English"},{code:"ko",name:"Korean",nativeName:"한국어"}]}}const a=S.getInstance();a.initialize({en:M,ko:N});class A{constructor(e,t){this.activeTab="RTU",this.selectedPort=null,this.grantedPorts=[],this.isCompactMode=!1,this.tcpNativeStatus="disconnected",this.nativeProxyStatus="disconnected",this.currentNativeConfig=null,this.manualDisconnect=!1,this.currentTheme="light",this.handleTabClick=n=>{const o=n.target.dataset.tab;this.switchTab(o)},this.handleConnectClick=()=>{console.log("Connect button clicked"),this.handleConnect()},this.handleDisconnectClick=()=>{this.handleDisconnect()},this.handleForceCloseClick=()=>{this.handleForceClose()},this.onConnectionChange=e,this.onDataReceived=t,this.serialService=new y,this.tcpNativeService=new D,this.setupTcpNativeHandlers()}setupTcpNativeHandlers(){this.tcpNativeService.onConnectionChange((e,t)=>{console.log(`TCP Native connection change: connected=${e}, error=${t}`),e?(console.log("✅ TCP Native connected successfully"),this.tcpNativeStatus="connected",this.onConnectionChange("connected",this.getCurrentConfig()),this.updateButtonStates(!0),this.updateStatusDisplayOnly()):(console.log("TCP Native disconnected",t?`: ${t}`:""),this.manualDisconnect?(console.log("Manual disconnect - not triggering reconnection"),this.tcpNativeStatus="disconnected"):this.tcpNativeStatus=t?"error":"disconnected",this.onConnectionChange(t?"error":"disconnected"),this.updateButtonStates(!1),this.updateStatusDisplayOnly(),this.updatePanelBackground())}),this.tcpNativeService.onData(e=>{console.log("Received from TCP Native:",e),this.onDataReceived&&this.onDataReceived(e)}),this.tcpNativeService.onError(e=>{console.error("TCP Native error:",e),this.updateStatusDisplayOnly()}),this.tcpNativeService.onProxyStatus(e=>{this.nativeProxyStatus=e?"connected":"disconnected",this.updateStatusDisplayOnly()})}updateStatusDisplayOnly(){setTimeout(()=>{this.activeTab==="TCP_NATIVE"&&this.updateStatusIndicators()},0)}async mount(e){await this.loadGrantedPorts(),e.innerHTML=this.render(),this.attachEventListeners()}render(){return`
      <div class="space-y-4">
        <!-- Tab Navigation -->
        <div class="flex border-b ${this.getThemeClasses().border}">
          <button class="tab-button ${this.activeTab==="RTU"?"active":""}" data-tab="RTU">
            ${a.t("connection.rtu.title")}
          </button>
          <button class="tab-button ${this.activeTab==="TCP_NATIVE"?"active":""}" data-tab="TCP_NATIVE">
            ${a.t("connection.tcp.title")}
          </button>
        </div>

        <!-- Tab Content -->
        <div class="tab-content">
          ${this.activeTab==="RTU"?this.renderRtuTab():this.renderTcpNativeTab()}
        </div>

        <!-- Connection Controls -->
        <div class="flex items-center gap-3 pt-4 border-t ${this.getThemeClasses().border}">
          <button class="btn-primary flex items-center gap-2" id="connect-btn">
            <span id="connect-btn-text">${a.t("common.connect")}</span>
            <div id="connect-spinner" class="hidden animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
          </button>
          <button class="btn-secondary" id="disconnect-btn" disabled>
            ${a.t("common.disconnect")}
          </button>
          ${y.isSupported()&&this.selectedPort?`
            <button class="btn-secondary text-xs px-2 py-1" id="force-close-btn" title="${a.t("connection.messages.portNotAvailable")}">
              🔧 Force Close
            </button>
          `:""}
        </div>
        
        <!-- Connection Progress Status -->
        <div id="connection-progress" class="hidden p-3 rounded-md bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800">
          <div class="flex items-center gap-2">
            <div class="animate-spin rounded-full h-4 w-4 border-2 border-blue-500 border-t-transparent"></div>
            <span class="text-sm text-blue-700 dark:text-blue-300" id="progress-message">
              Connecting to serial port...
            </span>
          </div>
          <p class="text-xs text-blue-600 dark:text-blue-400 mt-1">
            Waiting for browser permission and port access...
          </p>
        </div>
      </div>
    `}renderRtuTab(){const e=y.isSupported();return`
      <div class="space-y-4">
        <!-- Web Serial API Support Status -->
        <div class="p-3 rounded-md ${e?this.currentTheme==="dark"?"bg-green-900/20 border border-green-500/30":"bg-green-100 border border-green-400":this.currentTheme==="dark"?"bg-red-900/20 border border-red-500/30":"bg-red-100 border border-red-400"}">
          <div class="flex items-center gap-2">
            <div class="w-2 h-2 rounded-full ${e?"bg-green-500":"bg-red-500"}"></div>
            <span class="text-sm font-medium ${this.getStatusTextClass()}">
              ${e?"Web Serial API Supported":"Web Serial API Not Supported"}
            </span>
          </div>
          ${e?"":`
            <p class="text-xs ${this.getStatusMutedTextClass()} mt-1">
              Please use Chrome/Edge 89+ or enable the Web Serial API flag
            </p>
          `}
        </div>

        <div class="${this.isCompactMode?"space-y-4":"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"}">
          <!-- Serial Port Selection -->
          <div class="${this.isCompactMode?"":"lg:col-span-2"}">
            <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
              ${a.t("connection.rtu.port")}
            </label>
            <div class="space-y-2">
              ${e?`
                <div class="flex gap-2">
                  <button class="btn-primary flex-1 ${this.isCompactMode?"text-sm py-1":""}" id="select-port-btn">
                    📍 ${this.isCompactMode?a.t("connection.rtu.port"):a.t("connection.rtu.selectPort")}
                  </button>
                  <button class="btn-secondary ${this.isCompactMode?"text-sm py-1 px-2":""}" id="refresh-ports-btn" title="Refresh granted ports">
                    🔄
                  </button>
                </div>
                
                ${this.grantedPorts.length>0?`
                  <select class="input-field w-full ${this.isCompactMode?"text-sm":""}" id="granted-ports">
                    <option value="">Choose from granted ports...</option>
                    ${this.grantedPorts.map((t,n)=>{const s=t.getInfo(),o=s.usbVendorId&&s.usbProductId?`USB Device (VID: ${s.usbVendorId.toString(16).padStart(4,"0").toUpperCase()}, PID: ${s.usbProductId.toString(16).padStart(4,"0").toUpperCase()})`:`Serial Port ${n+1}`;return`<option value="${n}">${o}</option>`}).join("")}
                  </select>
                `:`
                  <p class="text-xs ${this.getThemeClasses().textMuted}">
                    No previously granted ports. Click "Select Serial Port" to choose a port.
                  </p>
                `}
                
                <div class="text-xs" id="selected-port-info">
                  <div class="flex items-center gap-2">
                    <span class="${this.selectedPort?this.getThemeClasses().textSecondary:this.getThemeClasses().textMuted}">
                      ${this.selectedPort?this.getPortDisplayName(this.selectedPort):a.t("connection.rtu.noPortSelected")}
                    </span>
                    ${this.selectedPort?`
                      <div class="flex items-center gap-1">
                        <div class="w-2 h-2 rounded-full ${this.serialService.getConnectionStatus()?"bg-green-500":"bg-gray-400"}"></div>
                        <span class="text-xs ${this.serialService.getConnectionStatus()?"text-green-400":"text-gray-400"}">
                          ${this.serialService.getConnectionStatus()?a.t("connection.connected"):"Available"}
                        </span>
                      </div>
                    `:""}
                  </div>
                </div>
              `:`
                <select class="input-field w-full" id="serial-port" disabled>
                  <option>Web Serial API not supported</option>
                </select>
              `}
            </div>
          </div>

          <!-- Baud Rate -->
          <div>
            <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
              Baud Rate
            </label>
            <select class="input-field w-full ${this.isCompactMode?"text-sm":""}" id="baud-rate">
              <option value="1200">1200</option>
              <option value="2400">2400</option>
              <option value="4800">4800</option>
              <option value="9600" selected>9600</option>
              <option value="19200">19200</option>
              <option value="38400">38400</option>
              <option value="57600">57600</option>
              <option value="115200">115200</option>
              <option value="230400">230400</option>
              <option value="460800">460800</option>
              <option value="custom">Custom...</option>
            </select>
            <input 
              type="text" 
              class="input-field w-full ${this.isCompactMode?"text-sm":""} mt-2 hidden" 
              id="baud-rate-custom" 
              placeholder="Enter custom baud rate"
              pattern="[0-9]*"
              inputmode="numeric"
            >
          </div>

          <!-- Parity -->
          <div>
            <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
              Parity
            </label>
            <select class="input-field w-full ${this.isCompactMode?"text-sm":""}" id="parity">
              <option value="none" selected>None</option>
              <option value="even">Even</option>
              <option value="odd">Odd</option>
            </select>
          </div>
        </div>
      </div>
    `}renderTcpNativeTab(){return`
      <div class="space-y-4">
        <!-- Native Proxy Status -->
        <div class="p-3 rounded-md ${this.getNativeProxyStatusClass()} tcp-native-proxy-status cursor-pointer hover:bg-opacity-80 transition-colors" 
             title="${this.isNativeProxyFailed()?a.t("connection.nativeGuide.clickToInstall"):a.t("connection.nativeGuide.clickToGuide")}">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <div class="w-2 h-2 rounded-full ${this.getNativeProxyIndicatorClass()} status-indicator"></div>
              <span class="text-sm font-medium status-text ${this.getStatusTextClass()}">
                ${this.getNativeProxyStatusText()}
              </span>
            </div>
            <div class="text-xs opacity-75 ${this.getStatusMutedTextClass()}">
              ${this.isNativeProxyFailed()?a.t("connection.nativeGuide.installGuide"):a.t("connection.nativeGuide.guideInfo")}
            </div>
          </div>
          <div class="text-xs ${this.getStatusMutedTextClass()} mt-1">
            <div class="flex items-center justify-between">
              <span class="${this.isCompactMode?"truncate":""}">Native Host: com.my_company.stdio_proxy</span>
            </div>
            ${this.isNativeProxyFailed()?`<div class="text-yellow-400 animate-pulse text-center mt-1">${a.t("connection.nativeGuide.clickToInstallTooltip")}</div>`:`<div class="text-gray-400 text-center mt-1">${a.t("connection.nativeGuide.reinstallTooltip")}</div>`}
          </div>
        </div>

        <!-- TCP Native Connection Status -->
        <div class="p-3 rounded-md ${this.getTcpNativeStatusClass()} tcp-native-connection-status">
          <div class="flex items-center gap-2">
            <div class="w-2 h-2 rounded-full ${this.getTcpNativeIndicatorClass()} status-indicator"></div>
            <span class="text-sm font-medium status-text">
              ${this.getTcpNativeStatusText()}
            </span>
          </div>
          <p class="text-xs ${this.getThemeClasses().textMuted} mt-1 status-detail">
            ${this.getTcpNativeStatusDetail()}
          </p>
        </div>

        <!-- TCP Connection Settings -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
              ${a.t("connection.tcp.host")}
            </label>
            <input 
              type="text" 
              class="input-field w-full" 
              id="tcp-native-host"
              placeholder="192.168.1.100"
              value="127.0.0.1"
            />
          </div>

          <div>
            <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
              ${a.t("connection.tcp.port")}
            </label>
            <input 
              type="number" 
              class="input-field w-full" 
              id="tcp-native-port"
              placeholder="5020"
              value="5020"
              min="1"
              max="65535"
            />
          </div>
        </div>
      </div>
    `}attachEventListeners(){this.removeEventListeners(),document.querySelectorAll("[data-tab]").forEach(r=>{r.addEventListener("click",this.handleTabClick)});const t=document.getElementById("connect-btn"),n=document.getElementById("disconnect-btn"),s=document.getElementById("force-close-btn");t?.addEventListener("click",this.handleConnectClick),n?.addEventListener("click",this.handleDisconnectClick),s?.addEventListener("click",this.handleForceCloseClick);const o=document.getElementById("baud-rate"),i=document.getElementById("baud-rate-custom");if(o?.addEventListener("change",()=>{o.value==="custom"?(i?.classList.remove("hidden"),i?.focus()):i?.classList.add("hidden")}),this.activeTab==="RTU"&&y.isSupported()){const r=document.getElementById("select-port-btn"),l=document.getElementById("refresh-ports-btn"),d=document.getElementById("granted-ports");r?.addEventListener("click",()=>this.handleSelectPort()),l?.addEventListener("click",()=>this.handleRefreshPorts()),d?.addEventListener("change",u=>{const g=parseInt(u.target.value);!isNaN(g)&&this.grantedPorts[g]&&(this.selectedPort=this.grantedPorts[g],this.updateSelectedPortInfo())})}this.activeTab==="TCP_NATIVE"&&document.querySelector(".tcp-native-proxy-status")?.addEventListener("click",()=>{this.showNativeHostInstallGuide()})}switchTab(e){if(this.activeTab===e)return;this.activeTab=e;const t=document.querySelector(".tab-content");t&&(t.innerHTML=e==="RTU"?this.renderRtuTab():this.renderTcpNativeTab(),this.attachEventListeners());const n=this.tcpNativeStatus==="connected"||this.serialService.getConnectionStatus()?"connected":"disconnected";this.onConnectionChange(n,{type:e}),document.querySelectorAll(".tab-button").forEach(s=>{s.classList.remove("active")}),document.querySelector(`[data-tab="${e}"]`)?.classList.add("active"),this.updatePanelBackground(),e==="TCP_NATIVE"&&!this.tcpNativeService.isProxyReady()&&!this.manualDisconnect&&(console.log("TCP Native tab selected, connecting to native proxy..."),this.nativeProxyStatus="connecting",this.updateTcpNativeStatusDisplay(),this.tcpNativeService.init().then(()=>{console.log("Native proxy connected successfully"),this.nativeProxyStatus="connected",this.updateTcpNativeStatusDisplay()}).catch(s=>{console.error("Native proxy connection failed:",s),this.nativeProxyStatus="error",this.updateTcpNativeStatusDisplay()}))}async loadGrantedPorts(){if(y.isSupported())try{this.grantedPorts=await this.serialService.getGrantedPorts()}catch(e){console.error("Failed to load granted ports:",e),this.grantedPorts=[]}}async handleSelectPort(){if(!y.isSupported()){alert("Web Serial API is not supported in this browser");return}try{this.serialService.getConnectionStatus()&&(await this.serialService.disconnect(),this.onConnectionChange("disconnected"),this.updateButtonStates(!1),this.updatePanelBackground());const e=await this.serialService.requestPort();this.selectedPort=e,await this.loadGrantedPorts(),this.refreshUI(),this.updateSelectedPortInfo()}catch(e){if(console.error("Failed to select port:",e),e instanceof Error){if(e.message.includes("No serial port was selected"))return;alert(`Failed to select port: ${e.message}`)}}}async handleRefreshPorts(){await this.loadGrantedPorts(),this.refreshUI()}updateSelectedPortInfo(){const e=document.getElementById("selected-port-info");if(e){const t=this.serialService.getConnectionStatus();e.innerHTML=`
        <div class="flex items-center gap-2">
          <span class="${this.selectedPort?"text-dark-text-secondary":"text-dark-text-muted"}">
            ${this.selectedPort?this.getPortDisplayName(this.selectedPort):"No port selected"}
          </span>
          ${this.selectedPort?`
            <div class="flex items-center gap-1">
              <div class="w-2 h-2 rounded-full ${t?"bg-green-500":"bg-gray-400"}"></div>
              <span class="text-xs ${t?"text-green-400":"text-gray-400"}">
                ${t?"Connected":"Available"}
              </span>
            </div>
          `:""}
        </div>
      `}}getPortDisplayName(e){const t=e.getInfo();return t.usbVendorId&&t.usbProductId?`USB Device (VID: ${t.usbVendorId.toString(16).padStart(4,"0").toUpperCase()}, PID: ${t.usbProductId.toString(16).padStart(4,"0").toUpperCase()})`:"Serial Port"}refreshUI(){if(this.activeTab==="RTU"){const e=document.querySelector(".tab-content");e&&(e.innerHTML=this.renderRtuTab(),this.attachEventListeners())}}async handleConnect(){this.activeTab==="RTU"?await this.handleRtuConnect():this.activeTab==="TCP_NATIVE"&&await this.handleTcpNativeConnect()}async handleRtuConnect(){if(!y.isSupported()){alert("Web Serial API is not supported in this browser");return}if(!this.selectedPort){alert("Please select a serial port first");return}if(this.serialService.getConnectionStatus()){alert("Already connected to a serial port. Disconnect first to reconnect.");return}if(this.serialService.getConnectionProgress()){this.showConnectionProgress("Connection already in progress..."),console.log("Connection attempt ignored: already in progress");return}this.showConnectionProgress("Initializing connection..."),this.updateButtonStates(!1,!0),this.onConnectionChange("connecting");try{const e=this.getCurrentConfig(),t={baudRate:e.serial.baudRate,dataBits:e.serial.dataBits,stopBits:e.serial.stopBits,parity:e.serial.parity};this.updateProgressMessage("Requesting port access permission..."),await new Promise(n=>setTimeout(n,500)),this.updateProgressMessage("Opening serial port..."),await this.serialService.connect(this.selectedPort,t),this.hideConnectionProgress(),this.onConnectionChange("connected",e),this.updateButtonStates(!0,!1),this.updateSelectedPortInfo(),this.updatePanelBackground(),this.startDataReading()}catch(e){console.error("Connection failed:",e),this.hideConnectionProgress(),this.updateButtonStates(!1,!1),this.onConnectionChange("error"),this.updatePanelBackground(),setTimeout(()=>{this.onConnectionChange("disconnected"),this.updateSelectedPortInfo(),this.updatePanelBackground()},2e3),e instanceof Error&&(e.message.includes("already open")?alert(`Connection failed: ${e.message}

Tip: Try refreshing the page or disconnecting other applications using this port.`):alert(`Connection failed: ${e.message}`))}}async handleTcpNativeConnect(){if(this.tcpNativeStatus==="connected"){console.log("Already connected to TCP Native, ignoring duplicate request");return}if(this.tcpNativeStatus==="connecting"){console.log("TCP Native connection already in progress");return}this.manualDisconnect=!1,this.tcpNativeStatus="connecting",this.nativeProxyStatus!=="connected"&&(this.nativeProxyStatus="connecting"),this.onConnectionChange("connecting"),this.updateButtonStates(!1,!0),this.updateTcpNativeStatusDisplay();try{this.tcpNativeService.isProxyReady()||(console.log("🔌 Connecting to native messaging host..."),await this.tcpNativeService.init());const e=this.getCurrentConfig(),t={host:e.tcp.host,port:e.tcp.port};console.log(`🔌 Attempting to connect to TCP device at ${t.host}:${t.port} via native proxy`),this.currentNativeConfig=t,await this.tcpNativeService.connect(t)}catch(e){console.error("TCP Native connection failed:",e),this.tcpNativeStatus="error",this.nativeProxyStatus="error",this.onConnectionChange("error"),this.updateButtonStates(!1,!1),this.updateTcpNativeStatusDisplay(),e instanceof Error&&alert(`TCP Native Connection failed: ${e.message}`)}}async handleDisconnect(){try{this.manualDisconnect=!0,this.activeTab==="RTU"&&this.serialService.getConnectionStatus()?await this.serialService.disconnect():this.activeTab==="TCP_NATIVE"&&this.tcpNativeStatus==="connected"&&this.tcpNativeService.disconnect(!0),this.tcpNativeStatus="disconnected",this.currentNativeConfig=null,this.onConnectionChange("disconnected"),this.updateButtonStates(!1,!1),this.updateSelectedPortInfo(),this.updateTcpNativeStatusDisplay(),this.updatePanelBackground()}catch(e){console.error("Disconnect failed:",e),this.onConnectionChange("disconnected"),this.updateButtonStates(!1,!1),this.updatePanelBackground()}}async handleForceClose(){if(this.selectedPort&&confirm("Force close the selected port? This will attempt to close the port even if it's being used by another application."))try{if(await this.serialService.disconnect(),this.selectedPort.readable!==null||this.selectedPort.writable!==null)try{await this.selectedPort.close()}catch(e){console.warn("Direct port close failed:",e)}this.onConnectionChange("disconnected"),this.updateButtonStates(!1,!1),this.updateSelectedPortInfo(),this.updatePanelBackground(),alert("✅ Port force closed successfully. You can now try to reconnect.")}catch(e){console.error("Force close failed:",e),alert(`❌ Force close failed: ${e instanceof Error?e.message:e}`)}}startDataReading(){this.serialService.getConnectionStatus()&&this.serialService.startReading(e=>{const t=y.uint8ArrayToHex(e);this.onDataReceived&&this.onDataReceived(t)},e=>{console.error("Serial read error:",e),this.onConnectionChange("error")})}getCurrentConfig(){if(this.activeTab==="RTU"){const e=document.getElementById("baud-rate")?.value||"9600",t=document.getElementById("baud-rate-custom")?.value||"9600",n=parseInt(e==="custom"?t:e),s=document.getElementById("parity")?.value||"none";return{type:"RTU",serial:{port:this.selectedPort,portName:this.selectedPort?this.getPortDisplayName(this.selectedPort):"No port selected",baudRate:n,parity:s,dataBits:8,stopBits:1}}}else if(this.activeTab==="TCP_NATIVE"){const e=document.getElementById("tcp-native-host")?.value||"127.0.0.1",t=parseInt(document.getElementById("tcp-native-port")?.value||"5020");return{type:"TCP_NATIVE",tcp:{host:e,port:t}}}}showConnectionProgress(e){const t=document.getElementById("connection-progress"),n=document.getElementById("progress-message"),s=document.getElementById("connect-spinner"),o=document.getElementById("connect-btn-text");t&&t.classList.remove("hidden"),n&&(n.textContent=e),s&&s.classList.remove("hidden"),o&&(o.textContent="Connecting...")}updateProgressMessage(e){const t=document.getElementById("progress-message");t&&(t.textContent=e)}removeEventListeners(){document.querySelectorAll("[data-tab]").forEach(o=>{o.removeEventListener("click",this.handleTabClick)});const t=document.getElementById("connect-btn"),n=document.getElementById("disconnect-btn"),s=document.getElementById("force-close-btn");t?.removeEventListener("click",this.handleConnectClick),n?.removeEventListener("click",this.handleDisconnectClick),s?.removeEventListener("click",this.handleForceCloseClick)}isNativeProxyFailed(){return this.nativeProxyStatus==="error"||this.nativeProxyStatus==="disconnected"}showNativeHostInstallGuide(){const e=chrome?.runtime?.id||"YOUR_EXTENSION_ID",t=!this.isNativeProxyFailed(),n=t?`🔌 ${a.t("connection.nativeGuide.title")} ${a.t("connection.nativeGuide.troubleshootingTitle")}`:`🔌 ${a.t("connection.nativeGuide.title")}`,s=`
      <div id="native-install-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="${this.getThemeClasses().panelBg} border ${this.getThemeClasses().border} rounded-lg p-6 max-w-2xl max-h-[90vh] overflow-y-auto m-4">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-semibold ${this.getThemeClasses().textPrimary}">${n}</h3>
            <button class="modal-close ${this.getThemeClasses().textMuted} hover:${this.getThemeClasses().textPrimary.replace("text-","hover:text-")}" data-modal="native-install-modal">✕</button>
          </div>
          
          ${t?`
            <!-- 연결됨 상태 -->
            <div class="${this.currentTheme==="dark"?"bg-green-900/20 border-green-600/30":"bg-green-100 border-green-400"} border rounded p-4 mb-4">
              <h4 class="text-sm font-medium ${this.currentTheme==="dark"?"text-green-300":"text-green-800"} mb-2">✅ ${a.t("connection.nativeGuide.connected")}</h4>
              <p class="text-sm ${this.currentTheme==="dark"?"text-green-200":"text-green-700"}">
                ${a.t("connection.nativeGuide.connectedDesc")}
              </p>
            </div>
          `:`
            <!-- 연결 안됨 상태 -->
            <div class="${this.currentTheme==="dark"?"bg-red-900/20 border-red-600/30":"bg-red-100 border-red-400"} border rounded p-4 mb-4">
              <h4 class="text-sm font-medium ${this.currentTheme==="dark"?"text-red-300":"text-red-800"} mb-2">❌ ${a.t("connection.nativeGuide.notConnected")}</h4>
              <p class="text-sm ${this.currentTheme==="dark"?"text-red-200":"text-red-700"}">
                ${a.t("connection.nativeGuide.notConnectedDesc")}
              </p>
            </div>
          `}
          
          <div class="space-y-4">
            <!-- 왜 설치가 필요한지 설명 -->
            <div class="${this.currentTheme==="dark"?"bg-blue-900/20 border-blue-600/30":"bg-blue-100 border-blue-400"} border rounded p-4">
              <h4 class="text-sm font-medium ${this.currentTheme==="dark"?"text-blue-300":"text-blue-800"} mb-2">🤔 ${a.t("connection.nativeGuide.whyNeeded")}</h4>
              <div class="text-sm ${this.currentTheme==="dark"?"text-blue-200":"text-blue-700"} space-y-2">
                <p><strong>${a.t("connection.nativeGuide.browserSecurity")}</strong></p>
                <p><strong>${a.t("connection.nativeGuide.webSerialVsTcp")}</strong></p>
                <ul class="list-disc list-inside ml-4 space-y-1">
                  <li>${a.t("connection.nativeGuide.rtuSerial")}</li>
                  <li>${a.t("connection.nativeGuide.tcpNative")}</li>
                </ul>
                <p><strong>${a.t("connection.nativeGuide.nativeHostRole")}</strong></p>
                <p><strong>${a.t("connection.nativeGuide.supportedBrowsers")}</strong></p>
              </div>
            </div>

            <!-- 설치 단계 -->
            <div class="${this.getThemeClasses().panelBg} border ${this.getThemeClasses().border} rounded p-4">
              <h4 class="text-sm font-medium ${this.getThemeClasses().textPrimary} mb-3">📋 ${a.t("connection.nativeGuide.simpleInstall")}</h4>
              
              <div class="space-y-3">
                <div class="flex items-start gap-3">
                  <span class="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">1</span>
                  <div>
                    <p class="text-sm font-medium ${this.getThemeClasses().textPrimary}">${a.t("connection.nativeGuide.step1")}</p>
                    <p class="text-xs ${this.getThemeClasses().textMuted} mb-2">${a.t("connection.nativeGuide.step1Desc")}</p>
                    <div class="flex flex-wrap gap-2 mt-2">
                      <button data-download-url="https://github.com/coreanq/release/releases/download/stdio-proxy-v1.0.0/stdio-proxy-macos.zip"
                              class="download-btn bg-gray-600 hover:bg-gray-700 text-white px-3 py-1 rounded text-xs flex items-center gap-1">
                        🍎 macOS (.zip)
                      </button>
                      <button data-download-url="https://github.com/coreanq/release/releases/download/stdio-proxy-v1.0.0/stdio-proxy-windows.zip"
                              class="download-btn bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-xs flex items-center gap-1">
                        🪟 Windows (.zip)
                      </button>
                      <button data-download-url="https://github.com/coreanq/release/releases/download/stdio-proxy-v1.0.0/stdio-proxy-linux.tar.gz"
                              class="download-btn bg-orange-600 hover:bg-orange-700 text-white px-3 py-1 rounded text-xs flex items-center gap-1">
                        🐧 Linux (.tar.gz)
                      </button>
                    </div>
                  </div>
                </div>

                <div class="flex items-start gap-3">
                  <span class="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">2</span>
                  <div>
                    <p class="text-sm font-medium ${this.getThemeClasses().textPrimary}">${a.t("connection.nativeGuide.step2")}</p>
                    <div class="text-sm ${this.getThemeClasses().textSecondary} mt-1 space-y-1">
                      <div><strong>${a.t("connection.nativeGuide.macosLinux")}</strong></div>
                      <div><strong>${a.t("connection.nativeGuide.windows")}</strong></div>
                    </div>
                  </div>
                </div>

                <div class="flex items-start gap-3">
                  <span class="bg-blue-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs">3</span>
                  <div>
                    <p class="text-sm font-medium ${this.getThemeClasses().textPrimary}">${a.t("connection.nativeGuide.step3")}</p>
                    <p class="text-sm ${this.getThemeClasses().textSecondary}">${a.t("connection.nativeGuide.step3Desc")}</p>
                    <p class="text-xs text-gray-400 mt-1">✨ ${a.t("connection.nativeGuide.supportedBrowsers")}</p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Extension ID 정보 -->
            <div class="${this.currentTheme==="dark"?"bg-yellow-900/20 border-yellow-600/30":"bg-yellow-100 border-yellow-400"} border rounded p-3">
              <h4 class="text-sm font-medium ${this.currentTheme==="dark"?"text-yellow-300":"text-yellow-800"} mb-2">🔑 ${a.t("connection.nativeGuide.extensionId")}</h4>
              <div class="${this.getThemeClasses().background} p-2 rounded font-mono text-sm ${this.getThemeClasses().textPrimary} break-all">
                ${e}
              </div>
            </div>

            <!-- 설치 후 확인 -->
            <div class="${this.currentTheme==="dark"?"bg-green-900/20 border-green-600/30":"bg-green-100 border-green-400"} border rounded p-3">
              <h4 class="text-sm font-medium ${this.currentTheme==="dark"?"text-green-300":"text-green-800"} mb-2">✅ ${a.t("connection.nativeGuide.installationConfirm")}</h4>
              <p class="text-sm ${this.currentTheme==="dark"?"text-green-200":"text-green-700"}">
                ${a.t("connection.nativeGuide.installationConfirmDesc")}
              </p>
            </div>

            <!-- 트러블슈팅 -->
            <div class="${this.currentTheme==="dark"?"bg-orange-900/20 border-orange-600/30":"bg-orange-100 border-orange-400"} border rounded p-3">
              <h4 class="text-sm font-medium ${this.currentTheme==="dark"?"text-orange-300":"text-orange-800"} mb-2">🔧 ${a.t("connection.nativeGuide.troubleshooting")}</h4>
              <div class="text-sm ${this.currentTheme==="dark"?"text-orange-200":"text-orange-700"} space-y-1">
                ${a.tArray("connection.nativeGuide.troubleshootingItems").map(o=>`<p>• ${o}</p>`).join("")}
              </div>
            </div>
          </div>

          <div class="flex justify-center mt-6">
            <button class="modal-close bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded text-sm" data-modal="native-install-modal">
              ${a.t("connection.nativeGuide.confirm")}
            </button>
          </div>
        </div>
      </div>
    `;document.getElementById("native-install-modal")?.remove(),document.body.insertAdjacentHTML("beforeend",s),this.attachModalEventListeners()}attachModalEventListeners(){document.querySelectorAll(".download-btn").forEach(s=>{s.addEventListener("click",o=>{o.preventDefault();const i=o.target,r=i.closest("button")?.getAttribute("data-download-url");if(console.log("Download button clicked, URL:",r),r)try{if(chrome&&chrome.tabs&&chrome.tabs.create)chrome.tabs.create({url:r}),console.log("Chrome tabs.create called successfully");else{const l=document.createElement("a");l.href=r,l.download="",l.target="_blank",l.rel="noopener noreferrer",document.body.appendChild(l),l.click(),document.body.removeChild(l),console.log("Fallback download link clicked")}}catch(l){console.error("Failed to open download URL:",l);try{window.location.href=r}catch(d){console.error("All download methods failed:",d),alert(a.t("connection.nativeGuide.downloadManually")+r)}}else console.error("No download URL found for button:",i)})}),document.querySelectorAll(".modal-close").forEach(s=>{s.addEventListener("click",o=>{o.preventDefault();const r=o.target.closest("button")?.getAttribute("data-modal");console.log("Modal close clicked, modalId:",r),r&&document.getElementById(r)?.remove()})}),document.querySelectorAll(".open-folder").forEach(s=>{s.addEventListener("click",o=>{o.preventDefault();const r=o.target.closest("button")?.getAttribute("data-path");console.log("Open folder clicked, path:",r),r&&window.open(r,"_blank")})})}hideConnectionProgress(){const e=document.getElementById("connection-progress"),t=document.getElementById("connect-spinner"),n=document.getElementById("connect-btn-text");e&&e.classList.add("hidden"),t&&t.classList.add("hidden"),n&&(n.textContent="Connect")}updateButtonStates(e,t=!1){const n=document.getElementById("connect-btn"),s=document.getElementById("disconnect-btn");n&&s&&(n.disabled=e||t,s.disabled=!e)}setCompactMode(e){this.isCompactMode=e}getSerialService(){return this.serialService}getTcpNativeService(){return this.tcpNativeService}getNativeProxyStatusClass(){const e=this.currentTheme==="dark";switch(this.nativeProxyStatus){case"connected":return e?"bg-green-900/20 border border-green-500/30":"bg-green-100 border border-green-400";case"connecting":return e?"bg-yellow-900/20 border border-yellow-500/30":"bg-yellow-100 border border-yellow-400";case"error":return e?"bg-red-900/20 border border-red-500/30":"bg-red-100 border border-red-400";default:return e?"bg-gray-900/20 border border-gray-500/30":"bg-gray-100 border border-gray-400"}}getNativeProxyIndicatorClass(){switch(this.nativeProxyStatus){case"connected":return"bg-green-500";case"connecting":return"bg-yellow-500 animate-pulse";case"error":return"bg-red-500";default:return"bg-gray-500"}}getNativeProxyStatusText(){switch(this.nativeProxyStatus){case"connected":return a.tString("connection.status.nativeProxyConnected");case"connecting":return a.tString("connection.status.nativeProxyConnecting");case"error":return a.tString("connection.status.nativeProxyFailed");default:return"Native Proxy Disconnected"}}getTcpNativeStatusClass(){const e=this.currentTheme==="dark";switch(this.tcpNativeStatus){case"connected":return e?"bg-green-900/20 border border-green-500/30":"bg-green-100 border border-green-400";case"connecting":return e?"bg-yellow-900/20 border border-yellow-500/30":"bg-yellow-100 border border-yellow-400";case"error":return e?"bg-red-900/20 border border-red-500/30":"bg-red-100 border border-red-400";default:return e?"bg-gray-900/20 border border-gray-500/30":"bg-gray-100 border border-gray-400"}}getTcpNativeIndicatorClass(){switch(this.tcpNativeStatus){case"connected":return"bg-green-500";case"connecting":return"bg-yellow-500 animate-pulse";case"error":return"bg-red-500";default:return"bg-gray-500"}}getStatusTextClass(){return this.currentTheme==="dark"?"text-dark-text-primary":"text-gray-900"}getStatusMutedTextClass(){return this.currentTheme==="dark"?"text-dark-text-muted":"text-gray-600"}getTcpNativeStatusText(){switch(this.tcpNativeStatus){case"connected":return a.tString("connection.status.tcpNativeConnected");case"connecting":return a.tString("connection.status.tcpNativeConnecting");case"error":return a.tString("connection.status.tcpNativeFailed");default:return a.tString("connection.status.tcpNativeDisconnected")}}getTcpNativeStatusDetail(){return this.currentNativeConfig?`${this.tcpNativeStatus==="connected"?a.tString("connection.status.connectedTo"):this.tcpNativeStatus==="connecting"?a.tString("connection.status.connectingTo"):this.tcpNativeStatus==="error"?a.tString("connection.status.failedToConnect"):a.tString("connection.status.lastAttempted")} ${this.currentNativeConfig.host}:${this.currentNativeConfig.port}`:a.tString("connection.status.noConnectionAttempted")}getPanelBackgroundClass(){return this.activeTab==="TCP_NATIVE"?this.nativeProxyStatus==="connected"&&this.tcpNativeStatus==="connected"?"bg-green-900/10":"bg-red-900/10":this.activeTab==="RTU"?this.serialService.getConnectionStatus()?"bg-green-900/10":"bg-red-900/10":"bg-gray-900/10"}updateTcpNativeStatusDisplay(){this.activeTab==="TCP_NATIVE"&&this.updateStatusIndicators()}updateStatusIndicators(){const e=document.querySelector(".tcp-native-proxy-status");if(e){e.className=`p-3 rounded-md ${this.getNativeProxyStatusClass()} tcp-native-proxy-status cursor-pointer hover:bg-opacity-80 transition-colors`;const n=e.querySelector(".status-indicator"),s=e.querySelector(".status-text");n&&(n.className=`w-2 h-2 rounded-full ${this.getNativeProxyIndicatorClass()} status-indicator`),s&&(s.textContent=this.getNativeProxyStatusText(),s.className=`text-sm font-medium status-text ${this.getStatusTextClass()}`)}const t=document.querySelector(".tcp-native-connection-status");if(t){t.className=`p-3 rounded-md ${this.getTcpNativeStatusClass()} tcp-native-connection-status`;const n=t.querySelector(".status-indicator"),s=t.querySelector(".status-text"),o=t.querySelector(".status-detail");n&&(n.className=`w-2 h-2 rounded-full ${this.getTcpNativeIndicatorClass()} status-indicator`),s&&(s.textContent=this.getTcpNativeStatusText()),o&&(o.textContent=this.getTcpNativeStatusDetail())}this.updatePanelBackground()}updatePanelBackground(){const e=new CustomEvent("panelBackgroundChange");document.dispatchEvent(e)}onLanguageChange(){const e=document.querySelector('[id*="connection-content"]');e&&(e.innerHTML=this.render(),this.attachEventListeners())}cleanup(){(this.tcpNativeService.isProxyReady()||this.tcpNativeService.isTcpConnected())&&this.tcpNativeService.cleanup()}getThemeClasses(){return this.currentTheme==="light"?{background:"bg-gray-50",panelBg:"bg-white",border:"border-gray-200",inputBg:"bg-white",textPrimary:"text-gray-900",textSecondary:"text-gray-800",textMuted:"text-gray-600"}:{background:"bg-dark-bg",panelBg:"bg-dark-surface",border:"border-dark-border",inputBg:"bg-dark-surface",textPrimary:"text-dark-text-primary",textSecondary:"text-dark-text-secondary",textMuted:"text-dark-text-muted"}}onThemeChange(e){this.currentTheme=e,this.updateStatusIndicators(),this.switchTab(this.activeTab)}}class F{constructor(e){this.allLogs=[],this.currentLogFile="",this.currentFileSize=0,this.isWriting=!1,this.config=e||this.getDefaultConfig(),this.initializeLogFile()}getDefaultConfig(){return{mode:"continuous",continuous:{maxFileSize:10,fileNameFormat:"YYYY-MM-DD_HH-mm-ss"},rotation:{maxFileSize:5,maxFiles:10,maxAge:30,compressionEnabled:!0}}}initializeLogFile(){const e=this.formatTimestamp(new Date);this.currentLogFile=`modbus_debug_${e}.log`,this.currentFileSize=0}formatTimestamp(e){const t=e.getFullYear(),n=String(e.getMonth()+1).padStart(2,"0"),s=String(e.getDate()).padStart(2,"0"),o=String(e.getHours()).padStart(2,"0"),i=String(e.getMinutes()).padStart(2,"0"),r=String(e.getSeconds()).padStart(2,"0");return`${t}-${n}-${s}_${o}-${i}-${r}`}formatLogEntry(e){const t=e.timestamp.toISOString(),n=e.direction.toUpperCase(),s=e.data.replace(/\s+/g," ").trim(),o=e.responseTime?` (${e.responseTime}ms)`:"",i=e.error?` [ERROR: ${e.error}]`:"";return`[${t}] ${n}: ${s}${o}${i}
`}async writeToFile(e){if(!this.isWriting)try{this.isWriting=!0,typeof window<"u"&&(this.currentFileSize+=e.length)}finally{this.isWriting=!1}}async rotateLogFile(){this.config.mode==="continuous"?await this.createNewLogFile():(await this.createNewLogFile(),await this.cleanupOldFiles())}async createNewLogFile(){this.currentFileSize>0&&await this.saveCurrentLogFile(),this.initializeLogFile()}async saveCurrentLogFile(){if(typeof window>"u")return;const e=this.generateFileContent(),t=new Blob([e],{type:"text/plain"}),n=URL.createObjectURL(t),s=document.createElement("a");s.href=n,s.download=this.currentLogFile,s.style.display="none",document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(n)}generateFileContent(){return this.allLogs.map(e=>this.formatLogEntry(e)).join("")}async cleanupOldFiles(){this.config.mode!=="rotation"||!this.config.rotation||(console.log("Cleanup would remove files older than",this.config.rotation.maxAge,"days"),console.log("Keeping maximum",this.config.rotation.maxFiles,"files"))}async addLog(e){this.allLogs.push(e);const t=this.formatLogEntry(e);await this.writeToFile(t)}async addLogs(e){this.allLogs.push(...e);const t=e.map(n=>this.formatLogEntry(n)).join("");await this.writeToFile(t)}getDisplayLogs(e=1e3){return this.allLogs.slice(-e)}getAllLogs(){return[...this.allLogs]}getLogCount(){return this.allLogs.length}updateConfig(e){this.config=e}getConfig(){return{...this.config}}clearLogs(){this.allLogs=[],this.initializeLogFile()}async exportLogsAsText(){const e=this.generateFileContent(),n=`modbus_export_${this.formatTimestamp(new Date)}.txt`;this.downloadFile(e,n,"text/plain")}async exportLogsAsCSV(){const e=`Timestamp,Direction,Data,Response Time (ms),Error
`,t=this.allLogs.map(i=>{const r=i.timestamp.toISOString(),l=i.direction,d=`"${i.data.replace(/"/g,'""')}"`,u=i.responseTime||"",g=i.error?`"${i.error.replace(/"/g,'""')}"`:"";return`${r},${l},${d},${u},${g}`}).join(`
`),n=e+t,o=`modbus_export_${this.formatTimestamp(new Date)}.csv`;this.downloadFile(n,o,"text/csv")}downloadFile(e,t,n){const s=new Blob([e],{type:n}),o=URL.createObjectURL(s),i=document.createElement("a");i.href=o,i.download=t,i.style.display="none",document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o)}}class U{constructor(e=1e3){this.head=0,this.tail=0,this.size=0,this.totalCount=0,this.capacity=e,this.buffer=new Array(e)}add(e){let t=null;return this.size===this.capacity?(t=this.buffer[this.tail],this.tail=(this.tail+1)%this.capacity):this.size++,this.buffer[this.head]=e,this.head=(this.head+1)%this.capacity,this.totalCount++,t}getAllLogs(){if(this.size===0)return[];const e=[];for(let t=0;t<this.size;t++){const n=(this.tail+t)%this.capacity;e.push(this.buffer[n])}return e}getRecentLogs(e){return this.getAllLogs().slice(-e)}getLogsInRange(e,t){return this.getAllLogs().slice(e,e+t)}clear(){this.head=0,this.tail=0,this.size=0,this.totalCount=0}resize(e){if(e===this.capacity)return;const t=this.getAllLogs();this.buffer=new Array(e),this.capacity=e,this.head=0,this.tail=0,this.size=0;const n=e<t.length?t.slice(-e):t;for(const s of n)this.add(s)}getStats(){return{capacity:this.capacity,size:this.size,totalCount:this.totalCount,memoryUsage:this.capacity*200}}isFull(){return this.size===this.capacity}isEmpty(){return this.size===0}getUtilization(){return this.size/this.capacity}}class H{constructor(){this.dbName="ModbusLogsDB",this.version=1,this.storeName="overflowLogs",this.db=null,this.initDB()}async initDB(){return new Promise((e,t)=>{const n=indexedDB.open(this.dbName,this.version);n.onerror=()=>{console.error("Failed to open IndexedDB:",n.error),t(n.error)},n.onsuccess=()=>{this.db=n.result,console.log("[IndexedDB] Database opened successfully"),e()},n.onupgradeneeded=s=>{const o=s.target.result;o.objectStoreNames.contains(this.storeName)||(o.createObjectStore(this.storeName,{keyPath:"id",autoIncrement:!1}).createIndex("timestamp","timestamp",{unique:!1}),console.log("[IndexedDB] Object store created"))}})}async ensureDB(){if(this.db||await this.initDB(),!this.db)throw new Error("Failed to initialize IndexedDB");return this.db}async addOverflowLog(e){try{const s=(await this.ensureDB()).transaction([this.storeName],"readwrite").objectStore(this.storeName);await new Promise((o,i)=>{const r=s.add(e);r.onsuccess=()=>o(),r.onerror=()=>i(r.error)})}catch(t){throw console.error("[IndexedDB] Failed to add overflow log:",t),t}}async addOverflowLogs(e){if(e.length!==0)try{const s=(await this.ensureDB()).transaction([this.storeName],"readwrite").objectStore(this.storeName);await new Promise((o,i)=>{let r=0,l=!1;for(const d of e){const u=s.add(d);u.onsuccess=()=>{r++,r===e.length&&!l&&o()},u.onerror=()=>{l||(l=!0,i(u.error))}}})}catch(t){throw console.error("[IndexedDB] Failed to add overflow logs:",t),t}}async getAllOverflowLogs(){try{const s=(await this.ensureDB()).transaction([this.storeName],"readonly").objectStore(this.storeName).index("timestamp");return new Promise((o,i)=>{const r=s.getAll();r.onsuccess=()=>{const l=r.result;l.sort((d,u)=>new Date(d.timestamp).getTime()-new Date(u.timestamp).getTime()),o(l)},r.onerror=()=>i(r.error)})}catch(e){return console.error("[IndexedDB] Failed to get overflow logs:",e),[]}}async getOverflowLogsPaginated(e=0,t=1e3){try{const i=(await this.ensureDB()).transaction([this.storeName],"readonly").objectStore(this.storeName).index("timestamp");return new Promise((r,l)=>{const d=[];let u=0;const g=i.openCursor();g.onsuccess=h=>{const c=h.target.result;if(c){if(u>=e&&(d.push(c.value),d.length>=t)){r(d);return}u++,c.continue()}else r(d)},g.onerror=()=>l(g.error)})}catch(n){return console.error("[IndexedDB] Failed to get paginated overflow logs:",n),[]}}async getOverflowLogCount(){try{const n=(await this.ensureDB()).transaction([this.storeName],"readonly").objectStore(this.storeName);return new Promise((s,o)=>{const i=n.count();i.onsuccess=()=>s(i.result),i.onerror=()=>o(i.error)})}catch(e){return console.error("[IndexedDB] Failed to get overflow log count:",e),0}}async getStats(){try{const e=await this.getOverflowLogCount(),t=await this.getOverflowLogsPaginated(0,10),n=t.length>0?JSON.stringify(t).length/t.length:200,s=e*n/1024/1024;return{totalLogs:e,dbSize:`${s.toFixed(2)} MB`,lastUpdated:e>0?new Date:null}}catch(e){return console.error("[IndexedDB] Failed to get stats:",e),{totalLogs:0,dbSize:"0 MB",lastUpdated:null}}}async clearAllOverflowLogs(){try{const n=(await this.ensureDB()).transaction([this.storeName],"readwrite").objectStore(this.storeName);await new Promise((s,o)=>{const i=n.clear();i.onsuccess=()=>{console.log("[IndexedDB] All overflow logs cleared"),s()},i.onerror=()=>o(i.error)})}catch(e){throw console.error("[IndexedDB] Failed to clear overflow logs:",e),e}}async clearLogsBefore(e){try{const o=(await this.ensureDB()).transaction([this.storeName],"readwrite").objectStore(this.storeName).index("timestamp");let i=0;return new Promise((r,l)=>{const d=IDBKeyRange.upperBound(e.toISOString()),u=o.openCursor(d);u.onsuccess=g=>{const h=g.target.result;h?(h.delete(),i++,h.continue()):(console.log(`[IndexedDB] Deleted ${i} old logs`),r(i))},u.onerror=()=>l(u.error)})}catch(t){return console.error("[IndexedDB] Failed to clear old logs:",t),0}}destroy(){this.db&&(this.db.close(),this.db=null,console.log("[IndexedDB] Database connection closed"))}}class w{constructor(e,t){this.exportedFileCount=0,this.overflowQueue=[],this.flushTimeout=null,this.config={bufferSize:1e4,exportFormat:"json",...e},this.buffer=new U(this.config.bufferSize),this.indexedDBService=new H,this.onLogEvicted=t,this.loadSettings()}loadSettings(){try{const e=localStorage.getItem("modbus-log-config");if(e){const t=JSON.parse(e);this.config={...this.config,...t},this.buffer&&this.buffer.resize(this.config.bufferSize)}}catch(e){console.warn("Failed to load log settings:",e)}}saveSettings(){try{localStorage.setItem("modbus-log-config",JSON.stringify(this.config))}catch(e){console.warn("Failed to save log settings:",e)}}updateConfig(e){const t=this.config.bufferSize;this.config={...this.config,...e},e.bufferSize&&e.bufferSize!==t&&this.buffer&&this.buffer.resize(e.bufferSize),this.saveSettings()}getConfig(){return{...this.config}}async addLog(e){const t=this.buffer.add(e);t&&(this.onLogEvicted&&this.onLogEvicted(t),this.overflowQueue.push(t),this.overflowQueue.length>=100?this.flushOverflowQueue():this.scheduleFlush())}scheduleFlush(){this.flushTimeout&&clearTimeout(this.flushTimeout),this.flushTimeout=setTimeout(()=>{this.flushOverflowQueue()},500)}async flushOverflowQueue(){if(this.flushTimeout&&(clearTimeout(this.flushTimeout),this.flushTimeout=null),this.overflowQueue.length===0)return;const e=[...this.overflowQueue];this.overflowQueue=[];try{await this.indexedDBService.addOverflowLogs(e)}catch(t){console.error("Failed to save bulk overflow logs to IndexedDB:",t)}}async exportAllLogsIncludingIndexedDB(e){try{const t=this.buffer.getAllLogs(),s=[...await this.indexedDBService.getAllOverflowLogs(),...t].sort((i,r)=>new Date(i.timestamp).getTime()-new Date(r.timestamp).getTime());if(s.length===0)throw new Error("No logs to export");const o=e||`modbus_logs_complete_${this.formatTimestamp(new Date)}`;await this.exportToFile(s,o),await this.indexedDBService.clearAllOverflowLogs(),console.log("IndexedDB cleared after export")}catch(t){throw console.error("Failed to export all logs:",t),t}}async getIndexedDBStats(){return await this.indexedDBService.getStats()}getAllLogs(){return this.buffer.getAllLogs()}getRecentLogs(e){return e?this.buffer.getRecentLogs(e):this.buffer.getAllLogs()}getLogsInRange(e,t){return this.buffer.getLogsInRange(e,t)}getTotalCount(){return this.buffer.getStats().totalCount+this.exportedFileCount}getMemoryCount(){return this.buffer.getStats().size}async exportAllLogs(e){const t=this.buffer.getAllLogs();if(t.length===0)throw new Error("No logs to export");const n=e||`modbus_logs_manual_${this.formatTimestamp(new Date)}`;await this.exportToFile(t,n)}async exportToFile(e,t){let n,s,o;switch(this.config.exportFormat){case"csv":n=this.logsToCSV(e),s="text/csv",o=".csv";break;case"txt":n=this.logsToText(e),s="text/plain",o=".txt";break;case"json":default:n=JSON.stringify(e,null,2),s="application/json",o=".json";break}this.downloadFile(n,t+o,s)}logsToCSV(e){const t=["Timestamp","Direction","Data","Error","ResponseTime"],n=e.map(s=>[s.timestamp.toISOString(),s.direction,s.data,s.error||"",s.responseTime?.toString()||""]);return[t,...n].map(s=>s.map(o=>`"${o.toString().replace(/"/g,'""')}"`).join(",")).join(`
`)}logsToText(e){return e.map(t=>{const n=t.timestamp.toISOString(),s=t.direction.toUpperCase(),o=t.error?` [ERROR: ${t.error}]`:"",i=t.responseTime?` (${t.responseTime}ms)`:"";return`${n} ${s}: ${t.data}${o}${i}`}).join(`
`)}downloadFile(e,t,n){const s=new Blob([e],{type:n}),o=URL.createObjectURL(s),i=document.createElement("a");i.href=o,i.download=t,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(o)}formatTimestamp(e){return e.toISOString().replace(/[:.]/g,"-").slice(0,19)}async getStats(){const e=this.buffer.getStats(),t=this.buffer.getAllLogs(),n=(JSON.stringify(t).length/1024/1024).toFixed(2),s=await this.indexedDBService.getStats();return{memoryLogs:e.size||0,totalLogs:(e.totalCount||0)+s.totalLogs,exportedFiles:this.exportedFileCount||0,memoryUsage:`${n} MB`,bufferUtilization:`${(e.size/e.capacity*100).toFixed(1)}%`,indexedDBLogs:s.totalLogs,indexedDBSize:s.dbSize}}getDetailedMemoryStats(){return{buffer:this.buffer.getStats(),config:this.config,exportedFileCount:this.exportedFileCount}}clearLogs(){if(console.log("OptimizedLogService.clearLogs called"),this.onLogEvicted){const e=this.buffer.getAllLogs();for(const t of e)this.onLogEvicted(t)}this.overflowQueue.length>0&&(console.log(`Clearing ${this.overflowQueue.length} overflow logs`),this.overflowQueue=[]),this.flushTimeout&&(clearTimeout(this.flushTimeout),this.flushTimeout=null),this.buffer.clear(),console.log("OptimizedLogService buffer cleared")}async clearAllLogs(){this.clearLogs();try{await this.indexedDBService.clearAllOverflowLogs()}catch(e){console.error("Failed to clear IndexedDB logs:",e)}this.exportedFileCount=0}searchLogs(e,t){return this.buffer.getAllLogs().filter(s=>{const o=!e||s.data.toLowerCase().includes(e.toLowerCase())||s.parsed?.functionCode&&s.parsed.functionCode.toString().toLowerCase().includes(e.toLowerCase()),i=!t?.direction||s.direction===t.direction,r=(!t?.startTime||s.timestamp>=t.startTime)&&(!t?.endTime||s.timestamp<=t.endTime);return o&&i&&r})}async destroy(){await this.flushOverflowQueue(),this.indexedDBService.destroy()}}class ${constructor(e){this.isVisible=!1,this.currentTheme="light",this.logService=e,this.container=this.createSettingsPanel()}setClearCallback(e){console.log("LogSettingsPanel.setClearCallback called"),this.onClearCallback=e,console.log("Callback set successfully:",!!this.onClearCallback)}createSettingsPanel(){const e=document.createElement("div");return e.className="log-settings-panel fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center",e.id="log-settings-panel",e.innerHTML=`
      <div class="${this.getThemeClasses().panelBg} rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto m-4">
        <!-- Header -->
        <div class="flex items-center justify-between p-6 border-b ${this.getThemeClasses().border}">
          <h2 class="text-xl font-semibold ${this.getThemeClasses().textPrimary}">
            📊 ${a.t("log.settings.title")}
          </h2>
          <button id="close-settings" class="${this.getThemeClasses().textMuted} hover:${this.getThemeClasses().textPrimary.replace("text-","hover:text-")}">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </div>

        <!-- Content -->
        <div class="p-6 space-y-6">
          
          <!-- Buffer Settings -->
          <div class="space-y-4">
            <h3 class="text-lg font-medium ${this.getThemeClasses().textPrimary}">🔄 ${a.t("log.settings.memoryManagement")}</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
                  ${a.t("log.settings.bufferSize")}
                </label>
                <input type="number" id="buffer-size" min="100" max="50000" step="100"
                       class="w-full px-3 py-2 border ${this.getThemeClasses().border} rounded-md shadow-sm 
                              focus:ring-blue-500 focus:border-blue-500 ${this.getThemeClasses().inputBg} ${this.getThemeClasses().textPrimary}">
                <p class="text-xs ${this.getThemeClasses().textMuted} mt-1">
                  ${a.t("log.settings.bufferSizeDesc")}
                </p>
              </div>
              
              <div>
                <label class="block text-sm font-medium ${this.getThemeClasses().textSecondary} mb-2">
                  ${a.t("log.export.format")}
                </label>
                <select id="export-format" 
                        class="w-full px-3 py-2 border ${this.getThemeClasses().border} rounded-md shadow-sm 
                               focus:ring-blue-500 focus:border-blue-500 ${this.getThemeClasses().inputBg} ${this.getThemeClasses().textPrimary}">
                  <option value="json">${a.t("log.export.json")}</option>
                  <option value="csv">${a.t("log.export.csv")}</option>
                  <option value="txt">${a.t("log.export.txt")}</option>
                </select>
                <p class="text-xs ${this.getThemeClasses().textMuted} mt-1">
                  ${a.t("log.settings.exportFormatDesc")}
                </p>
              </div>
            </div>

            <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <div class="flex items-start">
                <div class="flex-shrink-0">
                  <svg class="h-5 w-5 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path>
                  </svg>
                </div>
                <div class="ml-3">
                  <h4 class="text-sm font-medium text-blue-800 ${this.currentTheme==="dark"?"dark:text-blue-200":""}">
                    ${a.t("log.settings.circularBufferInfo")}
                  </h4>
                  <p class="text-sm text-blue-700 ${this.currentTheme==="dark"?"dark:text-blue-300":""} mt-1">
                    ${a.t("log.settings.circularBufferDesc")}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Current Stats -->
          <div class="space-y-4">
            <h3 class="text-lg font-medium ${this.getThemeClasses().textPrimary}">📈 ${a.t("log.settings.statistics")}</h3>
            
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div class="${this.getThemeClasses().background} p-3 rounded-lg">
                <div class="text-xl font-bold text-blue-600 dark:text-blue-400" id="stat-memory-logs">-</div>
                <div class="text-xs ${this.getThemeClasses().textMuted}">${a.t("log.settings.memoryLogs")}</div>
              </div>
              
              <div class="${this.getThemeClasses().background} p-3 rounded-lg">
                <div class="text-xl font-bold text-green-600 dark:text-green-400" id="stat-total-logs">-</div>
                <div class="text-xs ${this.getThemeClasses().textMuted}">${a.t("log.settings.totalLogs")}</div>
              </div>

              <div class="${this.getThemeClasses().background} p-3 rounded-lg">
                <div class="text-xl font-bold text-purple-600 dark:text-purple-400" id="stat-indexeddb-logs">-</div>
                <div class="text-xs ${this.getThemeClasses().textMuted}">${a.t("log.settings.indexedDBLogs")}</div>
              </div>
              
              <div class="${this.getThemeClasses().background} p-3 rounded-lg">
                <div class="text-xl font-bold text-orange-600 dark:text-orange-400" id="stat-indexeddb-size">-</div>
                <div class="text-xs ${this.getThemeClasses().textMuted}">${a.t("log.settings.indexedDBSize")}</div>
              </div>
            </div>

          </div>

          <!-- Actions -->
          <div class="space-y-4">
            <h3 class="text-lg font-medium ${this.getThemeClasses().textPrimary}">🔧 ${a.t("log.settings.actions")}</h3>
            
            <div class="flex flex-wrap gap-3">
              <button id="export-memory-logs" 
                      class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 
                             focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">
                📁 ${a.t("log.settings.memoryLogs")} ${a.t("common.save")}
              </button>

              <button id="export-all-logs" 
                      class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 
                             focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-colors">
                💾 ${a.t("log.settings.totalLogs")} ${a.t("common.save")}
              </button>
              
              <button id="clear-logs" 
                      class="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 
                             focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-colors">
                🗑️ ${a.t("log.clearLogs")}
              </button>

              <button id="clear-all-logs" 
                      class="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 
                             focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors">
                🗂️ ${a.t("log.settings.clearAllLogsWithDB")}
              </button>
            </div>
          </div>
        </div>

        <!-- Footer -->
        <div class="flex justify-end space-x-3 p-6 border-t ${this.getThemeClasses().border}">
          <button id="cancel-settings" 
                  class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 
                         focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors">
            ${a.t("common.cancel")}
          </button>
          <button id="save-settings" 
                  class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 
                         focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">
            ${a.t("common.save")}
          </button>
        </div>
      </div>
    `,this.setupEventListeners(e),e}setupEventListeners(e){const t=e.querySelector("#close-settings"),n=e.querySelector("#cancel-settings");t?.addEventListener("click",()=>this.hide()),n?.addEventListener("click",()=>this.hide()),e.addEventListener("click",d=>{d.target===e&&this.hide()}),e.querySelector("#save-settings")?.addEventListener("click",()=>this.saveSettings()),e.querySelector("#export-memory-logs")?.addEventListener("click",()=>this.exportMemoryLogs()),e.querySelector("#export-all-logs")?.addEventListener("click",()=>this.exportAllLogsWithDBClear()),e.querySelector("#clear-logs")?.addEventListener("click",()=>this.clearLogs()),e.querySelector("#clear-all-logs")?.addEventListener("click",()=>this.clearAllLogs()),this.startStatsUpdate()}show(){this.isVisible||(this.loadCurrentSettings(),this.updateStats(),document.body.appendChild(this.container),this.container.classList.remove("hidden"),this.isVisible=!0)}hide(){this.isVisible&&(this.container.classList.add("hidden"),this.container.parentNode&&this.container.parentNode.removeChild(this.container),this.isVisible=!1)}loadCurrentSettings(){const e=this.logService.getConfig();this.container.querySelector("#buffer-size").value=e.bufferSize.toString(),this.container.querySelector("#export-format").value=e.exportFormat}saveSettings(){try{const e={bufferSize:parseInt(this.container.querySelector("#buffer-size").value),exportFormat:this.container.querySelector("#export-format").value};this.logService.updateConfig(e),this.showNotification(a.t("log.settings.settingsSaved"),"success"),this.hide()}catch(e){this.showNotification(a.t("log.settings.settingsSaveError"),"error"),console.error("Failed to save settings:",e)}}async updateStats(){try{const e=await this.logService.getStats();this.container.querySelector("#stat-memory-logs").textContent=e.memoryLogs.toLocaleString(),this.container.querySelector("#stat-total-logs").textContent=e.totalLogs.toLocaleString(),this.container.querySelector("#stat-indexeddb-logs").textContent=e.indexedDBLogs.toLocaleString(),this.container.querySelector("#stat-indexeddb-size").textContent=e.indexedDBSize}catch(e){console.error("Failed to update stats:",e),this.container.querySelector("#stat-memory-logs").textContent="-",this.container.querySelector("#stat-total-logs").textContent="-",this.container.querySelector("#stat-indexeddb-logs").textContent="-",this.container.querySelector("#stat-indexeddb-size").textContent="-"}}startStatsUpdate(){setInterval(()=>{this.isVisible&&this.updateStats()},5e3)}async exportMemoryLogs(){try{await this.logService.exportAllLogs(),this.showNotification(a.t("log.settings.memoryLogsSaved"),"success"),this.updateStats()}catch(e){this.showNotification(a.t("log.settings.memoryLogsSaveError"),"error"),console.error("Failed to export memory logs:",e)}}async exportAllLogsWithDBClear(){try{await this.logService.exportAllLogsIncludingIndexedDB(),this.showNotification(a.t("log.settings.allLogsSaved"),"success"),this.updateStats()}catch(e){this.showNotification(a.t("log.settings.allLogsSaveError"),"error"),console.error("Failed to export all logs:",e)}}async clearLogs(){console.log("LogSettingsPanel.clearLogs called"),console.log("onClearCallback available:",!!this.onClearCallback);try{this.onClearCallback?(console.log("Calling onClearCallback from LogSettingsPanel"),this.onClearCallback()):(console.log("No callback available, using direct service call"),this.logService.clearLogs()),this.updateStats(),this.showNotification(a.t("log.settings.memoryLogsCleared"),"success")}catch(e){this.showNotification(a.t("log.settings.memoryClearError"),"error"),console.error("Failed to clear memory logs:",e)}}async clearAllLogs(){console.log("LogSettingsPanel.clearAllLogs called"),console.log("onClearCallback available:",!!this.onClearCallback);try{this.onClearCallback?(console.log("Calling onClearCallback from LogSettingsPanel (clearAll)"),this.onClearCallback()):(console.log("No callback available, using direct service call (clearAll)"),await this.logService.clearAllLogs()),this.updateStats(),this.showNotification(a.t("log.settings.allLogsCleared"),"success")}catch(e){this.showNotification(a.t("log.settings.allClearError"),"error"),console.error("Failed to clear all logs:",e)}}showNotification(e,t){const n=document.createElement("div");n.className=`fixed top-4 right-4 z-50 px-4 py-2 rounded-md text-white ${t==="success"?"bg-green-500":"bg-red-500"}`,n.textContent=e,document.body.appendChild(n),setTimeout(()=>{n.parentNode&&n.parentNode.removeChild(n)},3e3)}destroy(){try{this.hide(),this.container.parentNode&&this.container.parentNode.removeChild(this.container),this.logService=null,this.container=null,this.isVisible=!1,console.log("[LogSettingsPanel] Destroyed successfully")}catch(e){console.error("[LogSettingsPanel] Error during destroy:",e)}}onLanguageChange(){this.isVisible&&(this.container.remove(),this.container=this.createSettingsPanel(),document.body.appendChild(this.container),this.container.classList.remove("hidden"),this.loadCurrentSettings(),this.updateStats())}getThemeClasses(){return this.currentTheme==="light"?{background:"bg-gray-50",panelBg:"bg-white",border:"border-gray-200",inputBg:"bg-white",textPrimary:"text-gray-900",textSecondary:"text-gray-800",textMuted:"text-gray-600"}:{background:"bg-dark-bg",panelBg:"bg-dark-surface",border:"border-dark-border",inputBg:"bg-dark-surface",textPrimary:"text-dark-text-primary",textSecondary:"text-dark-text-secondary",textMuted:"text-dark-text-muted"}}onThemeChange(e){this.currentTheme=e,this.container.parentNode&&this.container.parentNode.removeChild(this.container),this.container=this.createSettingsPanel()}}const L=class L{static getPresets(){return[...this.PRESETS]}static filterLogs(e,t){return e.filter(n=>this.isLogInRange(n,t))}static isLogInRange(e,t){const n=e.timestamp;if(t.startDate&&n<t.startDate||t.endDate&&n>t.endDate)return!1;if(t.startTime||t.endTime){const s=this.formatTime(n);if(t.startTime&&s<t.startTime||t.endTime&&s>t.endTime)return!1}return!0}static formatTime(e){return e.toTimeString().substring(0,5)}static createCustomRange(e,t,n,s){return{startDate:e,endDate:t,startTime:n,endTime:s}}static validateRange(e){return e.startDate&&e.endDate&&e.startDate>e.endDate?{valid:!1,error:"Start date must be before end date"}:e.startTime&&e.endTime&&e.startTime>e.endTime?{valid:!1,error:"Start time must be before end time"}:e.startTime&&!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(e.startTime)?{valid:!1,error:"Invalid start time format (use HH:mm)"}:e.endTime&&!/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(e.endTime)?{valid:!1,error:"Invalid end time format (use HH:mm)"}:{valid:!0}}static formatDateForInput(e){return e.toISOString().split("T")[0]}static formatTimeForInput(e){return e.toTimeString().substring(0,5)}};L.PRESETS=[{id:"last-hour",name:"Last Hour",range:{startDate:new Date(Date.now()-60*60*1e3),endDate:new Date}},{id:"last-4-hours",name:"Last 4 Hours",range:{startDate:new Date(Date.now()-4*60*60*1e3),endDate:new Date}},{id:"today",name:"Today",range:{startDate:new Date(new Date().setHours(0,0,0,0)),endDate:new Date}},{id:"yesterday",name:"Yesterday",range:{startDate:new Date(new Date().setDate(new Date().getDate()-1)),endDate:new Date(new Date().setHours(0,0,0,0))}},{id:"last-7-days",name:"Last 7 Days",range:{startDate:new Date(Date.now()-7*24*60*60*1e3),endDate:new Date}}];let C=L;class z{constructor(e){this.data=[],this.config=e,this.state={scrollTop:0,startIndex:0,endIndex:0,visibleItems:[],totalHeight:0}}setData(e){this.data=e,this.updateState()}setScrollTop(e){this.state.scrollTop=e,this.updateState()}updateState(){const{itemHeight:e,containerHeight:t,overscan:n}=this.config,s=this.data.length*e,o=Math.max(0,Math.floor(this.state.scrollTop/e)-n),i=Math.ceil(t/e)+n*2,r=Math.min(this.data.length,o+i),l=this.data.slice(o,r);this.state={...this.state,startIndex:o,endIndex:r,visibleItems:l,totalHeight:s},this.onStateChange&&this.onStateChange(this.state)}getState(){return{...this.state}}onStateUpdate(e){this.onStateChange=e}scrollToBottom(){const e=Math.max(0,this.state.totalHeight-this.config.containerHeight);return this.setScrollTop(e),e}scrollToIndex(e){const t=e*this.config.itemHeight;this.setScrollTop(t)}updateConfig(e){this.config={...this.config,...e},this.updateState()}getConfig(){return{...this.config}}}class V{constructor(){this.logs=[],this.filteredLogs=[],this.isAutoScroll=!0,this.connectionType="RTU",this.isRepeatMode=!1,this.currentDateTimeFilter={},this.useOptimizedService=!0,this.lastRenderedCount=0,this.renderedLogIds=new Set,this.useVirtualScrolling=!1,this.isRenderingVirtualScroll=!1,this.currentTheme="light"}getThemeClasses(){return this.currentTheme==="light"?{background:"bg-gray-50",panelBg:"bg-white",border:"border-gray-200",inputBg:"bg-white",textPrimary:"text-gray-900",textSecondary:"text-gray-800",textMuted:"text-gray-600"}:{background:"bg-dark-bg",panelBg:"bg-dark-panel",border:"border-dark-border",inputBg:"bg-dark-surface",textPrimary:"text-dark-text-primary",textSecondary:"text-dark-text-secondary",textMuted:"text-dark-text-muted"}}onThemeChange(e){this.currentTheme=e;const t=document.querySelector("#log-content");t&&(t.innerHTML=this.render(),this.attachEventListeners(),this.addCustomStyles(),this.setupScrollContainer(),this.setupTooltipPositioning(),this.updateAutoScrollCheckbox(),this.initializeVirtualScrolling(),this.applyCurrentTimeFilter(),this.renderLogs())}mount(e){this.logService=new F,this.optimizedLogService=new w,this.logSettingsPanel=new $(this.optimizedLogService),this.onClearLogs?(console.log("Setting callback in mount - callback available"),this.logSettingsPanel.setClearCallback(this.onClearLogs)):console.log("Setting callback in mount - no callback available yet"),e.innerHTML=this.render(),this.attachEventListeners(),this.addCustomStyles(),this.setupScrollContainer(),this.setupTooltipPositioning(),this.updateAutoScrollCheckbox(),this.initializeVirtualScrolling(),this.applyCurrentTimeFilter()}setClearLogsCallback(e){console.log("LogPanel.setClearLogsCallback called"),this.onClearLogs=e,this.logSettingsPanel?(console.log("Setting callback for LogSettingsPanel"),this.logSettingsPanel.setClearCallback(e)):console.log("LogSettingsPanel not available yet")}setConnectionType(e){this.connectionType=e}setRepeatMode(e){this.isRepeatMode=e}updateAutoScrollCheckbox(){const e=document.getElementById("auto-scroll");e&&(e.checked=this.isAutoScroll)}addCustomStyles(){const e=document.createElement("style");e.textContent=`
      .modbus-packet {
        position: relative !important;
      }
      
      .tooltip-custom {
        position: fixed;
        background: rgba(0, 0, 0, 0.95);
        color: white;
        padding: 8px 12px;
        border-radius: 6px;
        font-size: 12px;
        line-height: 1.4;
        white-space: pre-line;
        z-index: 10000;
        min-width: 300px;
        max-width: 500px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        pointer-events: none;
        opacity: 0;
        transform: translateY(4px);
        transition: opacity 0.15s ease-out, transform 0.15s ease-out;
        font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      }
      
      .tooltip-custom.show {
        opacity: 1;
        transform: translateY(0);
      }
      
      .modbus-packet:hover {
        background-color: rgba(59, 130, 246, 0.1) !important;
        border-radius: 4px;
        transition: background-color 0.1s ease;
      }
    `;const t=document.querySelector("style[data-logpanel-tooltip]");t&&t.remove(),e.setAttribute("data-logpanel-tooltip","true"),document.head.appendChild(e)}setupTooltipPositioning(){let e=null;document.removeEventListener("mouseover",this.handleTooltipMouseOver),document.removeEventListener("mouseout",this.handleTooltipMouseOut);const t=document.getElementById("log-container");t&&(t.removeEventListener("mouseover",this.handleLogContainerMouseOver),t.removeEventListener("mouseout",this.handleLogContainerMouseOut),this.handleLogContainerMouseOver=n=>{const s=n.target;s.classList.contains("modbus-packet")&&s.dataset.tooltip&&!this.isRepeatMode&&!t.classList.contains("scrolling")&&(e=this.showTooltip(s,s.dataset.tooltip))},this.handleLogContainerMouseOut=n=>{n.target.classList.contains("modbus-packet")&&e&&(this.hideTooltip(e),e=null)},t.addEventListener("mouseover",this.handleLogContainerMouseOver),t.addEventListener("mouseout",this.handleLogContainerMouseOut))}showTooltip(e,t){const n=document.querySelector(".tooltip-custom");n&&n.remove();const s=document.createElement("div");s.className="tooltip-custom",s.textContent=t,document.body.appendChild(s);const o=e.getBoundingClientRect(),i=s.getBoundingClientRect(),r=window.innerHeight,l=window.innerWidth;let d=o.left,u=o.bottom+8;if(d+i.width>l-20&&(d=l-i.width-20),d<20&&(d=20),u+i.height>r-20){const g=o.top,h=r-o.bottom;g>h?u=o.top-i.height-8:u=Math.max(20,r-i.height-20)}return u<20&&(u=20),s.style.left=`${d}px`,s.style.top=`${u}px`,requestAnimationFrame(()=>{s.classList.add("show")}),s}hideTooltip(e){e.classList.remove("show"),setTimeout(()=>{e.parentNode&&e.remove()},150)}render(){return`
      <div class="h-full flex flex-col" style="height: 100%; min-height: 400px;">
        <!-- Log Controls -->
        <div class="flex items-center justify-between p-4 border-b ${this.getThemeClasses().border} ${this.getThemeClasses().panelBg} flex-shrink-0">
          <div class="flex items-center gap-4">
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" id="auto-scroll" ${this.isAutoScroll?"checked":""} 
                class="rounded ${this.getThemeClasses().border} ${this.getThemeClasses().inputBg}">
              <span class="${this.getThemeClasses().textSecondary}">Auto Scroll</span>
            </label>
            
            <div class="flex items-center gap-2">
              <input 
                type="text" 
                placeholder="Search logs..." 
                id="log-search"
                class="input-field text-sm w-48"
              />
              <button class="btn-secondary text-sm py-1 px-3" id="time-filter-btn">
                Time Filter
              </button>
            </div>
          </div>

          <div class="flex items-center justify-start gap-2 text-sm ${this.getThemeClasses().textSecondary}">
          </div>
        </div>

        <!-- Log Content -->
        <div class="flex-1 min-h-0 overflow-hidden" style="flex: 1; min-height: 0;">
          <div class="h-full overflow-y-auto scrollbar-thin" id="log-container" style="height: 100%; overflow-y: auto;">
            ${this.renderLogs()}
          </div>
        </div>
      </div>
      
      <!-- Log Settings Modal -->
      
      <!-- Time Filter Modal -->
      ${this.renderTimeFilterModal()}
    `}renderTimeFilterModal(){return`
      <div id="time-filter-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
        <div class="bg-dark-panel border border-dark-border rounded-lg shadow-lg w-full max-w-md mx-4">
          <div class="flex items-center justify-between p-4 border-b border-dark-border">
            <h3 class="text-lg font-medium text-dark-text-primary">Time Range Filter</h3>
            <button id="close-time-filter" class="text-dark-text-muted hover:text-dark-text-primary">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
              </svg>
            </button>
          </div>
          
          <div class="p-4 space-y-4">
            <!-- Quick Presets -->
            <div>
              <label class="block text-sm font-medium text-dark-text-primary mb-2">Quick Filters</label>
              <div class="grid grid-cols-2 gap-2">
                <button class="btn-secondary text-sm py-2 px-3 time-preset" data-preset="last-hour">Last Hour</button>
                <button class="btn-secondary text-sm py-2 px-3 time-preset" data-preset="last-4-hours">Last 4 Hours</button>
                <button class="btn-secondary text-sm py-2 px-3 time-preset" data-preset="today">Today</button>
                <button class="btn-secondary text-sm py-2 px-3 time-preset" data-preset="yesterday">Yesterday</button>
                <button class="btn-secondary text-sm py-2 px-3 time-preset" data-preset="last-7-days">Last 7 Days</button>
                <button class="btn-secondary text-sm py-2 px-3" id="clear-filter">Clear Filter</button>
              </div>
            </div>
            
            <!-- Custom Range -->
            <div class="border-t border-dark-border pt-4">
              <label class="block text-sm font-medium text-dark-text-primary mb-2">Custom Range</label>
              <div class="space-y-3">
                <div class="grid grid-cols-2 gap-2">
                  <div>
                    <label class="block text-xs text-dark-text-secondary mb-1">Start Date</label>
                    <input type="date" id="start-date" class="input-field text-sm w-full">
                  </div>
                  <div>
                    <label class="block text-xs text-dark-text-secondary mb-1">End Date</label>
                    <input type="date" id="end-date" class="input-field text-sm w-full">
                  </div>
                </div>
                <div class="grid grid-cols-2 gap-2">
                  <div>
                    <label class="block text-xs text-dark-text-secondary mb-1">Start Time</label>
                    <input type="time" id="start-time" class="input-field text-sm w-full">
                  </div>
                  <div>
                    <label class="block text-xs text-dark-text-secondary mb-1">End Time</label>
                    <input type="time" id="end-time" class="input-field text-sm w-full">
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div class="flex items-center justify-end gap-2 p-4 border-t border-dark-border">
            <button id="cancel-time-filter" class="btn-secondary text-sm py-2 px-4">Cancel</button>
            <button id="apply-time-filter" class="btn-primary text-sm py-2 px-4">Apply Filter</button>
          </div>
        </div>
      </div>
    `}renderLogs(){return this.logs.length===0?`
        <div class="flex items-center justify-center h-full text-dark-text-muted">
          <div class="text-center">
            <div class="text-4xl mb-4">📡</div>
            <p>No communication logs yet</p>
            <p class="text-sm">Connect to a Modbus device to start monitoring</p>
          </div>
        </div>
      `:this.logs.map(e=>this.renderLogEntry(e)).join("")}renderLogEntry(e){const t=this.formatTimestamp(e.timestamp),n=e.direction==="send"?"send":"recv",s=e.direction==="send"?"SEND":"RECV",o=this.analyzeModbusPacket(e.data);return`
      <div class="log-entry" data-log-id="${e.id}">
        <div class="log-timestamp">${t}</div>
        <div class="log-direction ${n}">${s}</div>
        <div class="log-data ${o?"cursor-help modbus-packet":""}" 
             ${o?`data-tooltip="${o.replace(/"/g,"&quot;")}"`:""}>
          ${this.formatLogData(e.data)}
        </div>
        ${e.responseTime?`<div class="text-xs ${this.getThemeClasses().textMuted}">${e.responseTime}ms</div>`:""}
        ${e.error?`<div class="text-xs text-status-error">${e.error}</div>`:""}
      </div>
    `}formatTimestamp(e){const t=e.getHours().toString().padStart(2,"0"),n=e.getMinutes().toString().padStart(2,"0"),s=e.getSeconds().toString().padStart(2,"0"),o=e.getMilliseconds().toString().padStart(3,"0");return`${t}:${n}:${s}.${o}`}formatLogData(e){const t=e.replace(/\s+/g,"").toUpperCase();return(t.length%2!==0?"0"+t:t).replace(/(.{2})/g,"$1 ").trim()}analyzeModbusPacket(e){const t=e.replace(/\s+/g,"").toUpperCase();return t.length<8?null:this.connectionType==="RTU"?this.analyzeRtuPacket(t):this.isTcpPacket(t)?this.analyzeTcpPacket(t):this.analyzeTcpNativePdu(t)}isTcpPacket(e){return e.length<14?!1:e.substring(4,8)==="0000"}analyzeTcpPacket(e){if(e.length<14)return null;try{const t=e.substring(0,4),n=e.substring(4,8),s=e.substring(8,12),o=e.substring(12,14),i=e.substring(14),r=this.analyzeModbusPdu(i);let l=`🌐 MODBUS TCP PACKET
`;return l+=`Transaction ID: 0x${t} (${parseInt(t,16)})
`,l+=`Protocol ID: 0x${n} (${parseInt(n,16)})
`,l+=`Length: 0x${s} (${parseInt(s,16)} bytes)
`,l+=`Unit ID: 0x${o} (${parseInt(o,16)})
`,r&&(l+=`
${r}`),l}catch{return null}}analyzeRtuPacket(e){if(e.length<8)return null;try{if(!this.validateCrc(e))return null;const n=e.substring(0,2),s=e.substring(2,e.length-4),o=e.substring(e.length-4),i=this.analyzeModbusPdu(s);let r=`📡 MODBUS RTU PACKET
`;return r+=`Device ID: 0x${n} (${parseInt(n,16)})
`,r+=`CRC: 0x${o} ✅ Valid
`,i&&(r+=`
${i}`),r}catch{return null}}analyzeTcpNativePdu(e){if(e.length<2)return null;try{const t=this.analyzeModbusPdu(e);if(t){let n=`🌐 MODBUS TCP NATIVE PDU
`;return n+=`PDU Length: ${e.length/2} bytes
`,n+=`
${t}`,n}return null}catch{return null}}analyzeModbusPdu(e){if(e.length<2)return null;const t=e.substring(0,2),n=parseInt(t,16);if(n&128){const s=(n&127).toString(16).padStart(2,"0").toUpperCase(),o=e.substring(2,4),i=this.getExceptionText(parseInt(o,16));return`⚠️ ERROR RESPONSE
Original Function: 0x${s} (${parseInt(s,16)})
Exception Code: 0x${o} (${parseInt(o,16)}) - ${i}`}switch(n){case 1:return this.analyzeReadCoils(e);case 2:return this.analyzeReadDiscreteInputs(e);case 3:return this.analyzeReadHoldingRegisters(e);case 4:return this.analyzeReadInputRegisters(e);case 5:return this.analyzeWriteSingleCoil(e);case 6:return this.analyzeWriteSingleRegister(e);case 8:return this.connectionType==="RTU"?this.analyzeDiagnostics(e):`📋 MODBUS PDU
Function Code: 0x${t} (${n}) - Not supported in TCP mode`;case 11:return this.connectionType==="RTU"?this.analyzeGetCommEventCounter(e):`📋 MODBUS PDU
Function Code: 0x${t} (${n}) - Not supported in TCP mode`;case 15:return this.analyzeWriteMultipleCoils(e);case 16:return this.analyzeWriteMultipleRegisters(e);case 17:return this.connectionType==="RTU"?this.analyzeReportServerId(e):`📋 MODBUS PDU
Function Code: 0x${t} (${n}) - Not supported in TCP mode`;case 22:return this.analyzeMaskWriteRegister(e);case 23:return this.analyzeReadWriteMultipleRegisters(e);case 43:return this.analyzeReadDeviceIdentification(e);default:return`📋 MODBUS PDU
Function Code: 0x${t} (${n}) - Unknown/Unsupported`}}analyzeReadCoils(e){if(e.length===10){const t=e.substring(2,6),n=e.substring(6,10);return`📖 READ COILS (0x01) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} coils)`}else if(e.length>=4){const t=e.substring(2,4),n=e.substring(4);return`📖 READ COILS (0x01) - RESPONSE
Byte Count: 0x${t} (${parseInt(t,16)} bytes)
Coil Data: 0x${n}`}return"📖 READ COILS (0x01)"}analyzeReadDiscreteInputs(e){if(e.length===10){const t=e.substring(2,6),n=e.substring(6,10);return`📖 READ DISCRETE INPUTS (0x02) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} inputs)`}else if(e.length>=4){const t=e.substring(2,4),n=e.substring(4);return`📖 READ DISCRETE INPUTS (0x02) - RESPONSE
Byte Count: 0x${t} (${parseInt(t,16)} bytes)
Input Data: 0x${n}`}return"📖 READ DISCRETE INPUTS (0x02)"}analyzeReadHoldingRegisters(e){if(e.length===10){const t=e.substring(2,6),n=e.substring(6,10);return`📊 READ HOLDING REGISTERS (0x03) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} registers)`}else if(e.length>=4){const t=e.substring(2,4),n=e.substring(4),s=parseInt(t,16)/2;let o=`📊 READ HOLDING REGISTERS (0x03) - RESPONSE
Byte Count: 0x${t} (${parseInt(t,16)} bytes)
Register Count: ${s}
`;for(let i=0;i<n.length;i+=4)if(i+4<=n.length){const r=n.substring(i,i+4),l=parseInt(r,16);o+=`Reg ${i/4}: 0x${r} (${l})
`}return o.trim()}return"📊 READ HOLDING REGISTERS (0x03)"}analyzeReadInputRegisters(e){if(e.length===10){const t=e.substring(2,6),n=e.substring(6,10);return`📊 READ INPUT REGISTERS (0x04) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} registers)`}else if(e.length>=4){const t=e.substring(2,4),n=e.substring(4),s=parseInt(t,16)/2;let o=`📊 READ INPUT REGISTERS (0x04) - RESPONSE
Byte Count: 0x${t} (${parseInt(t,16)} bytes)
Register Count: ${s}
`;for(let i=0;i<n.length;i+=4)if(i+4<=n.length){const r=n.substring(i,i+4),l=parseInt(r,16);o+=`Reg ${i/4}: 0x${r} (${l})
`}return o.trim()}return"📊 READ INPUT REGISTERS (0x04)"}analyzeWriteSingleCoil(e){if(e.length===10){const t=e.substring(2,6),n=e.substring(6,10),s=n==="0000"?"OFF":n==="FF00"?"ON":"INVALID";return`⚙️ WRITE SINGLE COIL (0x05)
Coil Address: 0x${t} (${parseInt(t,16)})
Coil Value: 0x${n} (${s})`}return"⚙️ WRITE SINGLE COIL (0x05)"}analyzeWriteSingleRegister(e){if(e.length===10){const t=e.substring(2,6),n=e.substring(6,10);return`✏️ WRITE SINGLE REGISTER (0x06)
Register Address: 0x${t} (${parseInt(t,16)})
Register Value: 0x${n} (${parseInt(n,16)})`}return"✏️ WRITE SINGLE REGISTER (0x06)"}analyzeWriteMultipleRegisters(e){if(e.length>=12){const t=e.substring(2,6),n=e.substring(6,10);if(e.length===10)return`✏️ WRITE MULTIPLE REGISTERS (0x10) - RESPONSE
Start Address: 0x${t} (${parseInt(t,16)})
Quantity Written: 0x${n} (${parseInt(n,16)} registers)`;{const s=e.substring(10,12),o=e.substring(12);let i=`✏️ WRITE MULTIPLE REGISTERS (0x10) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} registers)
Byte Count: 0x${s} (${parseInt(s,16)} bytes)
`;for(let r=0;r<o.length;r+=4)if(r+4<=o.length){const l=o.substring(r,r+4),d=parseInt(l,16);i+=`Reg ${r/4}: 0x${l} (${d})
`}return i.trim()}}return"✏️ WRITE MULTIPLE REGISTERS (0x10)"}analyzeDiagnostics(e){if(e.length>=6){const t=e.substring(2,6),n=e.substring(6),o={"0000":"Return Query Data","0001":"Restart Communications Option","0002":"Return Diagnostic Register","0003":"Change ASCII Input Delimiter","0004":"Force Listen Only Mode","000A":"Clear Counters and Diagnostic Register","000B":"Return Bus Message Count","000C":"Return Bus Communication Error Count","000D":"Return Bus Exception Error Count","000E":"Return Slave Message Count","000F":"Return Slave No Response Count"}[t]||"Unknown Sub-function";return`🔍 DIAGNOSTICS (0x08)
Sub-function: 0x${t} (${parseInt(t,16)}) - ${o}
Data: 0x${n}`}return"🔍 DIAGNOSTICS (0x08)"}analyzeGetCommEventCounter(e){if(e.length===2)return"📊 GET COMM EVENT COUNTER (0x0B) - REQUEST";if(e.length===8){const t=e.substring(2,6),n=e.substring(6,10);return`📊 GET COMM EVENT COUNTER (0x0B) - RESPONSE
Status: 0x${t} (${parseInt(t,16)})
Event Count: 0x${n} (${parseInt(n,16)})`}return"📊 GET COMM EVENT COUNTER (0x0B)"}analyzeWriteMultipleCoils(e){if(e.length>=12){const t=e.substring(2,6),n=e.substring(6,10);if(e.length===10)return`🔄 WRITE MULTIPLE COILS (0x0F) - RESPONSE
Start Address: 0x${t} (${parseInt(t,16)})
Quantity Written: 0x${n} (${parseInt(n,16)} coils)`;{const s=e.substring(10,12),o=e.substring(12);return`🔄 WRITE MULTIPLE COILS (0x0F) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} coils)
Byte Count: 0x${s} (${parseInt(s,16)} bytes)
Coil Data: 0x${o}`}}return"🔄 WRITE MULTIPLE COILS (0x0F)"}analyzeReportServerId(e){if(e.length===2)return"🏷️ REPORT SERVER ID (0x11) - REQUEST";if(e.length>=4){const t=e.substring(2,4),n=e.substring(4);return`🏷️ REPORT SERVER ID (0x11) - RESPONSE
Byte Count: 0x${t} (${parseInt(t,16)} bytes)
Server ID Data: 0x${n}`}return"🏷️ REPORT SERVER ID (0x11)"}analyzeMaskWriteRegister(e){if(e.length===14){const t=e.substring(2,6),n=e.substring(6,10),s=e.substring(10,14);return`🎭 MASK WRITE REGISTER (0x16)
Register Address: 0x${t} (${parseInt(t,16)})
AND Mask: 0x${n} (${parseInt(n,16)})
OR Mask: 0x${s} (${parseInt(s,16)})`}return"🎭 MASK WRITE REGISTER (0x16)"}analyzeReadWriteMultipleRegisters(e){if(e.length>=18){const t=e.substring(2,6),n=e.substring(6,10),s=e.substring(10,14),o=e.substring(14,18);if(e.length>18){const i=e.substring(18,20),r=e.substring(20);return`🔄 READ/WRITE MULTIPLE REGISTERS (0x17) - REQUEST
Read Start Address: 0x${t} (${parseInt(t,16)})
Read Quantity: 0x${n} (${parseInt(n,16)} registers)
Write Start Address: 0x${s} (${parseInt(s,16)})
Write Quantity: 0x${o} (${parseInt(o,16)} registers)
Write Byte Count: 0x${i} (${parseInt(i,16)} bytes)
Write Data: 0x${r}`}}else if(e.length>=4){const t=e.substring(2,4),n=e.substring(4);return`🔄 READ/WRITE MULTIPLE REGISTERS (0x17) - RESPONSE
Read Byte Count: 0x${t} (${parseInt(t,16)} bytes)
Read Data: 0x${n}`}return"🔄 READ/WRITE MULTIPLE REGISTERS (0x17)"}analyzeReadDeviceIdentification(e){if(e.length>=8){const t=e.substring(2,4),n=e.substring(4,6),s=e.substring(6,8),o={"0E":"Read Device Identification"},i={"01":"Basic Device Identification","02":"Regular Device Identification","03":"Extended Device Identification","04":"Individual Access"},r={"00":"VendorName","01":"ProductCode","02":"MajorMinorRevision","03":"VendorUrl","04":"ProductName","05":"ModelName","06":"UserApplicationName"},l=o[t]||"Unknown",d=i[n]||"Unknown",u=r[s]||"Unknown";if(e.length===8)return`🏷️ READ DEVICE IDENTIFICATION (0x2B/0x0E) - REQUEST
Sub-function: 0x${t} - ${l}
Read Device ID Code: 0x${n} - ${d}
Object ID: 0x${s} - ${u}`;{const g=e.substring(8,10),h=e.substring(10,12),c=e.substring(12,14),m=e.substring(14,16),v=e.substring(16);return`🏷️ READ DEVICE IDENTIFICATION (0x2B/0x0E) - RESPONSE
Sub-function: 0x${t} - ${l}
Conformity Level: 0x${g}
More Follows: 0x${h}
Next Object ID: 0x${c}
Number of Objects: 0x${m} (${parseInt(m,16)})
Object Data: 0x${v}`}}return"🏷️ READ DEVICE IDENTIFICATION (0x2B/0x0E)"}getExceptionText(e){return{1:"Illegal Function",2:"Illegal Data Address",3:"Illegal Data Value",4:"Slave Device Failure",5:"Acknowledge",6:"Slave Device Busy",8:"Memory Parity Error",10:"Gateway Path Unavailable",11:"Gateway Target Device Failed to Respond"}[e]||"Unknown Exception"}validateCrc(e){if(e.length<8)return!1;const t=e.substring(e.length-4);return/^[0-9A-F]{4}$/.test(t)}attachEventListeners(){document.getElementById("auto-scroll")?.addEventListener("change",s=>{this.isAutoScroll=s.target.checked,this.isAutoScroll&&this.scrollToBottom()}),document.getElementById("log-search")?.addEventListener("input",s=>{const o=s.target.value;this.filterLogs(o)}),document.getElementById("time-filter-btn")?.addEventListener("click",()=>{this.showTimeFilterModal()}),this.setupTimeFilterModal()}refreshLogDisplay(){this.renderRegularScrollLogs()}updateLogCount(){}scrollToBottom(){const e=document.getElementById("log-container");e&&requestAnimationFrame(()=>{e.scrollTop=e.scrollHeight})}setupScrollContainer(){const e=document.getElementById("log-container");if(!e)return;e.style.overflowY="auto",e.style.height="100%",e.style.position="relative";let t,n=!1;e.addEventListener("scroll",s=>{n||(n=!0,e.classList.add("scrolling")),clearTimeout(t),t=setTimeout(()=>{n=!1,e.classList.remove("scrolling")},300)}),this.renderRegularScrollLogs()}renderRegularScrollLogs(){const e=document.getElementById("log-container");if(e){e.innerHTML=this.filteredLogs.map(t=>this.renderLogEntry(t)).join(""),this.renderedLogIds.clear();for(const t of this.filteredLogs)this.renderedLogIds.add(t.id)}}renderNewLogsIncremental(e){const t=document.getElementById("log-container");if(!t)return;const n=this.filterLogsByTimeRange(e),s=[];for(const o of n)this.renderedLogIds.has(o.id)||(s.push(o),this.renderedLogIds.add(o.id));if(s.length>0){const o=document.createDocumentFragment();for(const i of s){const r=this.createLogElement(i);o.appendChild(r)}t.appendChild(o)}}filterLogsByTimeRange(e){return Object.keys(this.currentDateTimeFilter).length===0?e:C.filterLogs(e,this.currentDateTimeFilter)}createLogElement(e){const t=document.createElement("div");t.className="log-entry",t.setAttribute("data-log-id",e.id);const n=this.formatTimestamp(e.timestamp),s=e.direction==="send"?"send":"recv",o=e.direction==="send"?"SEND":"RECV",i=this.isRepeatMode?null:this.analyzeModbusPacket(e.data);return t.innerHTML=`
      <div class="log-timestamp">${n}</div>
      <div class="log-direction ${s}">${o}</div>
      <div class="log-data ${i&&!this.isRepeatMode?"cursor-help modbus-packet":""}" 
           ${i&&!this.isRepeatMode?`data-tooltip="${i.replace(/"/g,"&quot;")}"`:""}>
        ${this.formatLogData(e.data)}
      </div>
      ${e.responseTime?`<div class="text-xs text-dark-text-muted">${e.responseTime}ms</div>`:""}
      ${e.error?`<div class="text-xs text-status-error">${e.error}</div>`:""}
    `,t}initializeVirtualScrolling(){const e={itemHeight:32,containerHeight:400,overscan:5};this.virtualScrollManager=new z(e),this.virtualScrollManager.onStateUpdate(t=>{this.useVirtualScrolling&&!this.isRenderingVirtualScroll&&(console.log(`[Virtual Scroll] State update - showing items ${t.startIndex}-${t.endIndex} of ${this.filteredLogs.length}`),this.renderVirtualScrollLogs())}),this.setupVirtualScrollListener()}shouldUseVirtualScrolling(){const t=this.filteredLogs.length>30;return t&&!this.useVirtualScrolling?console.log(`[Virtual Scroll] Enabling for ${this.filteredLogs.length} logs`):!t&&this.useVirtualScrolling&&console.log(`[Virtual Scroll] Disabling for ${this.filteredLogs.length} logs`),t}updateVirtualScrollingMode(){const e=this.shouldUseVirtualScrolling();e!==this.useVirtualScrolling&&(this.useVirtualScrolling=e,this.useVirtualScrolling&&this.virtualScrollManager?(this.updateVirtualScrollContainerHeight(),this.virtualScrollManager.setData(this.filteredLogs),this.renderVirtualScrollLogs()):this.renderRegularScrollLogs())}renderVirtualScrollLogs(){if(!(!this.virtualScrollManager||this.isRenderingVirtualScroll)){this.isRenderingVirtualScroll=!0;try{const e=document.getElementById("log-container");if(!e)return;const t=this.virtualScrollManager.getState(),n=this.virtualScrollManager.getConfig();let s=e.querySelector(".virtual-scroll-wrapper"),o=e.querySelector("#virtual-content");if(!s||!o?(e.innerHTML=`
          <div class="virtual-scroll-wrapper" style="height: ${t.totalHeight}px; position: relative; overflow: hidden;">
            <div id="virtual-content" style="position: absolute; top: ${t.startIndex*n.itemHeight}px;">
            </div>
          </div>
        `,s=e.querySelector(".virtual-scroll-wrapper"),o=e.querySelector("#virtual-content"),this.setupVirtualScrollListener()):(s.style.height=`${t.totalHeight}px`,o.style.top=`${t.startIndex*n.itemHeight}px`,o.innerHTML=""),o)for(const i of t.visibleItems){const r=this.createLogElement(i);o.appendChild(r)}}finally{this.isRenderingVirtualScroll=!1}}}updateVirtualScrollContainerHeight(){const e=document.getElementById("log-container");if(!e||!this.virtualScrollManager)return;const t=e.getBoundingClientRect();t.height>0&&this.virtualScrollManager.updateConfig({containerHeight:t.height})}setupVirtualScrollListener(){const e=document.getElementById("log-container");e&&(this.scrollListener&&e.removeEventListener("scroll",this.scrollListener),this.scrollListener=t=>{if(this.useVirtualScrolling&&this.virtualScrollManager){const n=t.target;this.virtualScrollManager.setScrollTop(n.scrollTop)}},e.addEventListener("scroll",this.scrollListener,{passive:!0}))}filterLogs(e){const t=document.querySelectorAll(".log-entry"),n=e.toLowerCase();t.forEach(s=>{const o=s.textContent?.toLowerCase()||"",i=s;i.style.display=o.includes(n)?"flex":"none"})}clearLogs(){console.log("LogPanel.clearLogs called"),this.lastRenderedCount=0,this.renderedLogIds.clear(),this.virtualScrollManager&&(this.virtualScrollManager.setData([]),this.virtualScrollManager.setScrollTop(0)),this.useVirtualScrolling=!1,this.logs=[],this.filteredLogs=[];const e=document.getElementById("log-container");e&&(e.scrollTop=0,requestAnimationFrame(()=>{e.scrollTop=0,requestAnimationFrame(()=>{e.scrollTop=0})})),this.forceRefreshDisplay(),setTimeout(()=>{const t=document.getElementById("log-container");t&&(t.scrollTop=0,console.log("Post-refresh scroll reset:",t.scrollTop))},50),this.isAutoScroll=!0,this.updateAutoScrollCheckbox(),console.log("LogPanel cleared and refreshed")}forceRefreshDisplay(){const e=document.getElementById("log-container");e&&(e.innerHTML="",this.logs.length===0?e.innerHTML=`
          <div class="flex items-center justify-center py-8 text-dark-text-muted">
            <div class="text-center">
              <div class="text-4xl mb-4">📡</div>
              <p>No communication logs yet</p>
              <p class="text-sm">Connect to a Modbus device to start monitoring</p>
            </div>
          </div>
        `:(this.applyCurrentTimeFilter(),this.renderRegularScrollLogs()))}generateSampleLogs(){const e=[];for(let t=0;t<5;t++){const n=Date.now()-(5-t)*1e3,s=`01 03 00 ${t.toString(16).padStart(2,"0")} 00 0A C5 CD`,o=`01 03 14 ${Array.from({length:6},(i,r)=>(t+r).toString(16).padStart(2,"0")).join(" ")} FA 6C`;e.push({id:`initial-${t*2+1}`,timestamp:new Date(n),direction:"send",data:s}),e.push({id:`initial-${t*2+2}`,timestamp:new Date(n+100),direction:"recv",data:o,responseTime:80+Math.floor(Math.random()*40)})}this.updateLogs(e),this.startGradualLogGeneration()}startGradualLogGeneration(){let e=0;const t=setInterval(async()=>{if(e>=20){clearInterval(t);return}const n=Date.now(),s=`01 03 00 ${e.toString(16).padStart(2,"0")} 00 0A C5 CD`,o=`01 03 14 ${Array.from({length:6},(i,r)=>(e+r).toString(16).padStart(2,"0")).join(" ")} FA 6C`;await this.addLog({id:`gradual-send-${e}`,timestamp:new Date(n),direction:"send",data:s}),setTimeout(async()=>{await this.addLog({id:`gradual-recv-${e}`,timestamp:new Date(n+200),direction:"recv",data:o,responseTime:80+Math.floor(Math.random()*40)})},200),e++},3e3)}async addLog(e){this.useOptimizedService?(await this.optimizedLogService.addLog(e),this.logs=this.optimizedLogService.getRecentLogs(1e3)):(this.logService.addLog(e),this.logs=this.logService.getAllLogs()),this.applyCurrentTimeFilter(),this.renderRegularScrollLogs(),this.handleAutoScroll()}updateLogs(e){const t=e.slice(this.lastRenderedCount);if(this.useOptimizedService)for(const n of t)this.optimizedLogService.addLog(n);else this.logService.addLogs&&this.logService.addLogs(t);this.logs=e,this.applyCurrentTimeFilter(),this.updateVirtualScrollingMode(),this.useVirtualScrolling?this.virtualScrollManager&&(this.virtualScrollManager.setData(this.filteredLogs),this.renderVirtualScrollLogs()):this.renderNewLogsIncremental(t),this.lastRenderedCount=e.length,this.setupTooltipPositioning(),this.handleAutoScroll()}applyCurrentTimeFilter(){Object.keys(this.currentDateTimeFilter).length===0?this.filteredLogs=[...this.logs]:this.filteredLogs=C.filterLogs(this.logs,this.currentDateTimeFilter)}handleAutoScroll(){if(document.getElementById("auto-scroll")?.checked??this.isAutoScroll){const n=document.getElementById("log-container");if(n&&this.filteredLogs.length>0){const s=n.scrollHeight,o=n.clientHeight;s>o?setTimeout(()=>{document.getElementById("auto-scroll")?.checked&&this.scrollToBottom()},10):n.scrollTop=0}}}showTimeFilterModal(){const e=document.getElementById("time-filter-modal");e&&e.classList.remove("hidden")}hideTimeFilterModal(){const e=document.getElementById("time-filter-modal");e&&e.classList.add("hidden")}setupTimeFilterModal(){const e=document.getElementById("close-time-filter"),t=document.getElementById("cancel-time-filter");e?.addEventListener("click",()=>{this.hideTimeFilterModal()}),t?.addEventListener("click",()=>{this.hideTimeFilterModal()}),document.querySelectorAll(".time-preset").forEach(r=>{r.addEventListener("click",l=>{const d=l.target.dataset.preset;d&&this.applyPresetFilter(d)})}),document.getElementById("clear-filter")?.addEventListener("click",()=>{this.clearTimeFilter()}),document.getElementById("apply-time-filter")?.addEventListener("click",()=>{this.applyCustomTimeFilter()});const i=document.getElementById("time-filter-modal");i?.addEventListener("click",r=>{r.target===i&&this.hideTimeFilterModal()})}applyPresetFilter(e){const n=C.getPresets().find(s=>s.id===e);n&&(this.currentDateTimeFilter=n.range,this.applyTimeFilter(),this.hideTimeFilterModal())}applyCustomTimeFilter(){const e=document.getElementById("start-date"),t=document.getElementById("end-date"),n=document.getElementById("start-time"),s=document.getElementById("end-time"),o=e?.value?new Date(e.value):void 0,i=t?.value?new Date(t.value):void 0,r=n?.value||void 0,l=s?.value||void 0,d=C.createCustomRange(o,i,r,l),u=C.validateRange(d);if(!u.valid){alert(`Invalid time range: ${u.error}`);return}this.currentDateTimeFilter=d,this.applyTimeFilter(),this.hideTimeFilterModal()}clearTimeFilter(){this.currentDateTimeFilter={},this.applyTimeFilter(),this.hideTimeFilterModal()}applyTimeFilter(){this.applyCurrentTimeFilter(),this.refreshLogDisplay();const e=document.getElementById("time-filter-btn");e&&(Object.keys(this.currentDateTimeFilter).length===0?(e.textContent="Time Filter",e.classList.remove("bg-blue-600","text-white"),e.classList.add("btn-secondary")):(e.textContent="Time Filter ✓",e.classList.remove("btn-secondary"),e.classList.add("bg-blue-600","text-white")))}getOptimizedLogService(){return this.optimizedLogService}destroy(){try{const e=document.getElementById("log-container");e&&this.scrollListener&&(e.removeEventListener("scroll",this.scrollListener),this.scrollListener=void 0);const t=document.querySelector(".tooltip-custom");t&&t.remove();const n=document.querySelector("style[data-logpanel-tooltip]");n&&n.remove(),this.virtualScrollManager&&(this.virtualScrollManager=void 0),this.logs=[],this.filteredLogs=[],this.renderedLogIds.clear(),this.onClearLogs=void 0,this.lastRenderedCount=0,this.isRenderingVirtualScroll=!1,this.useVirtualScrolling=!1,this.isRepeatMode=!1,console.log("[LogPanel] Destroyed successfully")}catch(e){console.error("[LogPanel] Error during destroy:",e)}}}class O{constructor(e,t){this.commandHistory=[],this.historyIndex=-1,this.connectionType="RTU",this.lastConnectionType=null,this.recentCommands=[],this.maxRecentCommands=10,this.repeatTimer=null,this.isRepeating=!1,this.repeatInterval=1e3,this.startTime=0,this.expectedNextTime=0,this.checkedCommands=new Set,this.currentTheme="light",this.onCommandSend=e,this.onRepeatModeChanged=t}mount(e){e.innerHTML=this.render(),this.attachEventListeners(),this.updateAutoCrcForConnectionType(this.connectionType)}destroy(){this.stopRepeatMode()}render(){return`
      <div class="flex flex-col space-y-4 ${this.getThemeClasses().panelBg} p-4 rounded-lg">
        <!-- Quick Commands -->
        <div>
          <h3 class="text-sm font-medium ${this.getThemeClasses().textSecondary} mb-3">Quick Commands & Examples</h3>
          <div class="grid grid-cols-1 gap-2" id="quick-commands">
            ${this.renderQuickCommands()}
          </div>
          <div class="text-xs text-blue-400 mt-2" id="mode-info">
            ${this.renderModeInfo()}
          </div>
        </div>

        <!-- Manual Command Input -->
        <div class="flex flex-col">
          <h3 class="text-sm font-medium ${this.getThemeClasses().textSecondary} mb-3">${a.t("command.manual.title")}</h3>
          
          <div class="flex flex-col space-y-3">
            <!-- Manual HEX Input -->
            <div>
              <div class="flex items-center justify-between mb-2">
                <label class="block text-xs ${this.getThemeClasses().textMuted}">
                  ${a.t("command.manual.input")}
                </label>
                <div class="flex items-center gap-3">
                  <label class="flex items-center gap-1 text-xs">
                    <input type="checkbox" id="ascii-mode" class="rounded ${this.getThemeClasses().border} ${this.getThemeClasses().inputBg}">
                    <span class="${this.getThemeClasses().textMuted}">${a.t("command.manual.asciiMode")}</span>
                  </label>
                  <label class="flex items-center gap-1 text-xs">
                    <input type="checkbox" id="auto-crc" checked class="rounded ${this.getThemeClasses().border} ${this.getThemeClasses().inputBg}">
                    <span class="${this.getThemeClasses().textMuted}">${a.t("command.manual.autoCrc")}</span>
                  </label>
                </div>
              </div>
              <textarea 
                id="manual-hex-input"
                class="input-field w-full h-16 font-mono text-sm resize-none"
                placeholder="Enter Modbus PDU data:&#10;• HEX Mode: 01 03 00 00 00 0A&#10;• ASCII Mode: Hello World&#10;Toggle ASCII Mode checkbox for text input"
              ></textarea>
              <div class="text-xs mt-1" id="hex-preview">
                <span class="${this.getThemeClasses().textMuted}">Preview:</span> 
                <span class="${this.getThemeClasses().textSecondary} font-mono">Enter data above (toggle ASCII Mode for text input)...</span>
              </div>
            </div>

            <!-- Command Builder -->
            <div class="border-t ${this.getThemeClasses().border} pt-3">
              <h4 class="text-xs font-medium ${this.getThemeClasses().textMuted} mb-2">${a.t("command.generator.title")}</h4>
              
              <!-- Hex Base Mode Checkbox -->
              <div class="mb-3">
                <label class="flex items-center gap-2 text-sm">
                  <input type="checkbox" id="hex-base-mode" checked class="rounded ${this.getThemeClasses().border} ${this.getThemeClasses().inputBg}">
                  <span class="${this.getThemeClasses().textSecondary}">${a.t("command.generator.hexBaseMode")}</span>
                  <span class="text-xs ${this.getThemeClasses().textMuted}">(Input values as hex strings)</span>
                </label>
              </div>

              <div class="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <label class="block text-xs ${this.getThemeClasses().textMuted} mb-1">
                    ${a.t("command.generator.slaveId")}
                  </label>
                  <input id="slave-id" class="input-field w-full text-sm" value="01" 
                         placeholder="${this.connectionType.startsWith("TCP")?"01 (Unit ID for MBAP)":"01 (hex) or 1 (dec)"}">
                </div>
                <div>
                  <label class="block text-xs ${this.getThemeClasses().textMuted} mb-1">${a.t("command.generator.functionCode")}</label>
                  <select id="function-code" class="input-field w-full text-sm">
                    <option value="01">${a.t("command.functionCodes.01")}</option>
                    <option value="02">${a.t("command.functionCodes.02")}</option>
                    <option value="03" selected>${a.t("command.functionCodes.03")}</option>
                    <option value="04">${a.t("command.functionCodes.04")}</option>
                    <option value="05">${a.t("command.functionCodes.05")}</option>
                    <option value="06">${a.t("command.functionCodes.06")}</option>
                    <option value="0F">${a.t("command.functionCodes.0F")}</option>
                    <option value="10">${a.t("command.functionCodes.10")}</option>
                  </select>
                </div>
                <div>
                  <label class="block text-xs ${this.getThemeClasses().textMuted} mb-1">${a.t("command.generator.startAddress")}</label>
                  <input id="start-address" class="input-field w-full text-sm" value="0000" placeholder="0000 (hex) or 0 (dec)">
                </div>
                <div>
                  <label class="block text-xs ${this.getThemeClasses().textMuted} mb-1">${a.t("command.generator.quantity")}</label>
                  <input id="quantity" class="input-field w-full text-sm" value="000A" placeholder="000A (hex) or 10 (dec)">
                </div>
              </div>
              
              <!-- Data Values for Function Code 0F/10 -->
              <div id="data-values-section" class="mt-3 hidden">
                <label class="block text-xs ${this.getThemeClasses().textMuted} mb-2" id="data-values-label">${a.t("command.dataValues.title")}</label>
                <div class="space-y-2" id="data-values-container">
                  <!-- Data value inputs will be dynamically added here -->
                </div>
                <button type="button" class="btn-secondary text-xs mt-2" id="add-data-value">
                  + ${a.t("command.dataValues.add")}
                </button>
              </div>
              
              <button class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition-colors duration-200 font-medium w-full mt-2 text-sm" id="build-command">
                ${a.t("command.generator.generateCommand")}
              </button>
            </div>

            <!-- Send Controls -->
            <div class="flex gap-2 pt-3 border-t ${this.getThemeClasses().border} mt-auto">
              <button class="btn-primary flex-1" id="send-command">
                ${a.t("common.send")}
              </button>
              <button class="btn-secondary" id="clear-command">
                ${a.t("common.clear")}
              </button>
            </div>
          </div>
        </div>

        <!-- Command History -->
        <div class="border-t ${this.getThemeClasses().border} pt-3">
          <div class="flex items-center justify-between mb-2">
            <h3 class="text-sm font-medium ${this.getThemeClasses().textSecondary}">${a.t("command.history.title")} & ${a.t("command.repeat.title")} (Max 10)</h3>
            <div class="flex items-center gap-2">
              <input 
                type="number" 
                id="repeat-interval" 
                class="input-field text-xs w-20" 
                value="1000" 
                min="10" 
                max="999999"
                step="1"
                pattern="[0-9]*"
                placeholder="1000"
                title="${a.t("command.repeat.interval")} (${a.t("command.repeat.minInterval")}, integers only)">
              <span class="text-xs ${this.getThemeClasses().textMuted}">ms</span>
              <button class="btn-secondary text-xs py-1 px-2" id="toggle-repeat">
                ${a.t("common.start")}
              </button>
            </div>
          </div>
          <div class="space-y-1 max-h-32 overflow-y-auto scrollbar-thin" id="command-history">
            ${this.renderCommandHistory()}
          </div>
        </div>
      </div>
    `}renderCommandHistory(){return this.recentCommands.length===0?`<p class="text-xs ${this.getThemeClasses().textMuted} text-center py-2">${a.t("command.history.empty")}</p>`:this.recentCommands.map((e,t)=>`
      <div class="flex items-center gap-2 p-1 ${this.getThemeClasses().panelBg} rounded border ${this.getThemeClasses().border} hover:bg-gray-100 dark:hover:bg-dark-panel transition-colors">
        <input 
          type="checkbox" 
          id="repeat-${t}" 
          class="rounded ${this.getThemeClasses().border} ${this.getThemeClasses().inputBg} flex-shrink-0"
          data-repeat-command="${e}"
          title="${a.t("command.repeat.selectCommands")}"
          ${this.checkedCommands.has(e)?"checked":""}
        >
        <button 
          class="flex-1 text-left text-xs font-mono ${this.getThemeClasses().textPrimary} hover:text-blue-400 transition-colors min-w-0 truncate select-none"
          data-history-command="${e}"
          title="Click: Send directly"
          style="user-select: none; -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none;"
        >
          ${e}
        </button>
        <button 
          class="text-xs text-red-400 hover:text-red-300 px-1 flex-shrink-0"
          data-remove-history="${t}"
          title="${a.t("command.history.remove")}"
        >
          ✕
        </button>
      </div>
    `).join("")}attachEventListeners(){this.attachQuickCommandListeners(),document.getElementById("send-command")?.addEventListener("click",()=>this.handleSendCommand()),document.getElementById("clear-command")?.addEventListener("click",()=>this.clearCommand()),document.getElementById("build-command")?.addEventListener("click",()=>this.buildCommand()),document.getElementById("hex-base-mode")?.addEventListener("change",()=>{this.updateInputFieldsForHexBase()}),document.getElementById("function-code")?.addEventListener("change",()=>{this.handleFunctionCodeChange()}),document.getElementById("quantity")?.addEventListener("input",()=>{this.updateDataValuesSection()}),document.getElementById("add-data-value")?.addEventListener("click",()=>{this.addDataValueInput()}),this.updateInputFieldsForHexBase(),this.handleFunctionCodeChange();const l=document.getElementById("repeat-interval");l&&(setTimeout(()=>{l&&(l.value=this.repeatInterval.toString())},0),l.addEventListener("change",()=>{const c=parseInt(l.value,10);c>=10&&Number.isInteger(c)?this.repeatInterval=c:(l.value="10",this.repeatInterval=10,alert("Minimum interval is 10ms (integers only)"))}),l.addEventListener("input",()=>{const c=parseInt(l.value,10);isNaN(c)||c<10?l.setCustomValidity("Minimum interval is 10ms"):l.setCustomValidity("")})),document.getElementById("toggle-repeat")?.addEventListener("click",()=>{this.toggleRepeatMode()});const u=document.getElementById("manual-hex-input");u?.addEventListener("keydown",c=>{c.key==="Enter"&&(c.ctrlKey||c.metaKey)?(c.preventDefault(),this.handleSendCommand()):c.key==="ArrowUp"&&c.ctrlKey?(c.preventDefault(),this.navigateHistory(-1)):c.key==="ArrowDown"&&c.ctrlKey&&(c.preventDefault(),this.navigateHistory(1))}),u?.addEventListener("input",c=>{const m=c.target;if(!(document.getElementById("ascii-mode")?.checked||!1)){const f=m.value,x=m.selectionStart,T=this.formatHexInput(f);if(T!==f){m.value=T;const I=this.adjustCursorForSpacing(f,x,T);m.setSelectionRange(I,I)}}this.updateHexPreview()}),u?.addEventListener("paste",c=>{if(document.getElementById("ascii-mode")?.checked||!1){setTimeout(()=>this.updateHexPreview(),0);return}c.preventDefault();const b=c.clipboardData?.getData("text")||"",f=c.target,x=f.selectionStart,T=f.selectionEnd,I=f.value,R=I.substring(0,x)+b+I.substring(T),B=this.formatHexInput(R);f.value=B;const P=x+this.formatHexInput(b).length;f.setSelectionRange(P,P),this.updateHexPreview()}),document.getElementById("ascii-mode")?.addEventListener("change",()=>{this.updateHexPreview()}),document.getElementById("auto-crc")?.addEventListener("change",()=>{this.updateHexPreview()}),this.attachHistoryListeners()}attachHistoryListeners(){document.querySelectorAll("[data-history-command]").forEach(e=>{let t=null;e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),t&&clearTimeout(t),t=setTimeout(()=>{const s=n.target.dataset.historyCommand;s&&this.sendCommandDirectly(s)},100)})}),document.querySelectorAll("[data-remove-history]").forEach(e=>{e.addEventListener("click",t=>{t.stopPropagation();const n=parseInt(t.target.dataset.removeHistory||"");isNaN(n)||this.removeFromRecentCommands(n)})}),document.querySelectorAll("[data-repeat-command]").forEach(e=>{e.addEventListener("change",t=>{const n=t.target.dataset.repeatCommand,s=t.target.checked;n&&(s?this.checkedCommands.add(n):this.checkedCommands.delete(n)),console.log(`Repeat command ${s?"enabled":"disabled"} for: ${n}`),this.isRepeating&&!this.hasCheckedCommands()&&this.stopRepeatMode()})})}handleSendCommand(){const e=document.getElementById("manual-hex-input"),n=document.getElementById("ascii-mode")?.checked||!1,s=e?.value.trim();if(!s){alert("Please enter a command");return}this.sendCommandDirectly(s,n),e.value="",this.updateHexPreview()}sendCommandDirectly(e,t){if(!e)return;t===void 0&&(t=document.getElementById("ascii-mode")?.checked||!1);let n;if(t)n=this.asciiToHex(e);else if(n=this.formatHexInput(e),!this.isValidHexInput(n)){alert("Invalid HEX format. Please use hex characters (0-9, A-F) only.");return}this.connectionType==="RTU"&&document.getElementById("auto-crc")?.checked&&(n=this.addCrcToCommand(n)),this.addToRecentCommands(e),this.onCommandSend(n)}sendCommandDirectlyWithoutHistory(e,t){if(!e)return;t===void 0&&(t=document.getElementById("ascii-mode")?.checked||!1);let n;if(t)n=this.asciiToHex(e);else if(n=this.formatHexInput(e),!this.isValidHexInput(n)){console.error("Invalid HEX format during repeat mode:",e);return}this.connectionType==="RTU"&&document.getElementById("auto-crc")?.checked&&(n=this.addCrcToCommand(n)),this.onCommandSend(n,!1)}buildCommand(){const e=document.getElementById("hex-base-mode").checked,t=document.getElementById("slave-id").value,n=document.getElementById("function-code").value,s=document.getElementById("start-address").value,o=document.getElementById("quantity").value;let i,r,l;const d=parseInt(n,16);if(e?(i=parseInt(t,16),r=parseInt(s,16),l=parseInt(o,16)):(i=parseInt(t,10),r=parseInt(s,10),l=parseInt(o,10)),isNaN(i)||isNaN(d)||isNaN(r)||isNaN(l)){alert("Invalid input values. Please check your entries.");return}let u;if(this.connectionType.startsWith("TCP"))if(d===15){const h=this.getCoilValuesFromInputs();if(!h){alert("Please enter valid coil values for Function Code 0F");return}const c=h.coilCount,m=h.bytes.length;u=[d,r>>8&255,r&255,c>>8&255,c&255,m,...h.bytes]}else if(d===16){const h=this.getRegisterValuesFromInputs(e);if(!h){alert("Please enter valid register values for Function Code 10");return}const c=h.length/2,m=h.length;u=[d,r>>8&255,r&255,c>>8&255,c&255,m,...h]}else u=[d,r>>8&255,r&255,l>>8&255,l&255];else if(d===15){const h=this.getCoilValuesFromInputs();if(!h){alert("Please enter valid coil values for Function Code 0F");return}const c=h.coilCount,m=h.bytes.length;u=[i,d,r>>8&255,r&255,c>>8&255,c&255,m,...h.bytes]}else if(d===16){const h=this.getRegisterValuesFromInputs(e);if(!h){alert("Please enter valid register values for Function Code 10");return}const c=h.length/2,m=h.length;u=[i,d,r>>8&255,r&255,c>>8&255,c&255,m,...h]}else u=[i,d,r>>8&255,r&255,l>>8&255,l&255];const g=u.map(h=>h.toString(16).padStart(2,"0").toUpperCase()).join(" ");this.setManualHexInput(g)}calculateCRC16(e){let t=65535;for(const n of e){t^=n;for(let s=0;s<8;s++)t&1?t=t>>1^40961:t>>=1}return t}clearCommand(){const e=document.getElementById("manual-hex-input");e&&(e.value="",e.focus(),this.updateHexPreview())}setManualHexInput(e){const t=document.getElementById("manual-hex-input");t&&(t.value=e,t.focus(),this.updateHexPreview())}updateInputFieldsForHexBase(){const e=document.getElementById("hex-base-mode");if(!e)return;const t=e.checked,n=document.getElementById("slave-id"),s=document.getElementById("start-address"),o=document.getElementById("quantity");!n||!s||!o||(t?(n.placeholder="01 (hex)",s.placeholder="0000 (hex)",o.placeholder="000A (hex)",this.convertInputValuesToHex()):(n.placeholder="1 (decimal)",s.placeholder="0 (decimal)",o.placeholder="10 (decimal)",this.convertInputValuesToDecimal()),this.updateDataValuesSection())}convertInputValuesToHex(){const e=document.getElementById("slave-id"),t=document.getElementById("start-address"),n=document.getElementById("quantity");if(!(!e||!t||!n)){if(e.value&&/^\d+$/.test(e.value)){const s=parseInt(e.value,10);isNaN(s)||(e.value=s.toString(16).padStart(2,"0").toUpperCase())}if(t.value&&/^\d+$/.test(t.value)){const s=parseInt(t.value,10);isNaN(s)||(t.value=s.toString(16).padStart(4,"0").toUpperCase())}if(n.value&&/^\d+$/.test(n.value)){const s=parseInt(n.value,10);isNaN(s)||(n.value=s.toString(16).padStart(4,"0").toUpperCase())}}}convertInputValuesToDecimal(){const e=document.getElementById("slave-id"),t=document.getElementById("start-address"),n=document.getElementById("quantity");if(!(!e||!t||!n)){if(e.value&&/^[0-9A-Fa-f]+$/.test(e.value)){const s=parseInt(e.value,16);isNaN(s)||(e.value=s.toString(10))}if(t.value&&/^[0-9A-Fa-f]+$/.test(t.value)){const s=parseInt(t.value,16);isNaN(s)||(t.value=s.toString(10))}if(n.value&&/^[0-9A-Fa-f]+$/.test(n.value)){const s=parseInt(n.value,16);isNaN(s)||(n.value=s.toString(10))}}}detectInputType(e){const t=e.replace(/\s+/g,"");return/^[0-9a-fA-F]+$/.test(t)&&t.length>0||/^([0-9a-fA-F]{1,2}\s*)+$/.test(e.trim())?"hex":e.split("").filter(o=>{const i=o.charCodeAt(0);return i>=32&&i<=126}).length/e.length>.7?"ascii":"mixed"}formatHexInput(e){let t=e.replace(/[^0-9a-fA-F]/g,"").toUpperCase();return t.length%2!==0&&(t="0"+t),t.replace(/(.{2})/g,"$1 ").trim()}asciiToHex(e){const t=[];for(let n=0;n<e.length;n++){const s=e.charCodeAt(n);t.push(s.toString(16).padStart(2,"0").toUpperCase())}return t.join(" ")}mixedToHex(e){const t=[];let n=0;for(;n<e.length;){if(/\s/.test(e[n])){n++;continue}if(n+1<e.length&&/[0-9a-fA-F]/.test(e[n])&&/[0-9a-fA-F]/.test(e[n+1])){const o=e.substring(n,n+2);if(/^[0-9a-fA-F]{2}$/i.test(o)){t.push(o.toUpperCase()),n+=2;continue}}const s=e.charCodeAt(n);t.push(s.toString(16).padStart(2,"0").toUpperCase()),n++}return t.join(" ")}isValidHexInput(e){const t=e.replace(/\s+/g,"").trim();return t.length===0?!1:/^[0-9a-fA-F]+$/.test(t)}adjustCursorForSpacing(e,t,n){const o=e.substring(0,t).replace(/[^0-9a-fA-F]/g,"").length,i=Math.floor(o/2),r=o+i;return Math.min(r,n.length)}addCrcToCommand(e){const t=e.replace(/\s+/g,""),n=[];for(let o=0;o<t.length;o+=2)n.push(parseInt(t.substring(o,o+2),16));const s=this.calculateCRC16(n);return n.push(s&255,s>>8&255),n.map(o=>o.toString(16).padStart(2,"0").toUpperCase()).join(" ")}updateHexPreview(){const e=document.getElementById("manual-hex-input"),t=document.getElementById("auto-crc"),n=document.getElementById("ascii-mode"),s=document.getElementById("hex-preview");if(!e||!s)return;const o=e.value,i=o.trim(),r=n?.checked||!1;if(!i){s.innerHTML=`
        <span class="${this.getThemeClasses().textMuted}">Preview:</span> 
        <span class="${this.getThemeClasses().textSecondary} font-mono">Enter ${r?"text":"HEX data"} above...</span>
      `;return}let l;if(r)l=this.asciiToHex(o);else if(l=this.formatHexInput(o),!this.isValidHexInput(l)){s.innerHTML=`
          <span class="${this.getThemeClasses().textMuted}">Preview:</span> 
          <span class="text-red-400 font-mono">Invalid HEX format</span>
        `;return}let d=l,u="";this.connectionType==="TCP"?u=` <span class="text-cyan-400">(+MBAP: ${7+l.replace(/\s+/g,"").length/2} bytes total)</span>`:t?.checked&&this.connectionType==="RTU"&&(d=this.addCrcToCommand(l),u=` <span class="text-green-400">(+CRC: ${l.replace(/\s+/g,"").length/2+2} bytes total)</span>`),d.replace(/\s+/g,"").length/2;const g=this.analyzePacketForPreview(d,this.connectionType);s.innerHTML=`
      <div class="flex flex-col gap-1">
        <div>
          <span class="${this.getThemeClasses().textMuted}">Preview:</span> 
          <span class="${this.getThemeClasses().textSecondary} font-mono">${d}</span>${u}
        </div>
        <div class="text-xs">
          ${this.connectionType==="TCP"?`<span class="${this.getThemeClasses().textMuted}">Protocol:</span> <span class="text-cyan-400">Modbus TCP</span>`:""}
        </div>
        ${g?`
        <div class="text-xs border-t ${this.getThemeClasses().border} pt-1 mt-1">
          <span class="${this.getThemeClasses().textMuted}">Analysis:</span>
          <div class="mt-1 p-2 ${this.getThemeClasses().panelBg} rounded text-xs ${this.getThemeClasses().textSecondary} whitespace-pre-line font-mono">${g}</div>
        </div>
        `:""}
      </div>
    `}handleFunctionCodeChange(){const e=document.getElementById("function-code"),t=document.getElementById("data-values-section"),n=document.getElementById("data-values-label"),s=document.getElementById("add-data-value");if(!e||!t||!n||!s)return;const o=parseInt(e.value,16);o===15||o===16?(t.classList.remove("hidden"),o===15?(n.textContent="Coil Values (for FC 0F)",s.textContent="+ Add Coil"):(n.textContent="Register Values (for FC 10)",s.textContent="+ Add Register"),this.updateDataValuesSection()):t.classList.add("hidden")}updateDataValuesSection(){const e=document.getElementById("function-code"),t=document.getElementById("quantity"),n=document.getElementById("data-values-container");if(!e||!t||!n)return;const s=parseInt(e.value,16);if(s!==15&&s!==16)return;const o=document.getElementById("hex-base-mode")?.checked||!1;let i;if(o?i=parseInt(t.value,16):i=parseInt(t.value,10),isNaN(i)||i<=0){n.innerHTML='<p class="text-xs ${this.getThemeClasses().textMuted}">Enter valid quantity first</p>';return}i=Math.min(i,s===15?32:20);const r=s===15,l=r?"Coil":"Reg",d=r?"coil-value-input":"register-value-input",u=n.querySelectorAll(`.${d}`),g=[];for(let c=0;c<u.length;c++)g[c]=u[c].value;let h="";for(let c=0;c<i;c++){let m,v;r?(m=g[c]||(c%2===0?"1":"0"),v="1 (ON) or 0 (OFF)"):(g[c]?m=this.convertRegisterValue(g[c],!o,o):m=o?(c+1).toString(16).padStart(4,"0").toUpperCase():(c+1).toString(),v=o?"0001 (hex)":"1 (decimal)"),h+=`
        <div class="flex items-center gap-2">
          <label class="text-xs ${this.getThemeClasses().textMuted} min-w-max">${l} ${c}:</label>
          <input type="text" 
                 class="input-field flex-1 text-xs ${d}" 
                 data-value-index="${c}"
                 value="${m}" 
                 placeholder="${v}">
          <button type="button" 
                  class="text-red-400 hover:text-red-300 text-xs px-1 remove-value-btn"
                  data-value-index="${c}">×</button>
        </div>
      `}n.innerHTML=h,n.querySelectorAll(".remove-value-btn").forEach(c=>{c.addEventListener("click",m=>{const v=m.target.dataset.valueIndex;this.removeDataValueInput(parseInt(v||"0"))})})}addDataValueInput(){const e=document.getElementById("function-code"),t=document.getElementById("data-values-container");if(!t||!e)return;const s=parseInt(e.value,16)===15,o=s?32:20,r=t.querySelectorAll(s?".coil-value-input":".register-value-input").length;if(r>=o){alert(`Maximum ${o} ${s?"coils":"registers"} allowed`);return}const l=document.getElementById("hex-base-mode")?.checked||!1,d=s?"Coil":"Reg",u=s?"coil-value-input":"register-value-input";let g,h;s?(g=r%2===0?"1":"0",h="1 (ON) or 0 (OFF)"):(g=l?(r+1).toString(16).padStart(4,"0").toUpperCase():(r+1).toString(),h=l?"0001 (hex)":"1 (decimal)");const c=document.createElement("div");c.className="flex items-center gap-2",c.innerHTML=`
      <label class="text-xs ${this.getThemeClasses().textMuted} min-w-max">${d} ${r}:</label>
      <input type="text" 
             class="input-field flex-1 text-xs ${u}" 
             data-value-index="${r}"
             value="${g}" 
             placeholder="${h}">
      <button type="button" 
              class="text-red-400 hover:text-red-300 text-xs px-1 remove-value-btn"
              data-value-index="${r}">×</button>
    `,t.appendChild(c),c.querySelector(".remove-value-btn")?.addEventListener("click",b=>{const f=b.target.dataset.valueIndex;this.removeDataValueInput(parseInt(f||"0"))});const v=document.getElementById("quantity");if(v){const b=document.getElementById("hex-base-mode")?.checked||!1,f=r+1;v.value=b?f.toString(16).padStart(4,"0").toUpperCase():f.toString()}}removeDataValueInput(e){const t=document.getElementById("function-code"),n=document.getElementById("data-values-container");if(!n||!t)return;const o=parseInt(t.value,16)===15,i=o?".coil-value-input":".register-value-input",r=o?"Coil":"Reg",l=o?"FC 0F":"FC 10";if(n.querySelectorAll(i).length<=1){alert(`At least one ${o?"coil":"register"} is required for ${l}`);return}const u=n.querySelector(`[data-value-index="${e}"]`)?.parentElement;u&&u.remove();const g=n.querySelectorAll(i);g.forEach((c,m)=>{const v=c,b=v.parentElement;v.dataset.valueIndex=m.toString();const f=b?.querySelector("label");f&&(f.textContent=`${r} ${m}:`);const x=b?.querySelector(".remove-value-btn");x&&(x.dataset.valueIndex=m.toString())});const h=document.getElementById("quantity");if(h){const c=document.getElementById("hex-base-mode")?.checked||!1,m=g.length;h.value=c?m.toString(16).padStart(4,"0").toUpperCase():m.toString()}}convertRegisterValue(e,t,n){if(t===n)return e;try{let s;return t?(s=parseInt(e,16),isNaN(s)?e:s.toString(10)):(s=parseInt(e,10),isNaN(s)?e:s.toString(16).padStart(4,"0").toUpperCase())}catch{return e}}getCoilValuesFromInputs(){const e=document.querySelectorAll(".coil-value-input");if(e.length===0)return null;const t=[];for(const s of e){const o=s.value.trim();if(!o)return null;const i=parseInt(o,10);if(isNaN(i)||i!==0&&i!==1)return null;t.push(i===1)}const n=[];for(let s=0;s<t.length;s+=8){let o=0;for(let i=0;i<8&&s+i<t.length;i++)t[s+i]&&(o|=1<<i);n.push(o)}return{coilCount:t.length,bytes:n}}getRegisterValuesFromInputs(e){const t=document.querySelectorAll(".register-value-input");if(t.length===0)return null;const n=[];for(const s of t){const o=s.value.trim();if(!o)return null;let i;if(e?i=parseInt(o,16):i=parseInt(o,10),isNaN(i)||i<0||i>65535)return null;n.push(i>>8&255,i&255)}return n}toggleRepeatMode(){this.isRepeating?this.stopRepeatMode():this.startRepeatMode()}startRepeatMode(){if(this.getCheckedCommands().length===0){alert("Please check at least one command for periodic sending");return}this.isRepeating=!0,this.updateToggleButton(),this.updateIntervalInputState(),this.startTime=performance.now(),this.expectedNextTime=this.startTime+this.repeatInterval,this.onRepeatModeChanged&&this.onRepeatModeChanged(!0);let t=0;const n=()=>{if(!this.isRepeating)return;const s=this.getCheckedCommands();if(s.length===0){this.stopRepeatMode();return}const o=performance.now(),i=s[t];this.sendCommandDirectlyWithoutHistory(i),t=(t+1)%s.length;const r=o-this.expectedNextTime,l=Math.max(0,this.repeatInterval-r);this.expectedNextTime=o+l,this.repeatTimer=setTimeout(n,l)};n()}stopRepeatMode(){this.isRepeating=!1,this.repeatTimer&&(clearTimeout(this.repeatTimer),this.repeatTimer=null),this.startTime=0,this.expectedNextTime=0,this.updateToggleButton(),this.updateIntervalInputState(),this.onRepeatModeChanged&&this.onRepeatModeChanged(!1)}updateToggleButton(){const e=document.getElementById("toggle-repeat");e&&(e.textContent=this.isRepeating?"Stop":"Start",e.className=this.isRepeating?"btn-secondary text-xs py-1 px-2 bg-red-600 hover:bg-red-700 text-white":"btn-secondary text-xs py-1 px-2")}updateIntervalInputState(){const e=document.getElementById("repeat-interval");e&&(e.disabled=this.isRepeating,this.isRepeating?(e.style.opacity="0.5",e.style.cursor="not-allowed"):(e.style.opacity="1",e.style.cursor=""))}getCheckedCommands(){const e=Array.from(this.checkedCommands).filter(t=>this.recentCommands.includes(t));return this.checkedCommands=new Set(e),e}hasCheckedCommands(){return this.getCheckedCommands().length>0}analyzePacketForPreview(e,t){const n=e.replace(/\s+/g,"").toUpperCase();return n.length<2?null:t.startsWith("TCP")?this.analyzePduForPreview(n,"TCP"):this.analyzeRtuPacketForPreview(n)}analyzePduForPreview(e,t){if(e.length<2)return null;const n=this.analyzeModbusPduForPreview(e);if(t==="TCP"){let s=`🌐 MODBUS TCP PDU (will be wrapped in MBAP header)
`;return n&&(s+=`
${n}`),s}else return n}analyzeTcpPacketForPreview(e){if(e.length<14)return null;try{const t=e.substring(0,4),n=e.substring(4,8),s=e.substring(8,12),o=e.substring(12,14),i=e.substring(14),r=this.analyzeModbusPduForPreview(i);let l=`🌐 MODBUS TCP PACKET
`;return l+=`Transaction ID: 0x${t} (${parseInt(t,16)})
`,l+=`Protocol ID: 0x${n} (${parseInt(n,16)})
`,l+=`Length: 0x${s} (${parseInt(s,16)} bytes)
`,l+=`Unit ID: 0x${o} (${parseInt(o,16)})`,r&&(l+=`

${r}`),l}catch{return null}}analyzeRtuPacketForPreview(e){if(e.length<8)return null;try{const t=e.substring(0,2),n=e.substring(2,e.length-4),s=e.substring(e.length-4),o=this.analyzeModbusPduForPreview(n);let i=`📡 MODBUS RTU PACKET
`;return i+=`Device ID: 0x${t} (${parseInt(t,16)})
`,i+=`CRC: 0x${s}`,o&&(i+=`

${o}`),i}catch{return null}}analyzeModbusPduForPreview(e){if(e.length<2)return null;const t=e.substring(0,2),n=parseInt(t,16);switch(n){case 1:return this.analyzeReadCoilsForPreview(e);case 2:return this.analyzeReadDiscreteInputsForPreview(e);case 3:return this.analyzeReadHoldingRegistersForPreview(e);case 4:return this.analyzeReadInputRegistersForPreview(e);case 6:return this.analyzeWriteSingleRegisterForPreview(e);case 15:return this.analyzeWriteMultipleCoilsForPreview(e);case 16:return this.analyzeWriteMultipleRegistersForPreview(e);default:return`📋 MODBUS PDU
Function Code: 0x${t} (${n}) - Unknown/Unsupported`}}analyzeReadCoilsForPreview(e){const t=e.substring(2,6),n=e.substring(6,10);return`📖 READ COILS (0x01) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} coils)`}analyzeReadDiscreteInputsForPreview(e){const t=e.substring(2,6),n=e.substring(6,10);return`📖 READ DISCRETE INPUTS (0x02) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} inputs)`}analyzeReadHoldingRegistersForPreview(e){const t=e.substring(2,6),n=e.substring(6,10);return`📊 READ HOLDING REGISTERS (0x03) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} registers)`}analyzeReadInputRegistersForPreview(e){const t=e.substring(2,6),n=e.substring(6,10);return`📊 READ INPUT REGISTERS (0x04) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} registers)`}analyzeWriteSingleRegisterForPreview(e){const t=e.substring(2,6),n=e.substring(6,10);return`✏️ WRITE SINGLE REGISTER (0x06)
Register Address: 0x${t} (${parseInt(t,16)})
Register Value: 0x${n} (${parseInt(n,16)})`}analyzeWriteMultipleCoilsForPreview(e){if(e.length>=12){const t=e.substring(2,6),n=e.substring(6,10),s=e.substring(10,12),o=e.substring(12);let i=`🔘 WRITE MULTIPLE COILS (0x0F) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} coils)
Byte Count: 0x${s} (${parseInt(s,16)} bytes)
`;const r=parseInt(n,16);let l=0;for(let d=0;d<o.length;d+=2)if(d+2<=o.length&&l<r){const u=o.substring(d,d+2),g=parseInt(u,16);for(let h=0;h<8&&l<r;h++){const c=(g&1<<h)!==0?"ON":"OFF";i+=`Coil ${l}: ${c}
`,l++}}return i.trim()}return"🔘 WRITE MULTIPLE COILS (0x0F)"}analyzeWriteMultipleRegistersForPreview(e){if(e.length>=12){const t=e.substring(2,6),n=e.substring(6,10),s=e.substring(10,12),o=e.substring(12);let i=`✏️ WRITE MULTIPLE REGISTERS (0x10) - REQUEST
Start Address: 0x${t} (${parseInt(t,16)})
Quantity: 0x${n} (${parseInt(n,16)} registers)
Byte Count: 0x${s} (${parseInt(s,16)} bytes)
`;for(let r=0;r<o.length;r+=4)if(r+4<=o.length){const l=o.substring(r,r+4),d=parseInt(l,16);i+=`Reg ${r/4}: 0x${l} (${d})
`}return i.trim()}return"✏️ WRITE MULTIPLE REGISTERS (0x10)"}addToHistory(e){this.commandHistory=this.commandHistory.filter(t=>t!==e),this.commandHistory.push(e),this.commandHistory.length>10&&(this.commandHistory=this.commandHistory.slice(-10)),this.historyIndex=-1,this.updateHistoryDisplay()}navigateHistory(e){if(this.commandHistory.length===0)return;this.historyIndex+=e,this.historyIndex<-1?this.historyIndex=-1:this.historyIndex>=this.commandHistory.length&&(this.historyIndex=this.commandHistory.length-1);const t=document.getElementById("manual-hex-input");if(t){if(this.historyIndex===-1)t.value="";else{let n=this.commandHistory[this.commandHistory.length-1-this.historyIndex];if(document.getElementById("auto-crc")?.checked&&this.connectionType==="RTU"){const o=n.replace(/\s+/g,"");o.length>=8&&(n=o.substring(0,o.length-4).replace(/(.{2})/g,"$1 ").trim())}t.value=n}this.updateHexPreview()}}updateHistoryDisplay(){const e=document.getElementById("command-history");e&&(e.innerHTML=this.renderCommandHistory(),this.attachHistoryListeners())}updateConnectionStatus(e,t){!t&&this.isRepeating&&(console.log("Connection lost - stopping repeat mode"),this.stopRepeatMode()),this.lastConnectionType!==e&&(this.lastConnectionType=e,this.connectionType=e,this.updateAutoCrcForConnectionType(e),this.updateQuickCommandsForConnectionType(e),this.updateHexPreview())}updateQuickCommandsForConnectionType(e){const t=document.getElementById("quick-commands"),n=document.getElementById("mode-info");t&&(t.innerHTML=this.renderQuickCommands(),this.attachQuickCommandListeners()),n&&(n.innerHTML=this.renderModeInfo()),this.updateHistoryDisplay(),console.log(`Quick commands updated for ${e} mode`)}attachQuickCommandListeners(){document.querySelectorAll("[data-command]").forEach(e=>{e.addEventListener("click",t=>{const n=t.target.dataset.command;n&&this.setManualHexInput(n)})})}renderQuickCommands(){return this.connectionType.startsWith("TCP")?`
        <button class="btn-secondary text-sm text-left" data-command="03 00 00 00 0A">
          📖 Read Holding Registers (0-9)
        </button>
        <button class="btn-secondary text-sm text-left" data-command="04 00 00 00 05">
          📊 Read Input Registers (0-4)
        </button>
        <button class="btn-secondary text-sm text-left" data-command="01 00 00 00 08">
          🔌 Read Coils (0-7)
        </button>
        <button class="btn-secondary text-sm text-left" data-command="Hello World">
          📝 ASCII Text Example
        </button>
      `:`
        <button class="btn-secondary text-sm text-left" data-command="01 03 00 00 00 0A">
          📖 Read Holding Registers (0-9)
        </button>
        <button class="btn-secondary text-sm text-left" data-command="01 04 00 00 00 05">
          📊 Read Input Registers (0-4)
        </button>
        <button class="btn-secondary text-sm text-left" data-command="01 01 00 00 00 08">
          🔌 Read Coils (0-7)
        </button>
        <button class="btn-secondary text-sm text-left" data-command="Hello World">
          📝 ASCII Text Example
        </button>
      `}renderModeInfo(){return this.connectionType.startsWith("TCP")?`
        💡 <strong>TCP Mode:</strong> MBAP header (includes Unit ID) automatically added<br>
        💡 Preview show PDU only (Device ID handled by MBAP header)<br>
      `:`
        💡 <strong>RTU Mode:</strong> Device ID + Function Code + Data<br>
        💡 CRC automatically added when Auto CRC is enabled<br>
      `}addToRecentCommands(e){const t=this.recentCommands.indexOf(e);t!==-1&&this.recentCommands.splice(t,1),this.recentCommands.unshift(e),this.recentCommands.length>this.maxRecentCommands&&(this.recentCommands=this.recentCommands.slice(0,this.maxRecentCommands)),this.updateHistoryDisplay()}removeFromRecentCommands(e){if(e>=0&&e<this.recentCommands.length){const t=this.recentCommands[e];this.recentCommands.splice(e,1),this.checkedCommands.delete(t),this.updateHistoryDisplay()}}updateAutoCrcForConnectionType(e){const t=document.getElementById("auto-crc");t&&(e==="RTU"?(t.checked=!0,t.disabled=!1,console.log("Auto CRC enabled for Modbus RTU mode")):e.startsWith("TCP")&&(t.checked=!1,t.disabled=!0,console.log("Auto CRC disabled for Modbus TCP mode (MBAP header used instead)")),t.dispatchEvent(new Event("change",{bubbles:!0})))}onLanguageChange(){const e=document.querySelector('[id*="command-content"]');e&&(e.innerHTML=this.render(),this.attachEventListeners(),this.updateConnectionStatus(this.connectionType,this.connectionType!=="RTU"))}getThemeClasses(){return this.currentTheme==="light"?{background:"bg-gray-50",panelBg:"bg-white",border:"border-gray-200",inputBg:"bg-white",textPrimary:"text-gray-900",textSecondary:"text-gray-800",textMuted:"text-gray-600"}:{background:"bg-dark-bg",panelBg:"bg-dark-surface",border:"border-dark-border",inputBg:"bg-dark-surface",textPrimary:"text-dark-text-primary",textSecondary:"text-dark-text-secondary",textMuted:"text-dark-text-muted"}}onThemeChange(e){this.currentTheme=e;const t=document.querySelector("#command-content");t&&(t.innerHTML=this.render(),this.attachEventListeners(),this.updateConnectionStatus(this.connectionType,this.connectionType!=="RTU"))}}class q{constructor(){this.logSettingsPanel=null,this.connectionPanelPosition="right",this.mainContentLayout="command-left",this.currentTheme="light",this.connectionPanelVisible=!0,this.pendingRepeatLogs=[],this.lastLogUpdateTime=0,this.logUpdateThrottleMs=250,this.batchSize=50,this.logEntryPool=[],this.maxPoolSize=500,this.gcTimer=null,this.state={connectionStatus:"disconnected",connectionConfig:{type:"RTU",serial:{port:void 0,portName:"No port selected",baudRate:9600,parity:"none",dataBits:8,stopBits:1}},isAutoScroll:!0,filter:{}},this.loadUISettings(),this.connectionPanel=new A(this.onConnectionChange.bind(this),this.onDataReceived.bind(this)),this.logPanel=new V,this.commandPanel=new O(this.onCommandSend.bind(this),this.onRepeatModeChanged.bind(this));const e=this.connectionPanelPosition==="left"||this.connectionPanelPosition==="right";this.connectionPanel.setCompactMode(e),document.addEventListener("panelBackgroundChange",()=>{this.updatePanelBackground()}),this.optimizedLogService=new w(void 0,this.recycleLogEntry.bind(this)),this.initializeMemoryManagement(),a.onLanguageChange(()=>{this.onLanguageChange()}),window.addEventListener("beforeunload",()=>{this.saveUISettings()})}async mount(e){console.log("Initial connectionPanelPosition:",this.connectionPanelPosition),e.innerHTML=this.render(),this.attachEventListeners(),await this.mountChildComponents(),this.updateLayout(),this.applyTheme(),console.log("Layout applied, current position:",this.connectionPanelPosition)}render(){return console.log("render() called, connectionPanelPosition:",this.connectionPanelPosition),`
      <div class="min-h-screen ${this.getThemeClasses().background} p-4">
        <div class="max-w-7xl mx-auto">
          <!-- Header with Controls -->
          <header class="text-center py-4 mb-4">
            <div class="flex items-center justify-between mb-4">
              <div class="flex items-center gap-4">
                <h1 class="text-2xl font-bold ${this.getThemeClasses().textPrimary}">
                  🔧 ${a.t("app.title")}
                </h1>
              </div>
              
              <!-- Panel Controls -->
              <div class="flex items-center gap-3">
                <div class="flex items-center gap-2">
                  <select id="panel-position" class="input-field btn-sm">
                    <option value="top" ${this.connectionPanelPosition==="top"?"selected":""}>📍 ${a.t("panel.top")}</option>
                    <option value="left" ${this.connectionPanelPosition==="left"?"selected":""}>⬅️ ${a.t("panel.left")}</option>
                    <option value="right" ${this.connectionPanelPosition==="right"?"selected":""}>➡️ ${a.t("panel.right")}</option>
                    <option value="hide">🚫 ${a.t("panel.hide")}</option>
                  </select>
                </div>
                <div class="flex items-center gap-2">
                  <select id="main-layout" class="input-field btn-sm">
                    <option value="command-left" ${this.mainContentLayout==="command-left"?"selected":""}>⬅️ ${a.t("panel.commandLeft")}</option>
                    <option value="command-right" ${this.mainContentLayout==="command-right"?"selected":""}>➡️ ${a.t("panel.commandRight")}</option>
                  </select>
                </div>
                ${this.connectionPanelVisible?"":`<button id="show-connection-panel" class="btn-secondary btn-sm">
                  🔽 ${a.t("panel.show")}
                </button>`}
                <div class="flex items-center gap-2">
                  <select id="language-selector" class="input-field btn-sm">
                    <option value="en" ${a.getCurrentLanguage()==="en"?"selected":""}>🇺🇸 English</option>
                    <option value="ko" ${a.getCurrentLanguage()==="ko"?"selected":""}>🇰🇷 한국어</option>
                  </select>
                </div>
                <div class="flex items-center gap-2">
                  <select id="theme-selector" class="input-field btn-sm">
                    <option value="dark" ${this.currentTheme==="dark"?"selected":""}>🌙 ${a.t("common.dark")}</option>
                    <option value="light" ${this.currentTheme==="light"?"selected":""}>☀️ ${a.t("common.light")}</option>
                  </select>
                </div>
                <button id="global-settings" class="btn-secondary btn-sm" title="${a.t("common.settings")}">
                  ⚙️ ${a.t("common.settings")}
                </button>
              </div>
            </div>
            
            <div class="flex items-center justify-center gap-2">
              <div class="status-indicator ${this.getStatusClass()}"></div>
              <span class="text-sm ${this.getThemeClasses().textSecondary}">
                ${this.getStatusText()}
              </span>
            </div>
          </header>

          <!-- Dynamic Layout Container -->
          <div id="layout-container">
            ${this.renderLayout()}
          </div>
        </div>
      </div>
    `}attachEventListeners(){const e=document.getElementById("panel-position");document.getElementById("toggle-connection-panel"),e?.addEventListener("change",r=>{this.connectionPanelPosition=r.target.value,this.updateLayout(),this.saveUISettings()}),document.getElementById("main-layout")?.addEventListener("change",r=>{this.mainContentLayout=r.target.value,this.updateLayout(),this.saveUISettings()}),document.getElementById("show-connection-panel")?.addEventListener("click",()=>{this.connectionPanelVisible=!0,this.updateLayout(),this.saveUISettings()}),document.getElementById("language-selector")?.addEventListener("change",r=>{const l=r.target.value;a.setLanguage(l),this.onLanguageChange()}),document.getElementById("theme-selector")?.addEventListener("change",r=>{const l=r.target.value;this.setTheme(l)}),document.getElementById("global-settings")?.addEventListener("click",()=>{this.showGlobalSettings()}),this.attachMinimizeListener(),this.attachLogPanelListeners()}attachMinimizeListener(){setTimeout(()=>{document.getElementById("minimize-connection")?.addEventListener("click",()=>{this.connectionPanelVisible=!1,this.updateLayout(),this.saveUISettings()})},0)}attachLogPanelListeners(){setTimeout(()=>{document.getElementById("clear-logs")?.addEventListener("click",()=>{console.log("Clear logs button clicked"),this.onLogsClear()})},50)}async mountChildComponents(){const e=document.getElementById("connection-content"),t=document.getElementById("log-content"),n=document.getElementById("command-content");if(e){const s=this.connectionPanelPosition==="left"||this.connectionPanelPosition==="right";this.connectionPanel.setCompactMode(s),this.connectionPanel.onThemeChange(this.currentTheme),await this.connectionPanel.mount(e)}t&&(this.logPanel.mount(t),this.logPanel.setClearLogsCallback(this.onLogsClear.bind(this)),this.logPanel.setConnectionType(this.state.connectionConfig.type)),n&&(this.commandPanel.onThemeChange(this.currentTheme),this.commandPanel.mount(n))}renderLayout(){const e=this.connectionPanelVisible?`
      <div id="connection-panel" class="panel ${this.getConnectionPanelClasses()}">
        <div class="panel-header flex items-center justify-between">
          <span>${a.t("connection.title")}</span>
          <button id="minimize-connection" class="text-xs text-dark-text-muted hover:text-dark-text-primary">
            ${this.connectionPanelPosition==="top"?"−":"×"}
          </button>
        </div>
        <div class="panel-content" id="connection-content">
          <!-- Connection panel content will be mounted here -->
        </div>
      </div>
    `:"";switch(this.connectionPanelPosition){case"left":return`
          <div class="grid ${this.connectionPanelVisible?"grid-cols-1 lg:grid-cols-5":"grid-cols-1"} gap-4 h-screen-adjusted">
            ${this.connectionPanelVisible?`
              <!-- Left Connection Panel -->
              <div class="lg:col-span-1 h-full">
                ${e}
              </div>
              
              <!-- Main Content -->
              <div class="lg:col-span-4 h-full">
                ${this.renderMainContent()}
              </div>
            `:`
              <!-- Main Content Full Width -->
              <div class="col-span-1 h-full">
                ${this.renderMainContent()}
              </div>
            `}
          </div>
        `;case"right":return`
          <div class="grid ${this.connectionPanelVisible?"grid-cols-1 lg:grid-cols-5":"grid-cols-1"} gap-4 h-screen-adjusted">
            ${this.connectionPanelVisible?`
              <!-- Main Content -->
              <div class="lg:col-span-4 h-full">
                ${this.renderMainContent()}
              </div>
              
              <!-- Right Connection Panel -->
              <div class="lg:col-span-1 h-full">
                ${e}
              </div>
            `:`
              <!-- Main Content Full Width -->
              <div class="col-span-1 h-full">
                ${this.renderMainContent()}
              </div>
            `}
          </div>
        `;case"top":return`
          <div class="space-y-4">
            ${e}
            ${this.renderMainContent()}
          </div>
        `;case"hide":return`
          <div class="h-screen-adjusted">
            ${e}
            ${this.renderMainContent()}
          </div>
        `;default:return console.warn("Unknown panel position:",this.connectionPanelPosition,"defaulting to right"),this.connectionPanelPosition="right",`
          <div class="grid ${this.connectionPanelVisible?"grid-cols-1 lg:grid-cols-5":"grid-cols-1"} gap-4 h-screen-adjusted">
            ${this.connectionPanelVisible?`
              <!-- Left Connection Panel -->
              <div class="lg:col-span-1 h-full">
                ${e}
              </div>
              
              <!-- Main Content -->
              <div class="lg:col-span-4 h-full">
                ${this.renderMainContent()}
              </div>
            `:`
              <!-- Main Content Full Width -->
              <div class="col-span-1 h-full">
                ${this.renderMainContent()}
              </div>
            `}
          </div>
        `}}renderMainContent(){return this.mainContentLayout==="command-left"?`
        <!-- Main Layout: Command Panel (left) + Log Panel (right) -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
          <!-- Command Panel with flexible height -->
          <div class="md:col-span-1 order-2 md:order-1">
            <div id="command-panel" class="panel h-auto max-h-screen">
              <div class="panel-header">
                ${a.t("command.manual.title")}
              </div>
              <div class="panel-content overflow-y-auto h-auto" id="command-content">
                <!-- Command panel content will be mounted here -->
              </div>
            </div>
          </div>

          <!-- Log Panel with fixed height -->
          <div class="md:col-span-2 order-1 md:order-2">
            <div id="log-panel" class="panel panel-fixed">
              <div class="panel-header flex-shrink-0 flex items-center justify-between">
                <span>${a.t("log.title")}</span>
                <div class="flex items-center gap-2">
                  <button class="btn-secondary text-sm py-1 px-3" id="clear-logs">
                    ${a.t("log.clearLogs")}
                  </button>
                </div>
              </div>
              <div class="panel-content flex-1 min-h-0 p-0" id="log-content">
                <!-- Log panel content will be mounted here -->
              </div>
            </div>
          </div>
        </div>
      `:`
        <!-- Main Layout: Log Panel (left) + Command Panel (right) -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
          <!-- Log Panel with fixed height -->
          <div class="md:col-span-2 order-1">
            <div id="log-panel" class="panel panel-fixed">
              <div class="panel-header flex-shrink-0 flex items-center justify-between">
                <span>${a.t("log.title")}</span>
                <div class="flex items-center gap-2">
                  <button class="btn-secondary text-sm py-1 px-3" id="clear-logs">
                    ${a.t("log.clearLogs")}
                  </button>
                </div>
              </div>
              <div class="panel-content flex-1 min-h-0 p-0" id="log-content">
                <!-- Log panel content will be mounted here -->
              </div>
            </div>
          </div>

          <!-- Command Panel with flexible height -->
          <div class="md:col-span-1 order-2">
            <div id="command-panel" class="panel h-auto max-h-screen">
              <div class="panel-header">
                ${a.t("command.manual.title")}
              </div>
              <div class="panel-content overflow-y-auto h-auto" id="command-content">
                <!-- Command panel content will be mounted here -->
              </div>
            </div>
          </div>
        </div>
      `}getConnectionPanelClasses(){const e="layout-transition",t=this.connectionPanelVisible?"panel-visible":"panel-hidden",n=this.connectionPanel?this.connectionPanel.getPanelBackgroundClass():"bg-gray-900/10";switch(this.connectionPanelPosition){case"left":return`${e} ${t} ${n} panel-positioned-left panel-compact h-screen-adjusted panel-full-height debug-layout-left`;case"right":return`${e} ${t} ${n} panel-positioned-right panel-compact h-screen-adjusted panel-full-height debug-layout-right`;case"top":return`${e} ${t} ${n} panel-positioned-top debug-layout-top`;case"hide":return`${e} hidden ${n}`;default:return console.warn("getConnectionPanelClasses: Unknown position:",this.connectionPanelPosition),`${e} ${t} ${n} panel-positioned-left panel-compact h-screen-adjusted panel-full-height debug-layout-left`}}updateLayout(){console.log("updateLayout called, connectionPanelPosition:",this.connectionPanelPosition);const e=document.getElementById("layout-container"),t=document.getElementById("toggle-connection-panel"),n=this.connectionPanelPosition==="left"||this.connectionPanelPosition==="right";this.connectionPanel.setCompactMode(n),e&&(console.log("Rendering layout for position:",this.connectionPanelPosition),e.innerHTML=this.renderLayout(),this.mountChildComponents(),this.attachMinimizeListener(),this.attachLogPanelListeners()),t&&(t.innerHTML=`${this.connectionPanelVisible?"🔼 Hide":"🔽 Show"} Connection`)}updatePanelBackground(){const e=document.getElementById("connection-panel");if(e){const t=`panel ${this.getConnectionPanelClasses()}`;e.className=t}}getStatusClass(){switch(this.state.connectionStatus){case"connected":return"status-connected";case"connecting":return"status-connecting";case"error":return"status-error";default:return"status-disconnected"}}getStatusText(){switch(this.state.connectionStatus){case"connected":return"Connected";case"connecting":return"Connecting...";case"error":return"Connection Error";default:return"Disconnected"}}onConnectionChange(e,t){this.state.connectionStatus=e,t&&(this.state.connectionConfig=t),this.commandPanel.updateConnectionStatus(this.state.connectionConfig.type,e==="connected"),this.logPanel.setConnectionType(this.state.connectionConfig.type),this.updateStatus()}async onCommandSend(e,t){try{if(this.state.connectionStatus==="connected"){const n=this.getCurrentConnectionType();if(n==="RTU"){const s=this.createLogEntry(Date.now().toString(),new Date,"send",e);t?this.addToThrottledLogs(s):(this.optimizedLogService.addLog(s),this.updateLogPanelFromService());const o=this.connectionPanel.getSerialService();o&&o.getConnectionStatus()&&await o.sendHexString(e)}else if(n==="TCP_NATIVE"){const s=this.connectionPanel.getTcpNativeService();if(s&&s.isTcpConnected()){const o=this.getActualTcpData(e),i=this.createLogEntry(Date.now().toString(),new Date,"send",o);t?this.addToThrottledLogs(i):(this.optimizedLogService.addLog(i),this.updateLogPanelFromService()),s.sendData(o),t||console.log("TCP Native Command sent successfully:",o)}}}}catch(n){if(console.error("Failed to send command:",n),!t){const s=this.createLogEntry((Date.now()+1).toString(),new Date,"recv","",n instanceof Error?n.message:String(n));this.optimizedLogService.addLog(s),this.updateLogPanelFromService()}}}async addToThrottledLogs(e){this.pendingRepeatLogs.push(e),this.pendingRepeatLogs.length>=this.batchSize?await this.flushPendingLogs():Date.now()-this.lastLogUpdateTime>=this.logUpdateThrottleMs&&await this.flushPendingLogs()}async flushThrottledLogs(){if(this.pendingRepeatLogs.length!==0){for(const e of this.pendingRepeatLogs)this.optimizedLogService.addLog(e);this.updateLogPanelFromService();for(const e of this.pendingRepeatLogs)this.recycleLogEntry(e);this.pendingRepeatLogs=[],this.lastLogUpdateTime=Date.now()}}updateLogPanelFromService(){const e=this.optimizedLogService.getAllLogs();console.log(`Updating LogPanel with ${e.length} logs from service`),this.logPanel.updateLogs(e)}initializeMemoryManagement(){this.gcTimer=setInterval(()=>{this.performMemoryCleanup()},3e4),window.addEventListener("beforeunload",()=>{this.cleanup()})}createLogEntry(e,t,n,s,o){let i=this.logEntryPool.pop();return i||(i={}),i.id=e,i.timestamp=t,i.direction=n,i.data=s,i.error=o,i}recycleLogEntry(e){this.logEntryPool.length<this.maxPoolSize&&(e.error=void 0,e.data="",this.logEntryPool.push(e))}performMemoryCleanup(){this.logEntryPool.length>this.maxPoolSize&&(this.logEntryPool=this.logEntryPool.slice(0,this.maxPoolSize)),typeof window.gc=="function"&&window.gc()}cleanup(){this.gcTimer&&(clearInterval(this.gcTimer),this.gcTimer=null),this.logEntryPool=[],this.pendingRepeatLogs=[]}async destroy(){try{if(this.optimizedLogService&&await this.optimizedLogService.destroy(),this.connectionPanel)try{const e=this.connectionPanel.getSerialService?.();e&&e.getConnectionStatus()&&await e.disconnect();const t=this.connectionPanel.getTcpNativeService?.();t&&t.isTcpConnected()&&await t.disconnect()}catch(e){console.warn("[App] Error disconnecting services:",e)}this.logPanel&&typeof this.logPanel.destroy=="function"&&this.logPanel.destroy(),this.commandPanel&&typeof this.commandPanel.destroy=="function"&&this.commandPanel.destroy(),this.logSettingsPanel&&typeof this.logSettingsPanel.destroy=="function"&&this.logSettingsPanel.destroy(),document.removeEventListener("panelBackgroundChange",this.updatePanelBackground),window.removeEventListener("beforeunload",this.cleanup),this.cleanup(),this.performMemoryCleanup(),console.log("[App] Destroyed successfully")}catch(e){console.error("[App] Error during destroy:",e)}}async flushPendingLogs(){await this.flushThrottledLogs()}async onRepeatModeChanged(e){this.logPanel.setRepeatMode(e),e||await this.flushPendingLogs()}onLogsClear(){console.log("onLogsClear called"),this.optimizedLogService.clearLogs(),console.log("OptimizedLogService cleared");for(const e of this.pendingRepeatLogs)this.recycleLogEntry(e);this.pendingRepeatLogs=[],this.lastLogUpdateTime=0,this.resetIncrementalTracking(),this.updateLogPanelFromService(),console.log("Log panel updated from service"),this.logPanel.clearLogs()}resetIncrementalTracking(){}getCurrentConnectionType(){const e=document.querySelector(".tab-button.active");return e?e.getAttribute("data-tab")==="TCP_NATIVE"?"TCP_NATIVE":"RTU":this.state.connectionConfig.type||"RTU"}getActualTcpData(e,t=1){const n=e.replace(/\s+/g,""),s=n.length/2,o=(Date.now()%65536).toString(16).padStart(4,"0").toUpperCase(),i="0000",r=(1+s).toString(16).padStart(4,"0").toUpperCase(),l=t.toString(16).padStart(2,"0").toUpperCase();return(o+i+r+l+n.toUpperCase()).replace(/(.{2})/g,"$1 ").trim()}async onDataReceived(e){const t=this.createLogEntry(Date.now().toString(),new Date,"recv",e);this.optimizedLogService.addLog(t),this.updateLogPanelFromService()}updateStatus(){const e=document.querySelector(".status-indicator"),t=document.querySelector(".status-indicator + span");e&&(e.className=`status-indicator ${this.getStatusClass()}`),t&&(t.textContent=this.getStatusText())}showGlobalSettings(){this.logSettingsPanel||(this.logSettingsPanel=new $(this.optimizedLogService),console.log("Setting clear callback for LogSettingsPanel from App"),this.logSettingsPanel.setClearCallback(this.onLogsClear.bind(this))),this.logSettingsPanel.show()}toggleConnectionPanel(){this.connectionPanelVisible=!this.connectionPanelVisible,this.updateLayout(),this.saveUISettings()}setConnectionPanelPosition(e){this.connectionPanelPosition=e,this.updateLayout(),this.saveUISettings()}getConnectionPanelState(){return{position:this.connectionPanelPosition,visible:this.connectionPanelVisible}}setMainContentLayout(e){this.mainContentLayout=e,this.updateLayout(),this.saveUISettings()}getMainContentLayout(){return this.mainContentLayout}async loadUISettings(){try{if(typeof chrome<"u"&&chrome.storage){const e=await chrome.storage.local.get(["uiSettings"]);if(e.uiSettings){const t=e.uiSettings;this.connectionPanelPosition=t.connectionPanelPosition||"right",this.connectionPanelVisible=t.connectionPanelVisible!==!1,this.mainContentLayout=t.mainContentLayout||"command-left",this.currentTheme=t.theme||"light",setTimeout(()=>this.applyTheme(),0)}}}catch(e){console.warn("Failed to load UI settings:",e)}}async saveUISettings(){try{if(typeof chrome<"u"&&chrome.storage){const e={connectionPanelPosition:this.connectionPanelPosition,connectionPanelVisible:this.connectionPanelVisible,mainContentLayout:this.mainContentLayout,theme:this.currentTheme};await chrome.storage.local.set({uiSettings:e})}}catch(e){console.warn("Failed to save UI settings:",e)}}onLanguageChange(){const e=document.querySelector(".min-h-screen");if(!e)return;const t={connectionStatus:this.state.connectionStatus,connectionConfig:this.state.connectionConfig,isAutoScroll:this.state.isAutoScroll,filter:this.state.filter};e.innerHTML=this.render(),this.attachEventListeners(),this.mountChildComponents().then(()=>{this.state=t,this.updateStatus(),this.updateLayout(),this.connectionPanel?.onLanguageChange?.(),this.logPanel?.onLanguageChange?.(),this.commandPanel?.onLanguageChange?.(),this.logSettingsPanel&&(this.logSettingsPanel.destroy(),this.logSettingsPanel=null)})}getThemeClasses(){return this.currentTheme==="light"?{background:"",textPrimary:"text-gray-900",textSecondary:"text-gray-800",textMuted:"text-gray-600"}:{background:"",textPrimary:"text-dark-text-primary",textSecondary:"text-dark-text-secondary",textMuted:"text-dark-text-muted"}}applyTheme(){const e=document.documentElement;e.classList.remove("light-theme","dark-theme"),e.classList.add(this.currentTheme+"-theme");const t=this.currentTheme==="light"?"#f9fafb":"#0f0f23";document.body.style.setProperty("background-color",t,"important"),this.updateExistingElementsForTheme()}updateExistingElementsForTheme(){const e=this.getThemeClasses(),t=document.querySelector(".min-h-screen");t&&t.classList.remove("bg-gray-50","bg-dark-bg");const n=document.querySelector("h1");n&&(n.className=n.className.replace(/text-\S+/g,""),n.classList.add(e.textPrimary.split(" ")[0])),document.querySelectorAll("span.text-dark-text-muted, span.text-gray-500").forEach(i=>{i.className=i.className.replace(/text-\S+/g,""),i.classList.add(e.textMuted.split(" ")[0])});const o=document.getElementById("theme-selector");o&&(o.value=this.currentTheme),this.connectionPanel&&typeof this.connectionPanel.onThemeChange=="function"&&this.connectionPanel.onThemeChange(this.currentTheme),this.logPanel&&typeof this.logPanel.onThemeChange=="function"&&this.logPanel.onThemeChange(this.currentTheme),this.commandPanel&&typeof this.commandPanel.onThemeChange=="function"&&this.commandPanel.onThemeChange(this.currentTheme),this.logSettingsPanel&&typeof this.logSettingsPanel.onThemeChange=="function"&&this.logSettingsPanel.onThemeChange(this.currentTheme)}getCurrentTheme(){return this.currentTheme}setTheme(e){this.currentTheme=e,this.applyTheme(),this.saveUISettings()}}document.addEventListener("DOMContentLoaded",async()=>{const p=document.getElementById("app");p?(await new q().mount(p),W()):console.error("App element not found")});function W(p){const e=document.body;e.style.minWidth="800px",e.style.minHeight="600px",G()}function G(){typeof chrome<"u"&&chrome.runtime&&chrome.runtime.onMessage.addListener((p,e,t)=>(console.log("Popup received message:",p),!0)),console.log("Testing Web Serial API..."),console.log("navigator.serial available:","serial"in navigator),console.log("navigator.serial:",navigator.serial),"serial"in navigator?navigator.serial.getPorts().then(p=>{console.log("Available serial ports:",p.length),p.forEach((e,t)=>{console.log(`Port ${t}:`,e.getInfo())})}).catch(p=>{console.error("Error getting ports:",p)}):console.warn("Web Serial API not available")}
