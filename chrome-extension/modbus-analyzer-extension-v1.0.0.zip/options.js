class r{constructor(){this.defaultSettings={timeout:5e3,retryCount:3,showTimestamps:!0,autoScroll:!0,hexFormat:!0,logLevel:"info",enableDebug:!1},this.init()}async init(){await this.loadSettings(),this.render(),this.setupEventListeners()}render(){const s=document.getElementById("options-app");s&&(s.innerHTML=`
      <div class="max-w-4xl mx-auto">
        <!-- Communication Settings -->
        <section class="bg-dark-surface border border-dark-border rounded-lg p-6 mb-6">
          <h2 class="text-xl font-semibold mb-4">Communication Settings</h2>
          
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-medium mb-2">Response Timeout (ms)</label>
              <input type="number" id="timeout" class="input-field w-full" min="1000" max="30000">
            </div>
            
            <div>
              <label class="block text-sm font-medium mb-2">Retry Count</label>
              <input type="number" id="retry-count" class="input-field w-full" min="0" max="10">
            </div>
          </div>
        </section>

        <!-- Display Settings -->
        <section class="bg-dark-surface border border-dark-border rounded-lg p-6 mb-6">
          <h2 class="text-xl font-semibold mb-4">Display Settings</h2>
          
          <div class="space-y-4">
            <label class="flex items-center gap-3">
              <input type="checkbox" id="show-timestamps" class="w-4 h-4">
              <span>Show timestamps in logs</span>
            </label>
            
            <label class="flex items-center gap-3">
              <input type="checkbox" id="auto-scroll" class="w-4 h-4">
              <span>Auto-scroll logs</span>
            </label>
            
            <label class="flex items-center gap-3">
              <input type="checkbox" id="hex-format" class="w-4 h-4">
              <span>Display data in HEX format</span>
            </label>
          </div>
        </section>

        <!-- Advanced Settings -->
        <section class="bg-dark-surface border border-dark-border rounded-lg p-6 mb-6">
          <h2 class="text-xl font-semibold mb-4">Advanced Settings</h2>
          
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-medium mb-2">Log Level</label>
              <select id="log-level" class="input-field w-full">
                <option value="error">Error</option>
                <option value="warn">Warning</option>
                <option value="info">Info</option>
                <option value="debug">Debug</option>
              </select>
            </div>
            
            <div class="flex items-center">
              <label class="flex items-center gap-3">
                <input type="checkbox" id="enable-debug" class="w-4 h-4">
                <span>Enable debug mode</span>
              </label>
            </div>
          </div>
        </section>

        <!-- Native App Settings -->
        <section class="bg-dark-surface border border-dark-border rounded-lg p-6 mb-6">
          <h2 class="text-xl font-semibold mb-4">Native App Settings</h2>
          
          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium mb-2">Native App Status</label>
              <div id="native-status" class="p-3 rounded-md bg-dark-panel">
                <span id="native-status-text">Checking...</span>
              </div>
            </div>
            
            <div>
              <label class="block text-sm font-medium mb-2">Native App Path (Optional)</label>
              <input type="text" id="native-app-path" class="input-field w-full" 
                     placeholder="/usr/local/bin/modbus-native-app">
              <p class="text-xs text-dark-text-muted mt-1">
                Leave empty to use default path
              </p>
            </div>
          </div>
        </section>

        <!-- Actions -->
        <div class="flex gap-4">
          <button id="save-settings" class="btn-primary">Save Settings</button>
          <button id="reset-settings" class="btn-secondary">Reset to Defaults</button>
          <button id="test-native" class="btn-secondary">Test Native App</button>
        </div>

        <!-- Status Messages -->
        <div id="status-message" class="mt-4 p-3 rounded-md hidden"></div>
      </div>
    `)}setupEventListeners(){var e,t,n;(e=document.getElementById("save-settings"))==null||e.addEventListener("click",()=>{this.saveSettings()}),(t=document.getElementById("reset-settings"))==null||t.addEventListener("click",()=>{this.resetSettings()}),(n=document.getElementById("test-native"))==null||n.addEventListener("click",()=>{this.testNativeApp()}),document.querySelectorAll("input, select").forEach(a=>{a.addEventListener("change",()=>{this.saveSettings()})})}async loadSettings(){return new Promise(s=>{chrome.storage.sync.get(this.defaultSettings,e=>{const t=document.getElementById("timeout"),n=document.getElementById("retry-count"),a=document.getElementById("show-timestamps"),i=document.getElementById("auto-scroll"),o=document.getElementById("hex-format"),l=document.getElementById("log-level"),d=document.getElementById("enable-debug"),c=document.getElementById("native-app-path");t&&(t.value=e.timeout.toString()),n&&(n.value=e.retryCount.toString()),a&&(a.checked=e.showTimestamps),i&&(i.checked=e.autoScroll),o&&(o.checked=e.hexFormat),l&&(l.value=e.logLevel),d&&(d.checked=e.enableDebug),c&&(c.value=e.nativeAppPath||""),s()})})}saveSettings(){var e,t,n,a,i,o,l,d;const s={timeout:parseInt((e=document.getElementById("timeout"))==null?void 0:e.value)||5e3,retryCount:parseInt((t=document.getElementById("retry-count"))==null?void 0:t.value)||3,showTimestamps:((n=document.getElementById("show-timestamps"))==null?void 0:n.checked)||!1,autoScroll:((a=document.getElementById("auto-scroll"))==null?void 0:a.checked)||!1,hexFormat:((i=document.getElementById("hex-format"))==null?void 0:i.checked)||!1,logLevel:((o=document.getElementById("log-level"))==null?void 0:o.value)||"info",enableDebug:((l=document.getElementById("enable-debug"))==null?void 0:l.checked)||!1,nativeAppPath:((d=document.getElementById("native-app-path"))==null?void 0:d.value)||void 0};chrome.storage.sync.set(s,()=>{this.showStatus("Settings saved successfully","success"),chrome.runtime.sendMessage({type:"settings_updated",settings:s})})}resetSettings(){chrome.storage.sync.set(this.defaultSettings,()=>{this.loadSettings(),this.showStatus("Settings reset to defaults","info")})}async testNativeApp(){try{const s=await this.sendMessageToBackground({type:"check_native_status"}),e=document.getElementById("native-status-text");e&&(s.connected?(e.textContent="✅ Native app connected",e.className="text-green-400"):(e.textContent="❌ Native app not connected",e.className="text-red-400"))}catch(s){this.showStatus(`Native app test failed: ${s}`,"error")}}sendMessageToBackground(s){return new Promise((e,t)=>{chrome.runtime.sendMessage(s,n=>{chrome.runtime.lastError?t(new Error(chrome.runtime.lastError.message)):n!=null&&n.success?e(n.data):t(new Error((n==null?void 0:n.error)||"Unknown error"))})})}showStatus(s,e){const t=document.getElementById("status-message");t&&(t.textContent=s,t.className=`mt-4 p-3 rounded-md ${e==="success"?"bg-green-900 text-green-200":e==="error"?"bg-red-900 text-red-200":"bg-blue-900 text-blue-200"}`,t.classList.remove("hidden"),setTimeout(()=>{t.classList.add("hidden")},3e3))}}document.addEventListener("DOMContentLoaded",()=>{new r});
